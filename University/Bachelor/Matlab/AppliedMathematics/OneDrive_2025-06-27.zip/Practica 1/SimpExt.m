function z = SimpsonExtendida(f,a,b,m)
%m=intervalos 2m+1 nudos
h=(b-a)/(2*m);
coefs=(1/3)*ones(1,2*m+1);
indPar=2:2:2*m;
indImpar=3:2:2*m-1;
coefs(indPar)=4/3;
coefs(indImpar)=2/3;
nudos=a:h:b;
z=h*sum(coefs.*f(nudos))

end

