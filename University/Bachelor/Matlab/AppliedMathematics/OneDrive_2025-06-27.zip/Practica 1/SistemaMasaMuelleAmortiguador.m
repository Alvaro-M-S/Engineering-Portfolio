%Datos
m=10;
k=3;
c=0.2;
d0=1;
v0=0;
F=@(t) cos(2*t); %F=@(t) 0*t; dan t ceros, vector de dimension t de ceros
T=20;

%C�lculos
f=@(t,z) [z(2); (F(t)-k*z(1)-c*z(2))/m]
z0=[d0;v0];
[tnum,znum]=ode45(f,[0 T],z0);

d=znum(:,1); %primera columna de znum, los desplaz
v=znum(:,2)% segunda columna de znum, las velocidades


%Dibujo
figure(1)
plot(tnum,d)

figure(2)
plot(tnum,v)
