%% MEF para un sistema de muelles unidimensional. PARTE 3
% El programa completo se compone de tres archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: MEF_SistemaMuellesUnidim_01_Datos
% 2. C�lculo del desplazamiento y la fuerza en cada uno de los nudos: MEF_SistemaMuellesUnidim_02_Calculos
% 3. Dibujo del sistema libre y con carga: MEF_SistemaMuellesUnidim_03_Dibujo
%% Dibujo del sistema libre y con carga
%
% Datos para el dibujo
FactorDilatacionParaDibujo=2.0e2;%
bet=-0.5;
gam=1.5;
sam=0.2;
%%
COORTrasDeformacionDibujo=COOR+FactorDilatacionParaDibujo*d;
figure(1)
alf=0.03;
for i=1:n
    plot(COOR(i),0,'LineStyle','none','Marker','o','Color','k','MarkerFaceColor','k','MarkerSize',8)
    text(COOR(i)-alf,-sam,num2str(i))
    hold on  
end

plot([COOR(1) COOR(n)],[0 0],'LineStyle','-','Marker','none','Color','k','LineWidth',0.8)
text(COOR(1)-alf,1.5*sam,'Sistema sin cargas')
hold off
ylim([-2,2])
axis off
%
for i=1:n
    hold on
   plot(COORTrasDeformacionDibujo(i),bet,'LineStyle','none','Marker','o','Color','b','MarkerFaceColor','b','MarkerSize',8)  
   text(COORTrasDeformacionDibujo(i)-alf,bet-sam,num2str(i),'Color','blue')
end
plot([COORTrasDeformacionDibujo(1) COORTrasDeformacionDibujo(n)],[bet bet],'LineStyle','-','Marker','none','Color','b','LineWidth',0.8)
text(COOR(1)-alf,bet-2*sam,'Sistema cargado','Color','blue')
hold off
%
title('Sistema de muelles 1D libre y con carga','FontSize',14)
