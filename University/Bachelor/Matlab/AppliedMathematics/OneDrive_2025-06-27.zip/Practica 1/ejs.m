%rng(1)
%A=rand(10,3);
%b=rand(10,1);
%p=[1 2 3 4 5 5 4 3 2 1];
%D=(p'.^(1/2))*(p.*(1/2));
%C=D*A;
%xp=C\b
%res1=norm(b-C*xp)
%x=A\b
%res2=norm(b-A*x)

COOR = [0;30; 60; 80; 100];
MASA = [4e5; 7.1e5; 2.2e5; 3.2e5; 2.7e5];
RIG = [2e5; 3e5; 4.2e5; 2.7e5];
AMORT =[70; 100; 20;10];
M=diag(MASA);
CON=[1 2; 2 3; 3 4; 4 5; 5 6];
s=size(CON,1);
n=length(COOR);
K=zeros(n);
C=zeros(n);
d=[2.1e-2; 0
for e=1:s
 ke=[RIG(e) -RIG(e);-RIG(e) RIG(e)];
 ce=[AMORT(e) -AMORT(e); -AMORT(e) AMORT(e)];

 ind=[CON(e,1); CON(e,2)];
 
 K(ind,ind)=K(ind,ind)+ke;
 C(ind,ind)=C(ind,ind)+ce;
 
end
