%% Din�mica para un sistema mec�nico 1D. PARTE 1.
% El programa completo se compone de tres archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: Dinamica_SistemaMecanico1D_01_Datos
% 2. C�lculo del desplazamiento y la fuerza
%    en cada uno de las masas y en cada instante de tiempo: DinamicaSistemaMecanico1D_02_Calculos
% 3. Gr�ficas: DinamicaSistemaMecanico1D_03_Graficas
%% Datos
T=1000;% instante final en la simulaci�n
% COOR es un vector columna que contiene las coordenadas de los nudos (en el sistema sin deformar) 
COOR=[
0.0 % nudo 1
2.4 % nudo 2
3.9 % nudo 3
5.2 % nudo 4
7.5 % nudo 5
8.9 % nudo 6
11.5 % nudo 7
13.7 % nudo 8
15.0 % nudo 9
];
%
% CON es la matriz de conectividad
CON=[
1 2 % elem 1
2 3 % elem 2
3 4 % elem 3
4 5 % elem 4
5 6 % elem 5
6 7 % elem 6
7 8 % elem 7
8 9 % elem 8
];

% RIG contiene la rigidez de cada muelle
RIG=[
2.0e5 % muelle 1
3.0e5 % muelle 2
4.2e5 % muelle 3
2.7e5 % muelle 4
5.0e5 % muelle 5
3.9e5 % muelle 6
3.1e5 % muelle 7
2.6e5 % muelle 8
];
%
% AMORT contiene el coeficiente de amortiguamiento de cada amortiguador
AMORT=[
0.7e2 % amort 1
1.0e2 % amort 2
0.2e2 % amort 3
0.1e2 % amort 4
1.0e2 % amort 5
0.1e2 % amort 6
0.2e2 % amort 7
0.1e2 % amort 8
];
%
% MASA contiene las masas
MASA=[
4.0e2 % masa 1
7.1e2 % masa 2
2.2e2 % masa 3
3.2e2 % masa 4
5.0e2 % masa 5
4.8e2 % masa 6
1.0e2 % masa 7
5.0e2 % masa 8
3.0e2 % masa 9
];
% 
% inddD es un vector columna que contiene los �ndices de los nudos para los que el desplazamiento es dato. 
inddD=[
1
5
7
];
%

%% Desp, veloc y acel en los nudos de inddD
B1=5e-3;
lambda1=-0.09;
d1=@(t) B1*exp(lambda1*t); % nudo 1;
%
B5=3e-3;
lambda5=-0.07;
C5=2.3e-3;
d5=@(t) B5*exp(lambda5*t)+C5; % nudo 5
%
B7=4e-3;
lambda7=-0.1;
C7=-1.4e-3;
d7=@(t) B7*exp(lambda7*t)+C7; % nudo 7
% derivadas de la d el alummno
v1=@(t) B1*lambda1*exp(lambda1*t); % nudo 1
v5=@(t) B5*lambda5*exp(lambda5*t); % nudo 5
v7=@(t) B7*lambda7*exp(lambda7*t); % nudo 7
% derivadas de v el alumno
a1=@(t) B1*lambda1^2*exp(lambda1*t); % nudo 1
a5=@(t) B5*lambda5^2*exp(lambda5*t); % nudo 5
a7=@(t) B7*lambda7^2*exp(lambda7*t); % nudo 7
%% Fuerza en los nudos en los que F es dato
B2=2e3;
lambda2=-5;
F2=@(t) B2*exp(lambda2*t); % nudo 2
%
B3=-0.4e3;
lambda3=-6;
C3=2e3;
F3=@(t) B3*exp(lambda3*t)+C3; % nudo 3
%
B4=3.2e3;
lambda4=-7;
F4=@(t) B4*exp(lambda4*t); % nudo 4
%
B6=1.3e3;
lambda6=-10;
C6=-2.6e3;
F6=@(t) B6*exp(lambda6*t)+C6; % nudo 6
%
B8=6e3;
lambda8=-4;
F8=@(t) B8*exp(lambda8*t); % nudo 8
%
B9=1e3;
lambda9=-3;
C9=4e3;
F9=@(t) B9*exp(lambda9*t)+C9; % nudo 9

%% handle vectorial a partir de handles escalares
dD=@(t) [
d1(t) % nudo 1
d5(t) % nudo 5
d7(t) % nudo 7
];
%
vD=@(t) [
v1(t) % nudo 1
v5(t) % nudo 5
v7(t) % nudo 7
];
%
aD=@(t) [
a1(t) % nudo 1
a5(t) % nudo 5
a7(t) % nudo 7
];
%
FD=@(t) [
F2(t) % nudo 2
F3(t) % nudo 3
F4(t) % nudo 4
F6(t) % nudo 6
F8(t) % nudo 8
F9(t) % nudo 9
];
%
G=1e15;% una cte grande para el m�todo III (aproximado)
%
%% Condiciones iniciales (en los nudos en que d es inc�gnita)
dInic=[
2.1e-3 % nudo 2
-1.2e-3 % nudo 3
1e-3 % nudo 4
0 % nudo 6
2e-3 % nudo 8
0 % nudo 9    
];
%
vInic=[
-2.1e-1 % nudo 2
0 % nudo 3
1e-1 % nudo 4
0 % nudo 6
-1e-1 % nudo 8
1.2e-1 % nudo 9    
];

tdib=0:1:T;
Fdat=FD(tdib);
figure(1)
plot(tdib,Fdat(1,:),'DisplayName','F_2')
hold on
plot(tdib,Fdat(2,:),'DisplayName','F_3')
plot(tdib,Fdat(3,:),'DisplayName','F_4')
plot(tdib,Fdat(4,:),'DisplayName','F_6')
plot(tdib,Fdat(5,:),'DisplayName','F_8')
plot(tdib,Fdat(6,:),'DisplayName','F_9')
hold off
title('Fuerzas dato como funci�n del tiempo')
xlabel('t')
ylabel('F')
legend show
%%
tdib=0:1:T;
ddat=dD(tdib);
figure(2)
plot(tdib,ddat(1,:),'DisplayName','d_1')
hold on
plot(tdib,ddat(2,:),'DisplayName','d_5')
plot(tdib,ddat(3,:),'DisplayName','d_7')
hold off
title('Desplazamientos dato como funci�n del tiempo')
xlabel('t')
ylabel('d')
legend show
