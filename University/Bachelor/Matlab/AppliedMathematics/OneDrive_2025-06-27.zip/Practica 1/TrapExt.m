function z = TrapecioExtendida(f,a,b,m)
%m=intervalos o m+1 nudos
h=(b-a)/m;
coefs=ones(1,m+1);
coefs(1)=1/2;
coefs(m+1)=1/2;
nudos=a:h:b;
z=h*sum(coefs.*f(nudos))
end

