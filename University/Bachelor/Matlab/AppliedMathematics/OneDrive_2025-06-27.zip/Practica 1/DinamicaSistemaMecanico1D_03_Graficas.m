%% Din�mica para un sistema mec�nico 1D. PARTE 3.
% El programa completo se compone de tres archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: Dinamica_SistemaMecanico1D_01_Datos
% 2. C�lculo del desplazamiento y la fuerza
%    en cada uno de las masas y en cada instante de tiempo: DinamicaSistemaMecanico1D_02_Calculos
% 3. Gr�ficas: DinamicaSistemaMecanico1D_03_Graficas
figure(3)
plot(tdisc,d(1,:),'DisplayName','d_1')
hold on
plot(tdisc,d(2,:),'DisplayName','d_2')
plot(tdisc,d(3,:),'DisplayName','d_3')
plot(tdisc,d(4,:),'DisplayName','d_4')
plot(tdisc,d(5,:),'DisplayName','d_5')
plot(tdisc,d(6,:),'DisplayName','d_6')
plot(tdisc,d(7,:),'DisplayName','d_7')
plot(tdisc,d(8,:),'DisplayName','d_8')
plot(tdisc,d(9,:),'DisplayName','d_9')
hold off
title('Desplazamientos como funci�n del tiempo')
xlabel('t')
ylabel('d')
legend show
%%
figure(4)
plot(tdisc,F(1,:),'DisplayName','F_1')
hold on
plot(tdisc,F(2,:),'DisplayName','F_2')
plot(tdisc,F(3,:),'DisplayName','F_3')
plot(tdisc,F(4,:),'DisplayName','F_4')
plot(tdisc,F(5,:),'DisplayName','F_5')
plot(tdisc,F(6,:),'DisplayName','F_6')
plot(tdisc,F(7,:),'DisplayName','F_7')
plot(tdisc,F(8,:),'DisplayName','F_8')
plot(tdisc,F(9,:),'DisplayName','F_9')
hold off
title('Fuerzas como funci�n del tiempo')
xlabel('t')
ylabel('F')
legend show
%%
figure(5)
plot(tdisc,v(1,:),'DisplayName','v_1')
hold on
plot(tdisc,v(2,:),'DisplayName','v_2')
plot(tdisc,v(3,:),'DisplayName','v_3')
plot(tdisc,v(4,:),'DisplayName','v_4')
plot(tdisc,v(5,:),'DisplayName','v_5')
plot(tdisc,v(6,:),'DisplayName','v_6')
plot(tdisc,v(7,:),'DisplayName','v_7')
plot(tdisc,v(8,:),'DisplayName','v_8')
plot(tdisc,v(9,:),'DisplayName','v_9')
hold off
title('Velocidades como funci�n del tiempo')
xlabel('t')
ylabel('v')
legend show
%%
figure(6)
plot(tdisc,a(1,:),'DisplayName','a_1')
hold on
plot(tdisc,a(2,:),'DisplayName','a_2')
plot(tdisc,a(3,:),'DisplayName','a_3')
plot(tdisc,a(4,:),'DisplayName','a_4')
plot(tdisc,a(5,:),'DisplayName','a_5')
plot(tdisc,a(6,:),'DisplayName','a_6')
plot(tdisc,a(7,:),'DisplayName','a_7')
plot(tdisc,a(8,:),'DisplayName','a_8')
plot(tdisc,a(9,:),'DisplayName','a_9')
hold off
title('Aceleraciones como funci�n del tiempo')
xlabel('t')
ylabel('a')
legend show
