%% Din�mica para un sistema mec�nico 1D. PARTE 2.
% El programa completo se compone de tres archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: Dinamica_SistemaMecanico1D_01_Datos
% 2. C�lculo del desplazamiento y la fuerza
%    en cada uno de las masas y en cada instante de tiempo: DinamicaSistemaMecanico1D_02_Calculos
% 3. Gr�ficas: DinamicaSistemaMecanico1D_03_Graficas

%% C�lculos

s=size(CON,1); % n�mero de elementos
n=length(COOR); % n�mero de nudos
p=length(inddD); % n�mero de componentes en las que el desplazamiento es dato
m=n-p; % n�mero de componentes en las que el desplazamiento es inc�gnita
%
K=zeros(n);% Inicializaci�n
C=zeros(n);% Inicializaci�n
%
format short e
%
M=diag(MASA); %ser� ,matriz diagonal
%% Ensamblaje de K y C
for e=1:s    %
    ke=[RIG(e) -RIG(e); -RIG(e) RIG(e)];
    ce=[AMORT(e) -AMORT(e); -AMORT(e) AMORT(e)];
    
    
    ind=[CON(e,1) CON(e,2)]; %indices donde ensamblar
    K(ind,ind)=K(ind,ind) + ke;
    C(ind,ind)=C(ind,ind) + ce;
    
end
K
C
%%


%% M�TODO III (aproximado)
% Construcci�n de MG, KG y CG  
MG=M;
KG=K;
CG=C;
g=1e15;
for i=1:p
    j=inddD(i);
    MG(j,j)=G;
end
% Construcci�n de FG 
%1, 5 y 7 desplaz dato
FG=@(t) [ 
G*a1(t)
F2(t)
F3(t)
F4(t)
G*a5(t)
F6(t)
G*a7(t)
F8(t)
F9(t)
];

% Construcci�n del vector de condiciones iniciales 
inddI=setdiff(1:n,inddD);% �ndices de las masas en las que el desplazamiento es inc�gnita
d0=zeros(n,1);%inicializaci�n
v0=zeros(n,1);%inicializaci�n
d0(inddD)=dD(0);
d0(inddI)=dInic;
v0(inddD)=vD(0);
v0(inddI)=vInic;
% Funci�n que define el PVI de primer orden
invMG=inv(MG);
f=@(t,z) [z(n+1:2*n); invMG*(FG(t)-KG*z(1:n)-CG*z(n+1:2*n))]; 
% Llamada a ode45 para resolver num�ricamente el PVI
z0=[d0;v0];
[tnum,znum]=ode45(f,[0 T],z0);

d=znum(:,1:n)'; %lo que corresponde a d dentro de znum y traspuesto
v=znum(:,n+1:2*n)'; %lo que corresponde a v dentro de znum y traspuesto

% Desplazamientos y velocidades: la columna j de d contiene
% el desplazamiento de las distintas masas en el instante tdisc(j). Algo
% an�logo para la velocidad (POR HACER)
%

% C�lculo de las aceleraciones a y las fuerzas F en todos los instantes de
% tiempo. (POR HACER) 

