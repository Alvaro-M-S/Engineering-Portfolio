%% M�todo directo de la rigidez para un sistema de muelles unidimensional. PARTE 2
% El programa completo se compone de tres archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: EstaticaSistemaMecanico1D_01_Datos
% 2. C�lculo del desplazamiento y la fuerza en cada uno de los nudos: EstaticaSistemaMecanico1D_02_Calculos
% 3. Dibujo del sistema libre y con carga: EstaticaSistemaMecanico1D_03_Dibujo

%% C�lculos
%
s=size(CON,1); % n�mero de elementos
n=length(COOR); % n�mero de nudos
p=length(inddD); % n�mero de componentes en las que el desplazamiento es dato
m=n-p; % n�mero de componentes en las que el desplazamiento es inc�gnita
%
K=zeros(n);% Inicializaci�n
%
format short e
%

%% Ensamblaje de K (EST� SIN TERMINAR)
for e=1:s %bucle s veces, s elementos, muelles
    % C�lculo y ensamblaje de ke
   ke=[RIG(e) -RIG(e); -RIG(e) RIG(e)];
   %Posibilidad 1
   I=CON(e,1);
   J=CON(e,1);
   K(I,J)=K(I,J)+ke(1,1);   %ensamblaje de ke11 
   %
   I=CON(e,1);
   J=CON(e,2);
   K(I,J)=K(I,J)+ke(1,2);   %ensamblaje de ke12 y de ke21, sim�tricos
   K(J,I)=K(J,I)+ke(1,2);
   %
   I=CON(e,2);
   J=CON(e,2);
   K(I,J)=K(I,J)+ke(2,2);   %ensamblaje de ke22
   %%
   %Posibilidad 2, ensamblaje de golpe
 %  in=[CON(e,1) CON(e,2)]; %saco los indices de la matriz de conectividad
 % para el muelle e . EJemplo muelle 3 ser�an 3, 4
 %  K(in,in)=K(in,in)+ke;
    
end
%% Introducci�n de los datos en Kd=F para construir el sistema "verdadero" K*d=FG (M�todo 3 aproximado) (EST� SIN TERMINAR)
 G=1e15;
 FG=zeros(n,1); %vector columna con n componentes, filas
 inddI=setdiff(1:n,inddD);
 
 FG(inddI,1)=FD;
 
 FG(inddD,1)=G*dD;

 KG=K;
 
 for i=1:p % de 1 al n�mero de componenetes donde desplazamiento es dato, lo que vamos a sustituir, metodo3
   j=inddD(i); %valor de la componente i del vector componentes desplazamiento dato
   KG(j,j)=G;
   %se podr�a unificar en K(inddD(i),inddD(i))=G;
 end
%% Resoluci�n del sistema "verdadero" KG*d=FG y c�lculo de d y F (EST� SIN TERMINAR)
%dMal=inv(KG)*FG;%metodo que no hay que usar

d=KG\FG;%metodo que si hay que usar, desplazamiento aprox

%diferencia=d-dMal;

%% C�lculo de las coordenadas finales de los nudos  y de la deformaci�n en cada muelle (EST� SIN TERMINAR)