A=2;
B=0.02;
C=2e-4;
D=0.8;

f=@(t,z) [A*z(1)-B*z(1)*z(2); C*z(1)*z(2)-D*z(2)];
T=100;
z0=[3000 120]';

[tnum,solnum]=ode45(f,[0 T],z0);

prey=solnum(:,1);
pred=solnum(:,2);

figure(1)
plot(tnum,prey)
figure(2)
plot(tnum,pred)
figure(3)
plot(prey,pred)