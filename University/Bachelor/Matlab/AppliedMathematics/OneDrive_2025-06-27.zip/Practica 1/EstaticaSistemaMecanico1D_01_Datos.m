%% M�todo directo de la rigidez para un sistema de muelles unidimensional. PARTE 1
% El programa completo se compone de tres archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: EstaticaSistemaMecanico1D_01_Datos
% 2. C�lculo del desplazamiento y la fuerza en cada uno de los nudos: EstaticaSistemaMecanico1D_02_Calculos
% 3. Dibujo del sistema libre y con carga: EstaticaSistemaMecanico1D_03_Dibujo
%% Datos (expresados en unidades del sistema internacional). 
%
% COOR es un vector columna que contiene las coordenadas de los nudos (en el sistema sin deformar) 
COOR=[
0.0 % nudo 1
2.4 % nudo 2
3.9 % nudo 3
5.2 % nudo 4
7.5 % nudo 5
8.9 % nudo 6
11.5 % nudo 7
13.7 % nudo 8
15.0 % nudo 9
];
%
% RIG contiene la rigidez de cada muelle (n�mero muelles= n�mero nudos -1)
%
RIG=[
2.0e5 % muelle 1
3.0e5 % muelle 2
4.2e5 % muelle 3
2.7e5 % muelle 4
5.0e5 % muelle 5
3.9e5 % muelle 6
3.1e5 % muelle 7
2.6e5 % muelle 8
];
%
% CON es la matriz de conectividad (para ensamblar)
CON=[
1 2 % muelle 1
2 3 % muelle 2
3 4 % muelle 3
4 5 % muelle 4
5 6 % muelle 5
6 7 % muelle 6
7 8 % muelle 7
8 9 % muelle 8
];
% Nudo = grado de libertad
% inddD es un vector columna que contiene los �ndices de los nudos para los que el desplazamiento es dato. 
inddD=[
1
5
7
];
%
% dD es un vector columna con p componentes que contiene el dato de desplazamiento en los nudos. 
dD=[ 
0.0    % nudo 1
2.3e-3 % nudo 5
-1.4e-3% nudo 7
];
%
% FD (fuerzas datos) es un vector columna con m componentes que contiene el dato de fuerza aplicada en los nudos. 
FD=[
0.0    % nudo 2
2.0e3  % nudo 3
0.0    % nudo 4
-2.6e3 % nudo 6
0.0    % nudo 8
4.0e3  % nudo 9   
];
%
