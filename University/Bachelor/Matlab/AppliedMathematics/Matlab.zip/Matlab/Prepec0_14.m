format short e
rng(1)
A=rand(7,9);
b=rand(7,1);
rangoA=rank(A) %Tendra rango 7 rang(A|b)=7, y ambos es igual al numero de filas. Habra mas incognitas que filas, ser� SCI
xp=A\b; %Ser� una sol particular del sistema
error=norm(b-A*xp) %error peque�o para comprobar si es solucion
%Apartado 2, hallar todas las soluciones: x=xp+cte*nucleo(A) (Combinacion
%lineal con los dos vectores del nucleo(p=n-r(A), p dim del nucleo
%Apatado 3, imponer dichas condiciones para los dos vectores nucleo y
%hallaremos las ctes
% nucleoA=null(A);
%creando un sistema Aampliado y bampliado con las condiciones
Aamp=zeros(9);
bamp=zeros(9,1);
Aamp=A;
Aamp(8,:)=zeros(1,9);
Aamp(8,1)=1;
Aamp(9,:)=zeros(1,9);
Aamp(9,3)=1;
bamp=[b;3;4];
sol=Aamp\bamp
%Apartado 4 igual pero cambiadno las ecuaciones que metemos en Aamp
% fila8=zeros(1,9);
% fila8([3 5 6])=[2 3 -1];
% fila9=zeros(1,9);
% fila9([2 5])=[-2 4];
% Aamp=[A;fila8;fila9];
% bamp=[b;-1;3];
% sol4=Aamp\bamp
% res4=norm(bamp-Aamp*sol4)

