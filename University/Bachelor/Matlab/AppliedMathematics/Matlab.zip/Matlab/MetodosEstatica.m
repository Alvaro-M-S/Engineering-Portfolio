format short e

% Metodo 3 aproximado

indxdato=[2 4];
indbdato=setdiff(1:5,indxdato);

valxdato=[-1 2]';
valbdato=[10 20 15]';
p=length(indxdato);
G=10^9;
A2=A;
b2=zeros(5,1);
b2(indbdato)=valbdato;
for i=1:p
    I=indxdato(i);
    
    A2(I,I)=G;
    
    b2(I)=G.*valxdato(i);
end

x3=A2\b2;
b3=A*x3;

d=A2*x3 %si me piden dato de d siendo el sistema aproximado de Ax=b es A2x=d


% %Metodo 1

indxdato=[2 4];
indbdato=setdiff(1:5,indxdato);

valxdato=[-1 2]';
valbdato=[10 20 15]';
AII=A(indbdato,indbdato);
AID=A(indbdato,indxdato);
ADD=A(indxdato,indxdato);
ADI=A(indxdato,indbdato);

bD=valbdato;
xD=valxdato;

xI=AII\(bD-AID*xD);
bI=ADI*xI+ADD+xD;
q=bD-AID*xD;

x1=zeros(5,1);
x1(indxdato)=valxdato;
x1(indbdato)=xI;

b1=A*x1;

% Metodo 3 Exacto PRACTICA 1

s=size(CON,1); 
n=length(COOR); 
p=length(inddD); 
m=n-p; 
K=zeros(n);

for e=1:s
    ke=[RIG(e) -RIG(e); -RIG(e) RIG(e)];
    indices=CON(e,:);
    K(indices,indices)=K(indices,indices)+ke;
end

Kaux=K;
Faux=zeros(n,1);

indFD=[2 3 4 6 8 9];
Faux(indFD)=FD;
for i=1:p
    I=inddD(i);
    Kaux(I,:)=0;
    Kaux(I,I)=1;
    Faux(I)=dD(i);
end
d=Kaux\Faux;
F=K*d;
