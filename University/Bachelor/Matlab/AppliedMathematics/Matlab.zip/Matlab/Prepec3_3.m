format short e
xnudos=[-3/5;0;3/5];
%Apartado1(cuadratura interpolatoria al menos debe integrar de forma exacta
%los polinomios de grado n-1, en este caso 2)
A=@(x) [ones(length(x),1) x x.^2];
intpn=[2;0;2/3];
coefs=A(xnudos)\intpn