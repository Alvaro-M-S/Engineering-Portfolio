format short e
w=1.5;
w2=2*w;
%Apartado2
xdat =[
-2.9282
-2.4309
-1.7790
-1.2486
-0.3315
];
ydat =[
2.6308
6.2477
4.7617
-2.3037
0.8645
];
A=@(x) [ones(length(x),1) cos(w*x) sin(w*x) cos(w2*x) sin(w2*x)];
coefs=A(xdat)\ydat;
xeval=[0.17;2.13;4.25];
Aeval=A(xeval);
teval=Aeval*coefs