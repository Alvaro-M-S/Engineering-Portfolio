rng(1)
A=rand(20,20);
b=rand(20,1);
C=A;
C(:,[3 5 9])=[];
c=b;
ind=find(abs(c)<0.3);
c(ind)=0;
x=C\c;
norma1=norm(x,1)