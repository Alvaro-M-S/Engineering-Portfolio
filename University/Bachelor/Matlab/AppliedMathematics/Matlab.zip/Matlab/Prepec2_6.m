format short e
xdat =[
-2.9282
-2.4309
-1.7790
-1.2486
-0.3315
];
ydat =[
2.6308
6.2477
4.7617
-2.3037
0.8645
];
%Apartado2
columna1=ones(5,1);
columna2=xdat;
columna3=xdat.^2;
columna4=xdat.^3;
columna5=xdat.^4;
A=[columna1 columna2 columna3 columna4 columna5];
b=ydat;
coefs=A\b;
yinterp=A*coefs;
%Apartado3
xeval=[0.17;2.13;4.25];
p=@(x) [ones(length(x),1) x x.^2 x.^3 x.^4];
psol=(p(xeval)*coefs)'
%Apartado4
num1=@(x) (x-xdat(2)).*(x-xdat(3)).*(x-xdat(4)).*(x-xdat(5));
den1=num1(xdat(1));
N1=@(x) num1(x)/den1;
N2=@(x) ((x-xdat(1)).*(x-xdat(3)).*(x-xdat(4)).*(x-xdat(5)))/((xdat(2)-xdat(1)).*(xdat(2)-xdat(3)).*(xdat(2)-xdat(4)).*(xdat(2)-xdat(5)));
num3=@(x) (x-xdat(1)).*(x-xdat(2)).*(x-xdat(4)).*(x-xdat(5));
den3=num3(xdat(3));
N3=@(x) num3(x)/den3;
num4=@(x) (x-xdat(1)).*(x-xdat(2)).*(x-xdat(3)).*(x-xdat(5));
den4=num4(xdat(4));
N4=@(x) num4(x)/den4;
num5=@(x) (x-xdat(1)).*(x-xdat(2)).*(x-xdat(3)).*(x-xdat(4));
den5=num5(xdat(5));
N5=@(x) num5(x)/den5;
N=@(x) [N1(x) N2(x) N3(x) N4(x) N5(x)];
N(xeval);
%Apartado5
peval=N(xeval)*ydat
