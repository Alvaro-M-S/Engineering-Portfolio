format short e
rng(1)
A=10*rand(14);
b=12*rand(11,1);
%Para eliminar filas:
C=A;
C([3 5 9],:)=[];
C(:,[3 5 9])=[];
d=b;
%Buscar en b numeros menores de 4:
ind=find(b<4);
d(ind)=0;
x=C\d;
sol=norm(x,1)


