format short e
COOR=[0 30 60 80 100]';
MASA=[4e5 7.1e5 2.2e5 3.2e5 2.7e5]';
RIG=[2e5 3e5 4.2e5 2.7e5]';
AMORT=[70 100 20 10]';
indxdespdato=[2 4];
indxfdato=setdiff(1:5,indxdespdato);
n=length(MASA); %Numero de nudos
ndd=length(indxdespdato);%numero de despdato

%Datos
d2D=@(t) 0*t;
d4D=@(t) -9.2e-2*cos(0.2*t);
dD=@(t) [d2D(t);d4D(t)];

v2D=@(t) 0*t;
ctev4D=0.2*9.2e-2;
v4D=@(t) ctev4D*sin(0.2*t);
vD=@(t) [v2D(t); v4D(t)];

a2D=@(t) 0*t;
ctea4D=0.2*0.2*9.2e-2;
a4D=@(t) ctea4D*cos(0.2*t);
aD=@(t) [a2D(t);a4D(t)];

f1D=@(t) 2e3*cos(0.5*t);
f3D=@(t) -1.3e3*cos(0.2*t);
f5D=@(t) 0*t;
fD=@(t) [f1D(t);f3D(t);f5D(t)];

%Apartado1(M,C y K)
M=diag(MASA);
E=n-1; %Numero elementos totales
CON=[1 2;2 3;3 4;4 5];
K=zeros(n);
C=zeros(n);
for e=1:E
ke=[RIG(e) -RIG(e); -RIG(e) RIG(e)];
ce=[AMORT(e) -AMORT(e); -AMORT(e) AMORT(e)];

I=CON(e,1);
J=CON(e,2);
    
K(I,I)=K(I,I)+ke(1,1);
K(I,J)=K(I,J)+ke(1,2);
K(J,I)=K(I,J);
K(J,J)=K(J,J)+ke(2,2);

C(I,I)=C(I,I)+ce(1,1);
C(I,J)=C(I,J)+ce(1,2);
C(J,I)=C(I,J);
C(J,J)=C(J,J)+ce(2,2);
end
%Apartado2(Metodo 3 exacto)
T=100;
ME=M;
for ad=1:ndd
ME(indxdespdato(ad),indxdespdato(ad))=1;
end
KE=K;
CE=C;
KE(indxdespdato,:)=0;
CE(indxdespdato,:)=0;
FE=@(t)[
f1D(t)
a2D(t)
f3D(t)
a4D(t)
f5D(t)
];

%Vector cond iniciales
d0=zeros(5,1);
v0=zeros(5,1);
d0(indxfdato,1)=[2.1e-2;-1.2e-2;1e-2];
v0(indxfdato,1)=[-1.7e-1;0;1e-1];
d0(indxdespdato,1)=dD(0);
v0(indxdespdato,1)=vD(0);

z0=[d0;v0];

%f a partir de despejar a de  la ecuacion M*a +C*v +K*d=F, para ello usar
%z(zprimerasn los d, z(n+1 a 2n) los v)
MEinv=inv(ME);
f=@(t,z) [z(n+1:2*n); MEinv*(FE(t)-KE*z(1:n)-CE*z(n+1:2*n))];

%Funcion para resolver el problema
[tnum,znum]=ode45(f,[0,T],z0);


%Hallar d,v,a,F a partir de los resuleto
dsol=znum(:,1:n)';
vsol=znum(:,(n+1):2*n)';
dsol(:,length(dsol))
vsol(:,length(vsol))
 
asol=MEinv*(FE(tnum')-KE*dsol-CE*vsol);
asol(:,length(asol))

Fsol=M*asol+C*vsol+K*dsol;
Fsol(:,length(Fsol))

