format short e
rng(3)
A=rand(10,5);
b=rand(10,1);
rangoA=rank(A) %Dando rangoA=5 e igual a rang(A|b)=5, rango max.SCD (una �nica sol x=A\b)
sol=A\b
error=norm(b-A*sol)

