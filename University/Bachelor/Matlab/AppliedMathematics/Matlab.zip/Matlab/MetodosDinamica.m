% Ensamblajes

M=diag(M);
s=size(CON,1); 
n=length(COOR);
p=length(inddD); 
m=n-p; 

K=zeros(n);
C=zeros(n);

for e=1:s    
    ke=[RIG(e) -RIG(e); -RIG(e) RIG(e)];
    indices=[CON(e,1) CON(e,2)];
    K(indices,indices)=K(indices,indices)+ke;
    
    ce=[AMORT(e) -AMORT(e); -AMORT(e) AMORT(e)];
    C(indices,indices)=C(indices,indices)+ce;
end

inddI=setdiff(1:n,inddD);
d0=zeros(n,1);
v0=zeros(n,1);
d0(inddD)=dD(0);
d0(inddI)=dInic;
v0(inddD)=vD(0);
v0(inddI)=vInic;

z0 = [d0;v0];


% Metodo 3 aproximado con G=...


FG=@(t) [
F1(t)
a2*G(t)
F3(t)
a4*G(t)
F5(t)
];


MG=M;
KG=K;
CG=C;

for i=1:p
    MG(inddD(i),inddD(i))=G;

end

X=inv(M);
f=@(t,z) [z(n+1:2*n);X*(FG(t)-KG*z(1:n)-CG*z(n+1:2*n))];
z0=[d0;v0];
[tdisc,znum]=ode45(f,[0,T],z0);

d=znum(:,1:n);
v=znum(:,(n+1):2*n)';
a=inv(MG)*(FG(tnum')-KG*d-CG*v);
F=M*a+K*d+C*v;


% Metodo 3 exacto

F=@(t) [
F1(t)
a2(t)
F3(t)
a4(t)
F5(t)
];


M3=M;
C3=C;
K3=K;
M3(inddD,:)=0;
K3(inddD,:)=0;
C3(inddD,:)=0;
for i=1:length(inddD)
    M3(inddD(i),inddD(i))=1;    
end

f3=@(t,z) [z(n+1:2*n); inv(M3)*(F(t)-K3*z(1:n)-C3*z(n+1:2*n))];

[tnum, znum]=ode45(f3,[0 T],z0);

d3=znum(:,1:n)';
v3=znum(:,n+1:2*n)';
a3=inv(M3)*(F(tnum')-K3*d3-C3*v3);
F3=M*a3+K*d3+C*v3;
