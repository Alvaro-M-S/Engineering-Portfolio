format short e
f=@(x) x.^5.*sin(x).*exp(-x.^2);
TrapecioExtendida(f,0,3,6)
SimpsonExtendida(f,0,3,3)
