format short e
A=[
9 3 2 10 5
-3 -4 -4 -7 -10
2 5 9 6 10
9 10 21 14 15
8 4 7 9 5
];
indxdato=[2 4];
indbdato=setdiff(1:5,indxdato);
valxdato=[-1 2]';
valbdato=[10 20 15]';
%Metodo3(Hacer la igualdad a partir de G)
G=1e+9;
C=A;
C(indxdato(1),indxdato(1))=G;
C(indxdato(2),indxdato(2))=G;
d=zeros(5,1);
d(indbdato,1)=valbdato;
d(indxdato,1)=valxdato.*G;
x=C\d
b=A*x
b(4)
%Metodo1
bD=valbdato;
xD=valxdato;
AII=A(indbdato,indbdato);
AID=A(indbdato,indxdato);
ADI=A(indxdato,indbdato);
ADD=A(indxdato,indxdato);
xI=AII\(bD-AID*xD)
q=(bD-AID*xD);
q(2)
xsol=zeros(5,1);
xsol(indxdato,1)=valxdato;
xsol(indbdato,1)=xI;
xsol
b1=A*xsol
b1(4)