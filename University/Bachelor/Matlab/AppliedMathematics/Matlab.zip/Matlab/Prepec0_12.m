format short e
rng(5)
A=rand(29,29);
b=rand(29,1);
rangoA=rank(A)
C=A;
c=b;
for e=16:28 
C(e,:)=A(e+1,:);
c(e,1)=b(e+1,1);
end
rangoC=rank(C) %saldr� 28, siendo una matriz 28x29, por lo que habr�a mas incognitas que ecuaciones. SCI. Por tanto: x=xparticular + landa*nucleo(c)
xp=C\c;
nucleo=null(C);
%Para hallar el landa, impondremos la condici�n de x(3)=0. Despejando:
%xp(3)+landa*nucleo(3)=0
landa=(-xp(3))/nucleo(3);
sol=norm(xp+landa*nucleo,1)
