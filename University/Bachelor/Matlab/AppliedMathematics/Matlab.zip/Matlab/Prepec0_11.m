format short e
rng(5)
A=rand(10,10);
B=rand(10,1);
x=A\B;
y=A*x;
error=norm(B-y)