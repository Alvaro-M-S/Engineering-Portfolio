function [z,n]=TrapecioExtendida(fun,a,b,m)
n=m+1; %nudos con m=intervalos
long=b-a; %longitud del intervalo
h=long/m; %distancia entre numero de intervalos
xnudos=a:h:b; %genera el vector con las posiciones de los nudos equidistanciados
fennudos=fun(xnudos); %evalua la funcion en los nudos
coef=ones(1,n);
coef(1)=0.5;
coef(n)=0.5;
z=h*sum(coef.*fennudos); %forma de poner prod escalar sum(algo.*algo)