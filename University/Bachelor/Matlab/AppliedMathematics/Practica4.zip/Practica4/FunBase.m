function [funbase,derfunbase]=FunBase(psi,a)
%% Funciones de base y sus derivadas para el elemento estandar [-1,1]
% psi es un vector  fila en el que cada elemento representa un punto.
% funbase es una matriz en la que la fila i contiene el valor de la funcion
% de forma i en los puntos definidos por psi.
% derfunbase es una matriz en la que la fila i contiene el valor de la
% derivada de la funcion de forma i en los puntos definidos por psi.
% a=1 indica que el elemento es lineal
% a=2 indica que el elemento es cuadratico
% a=3 indica que el elemento es cubico de Lagrange
numpuntos=size(psi,2);
if a==1 %verdad si el elemento es lineal
    funbase=zeros(2,numpuntos);
    funbase(1,:)=(1/2)*(1-psi);
    funbase(2,:)=(1/2)*(1+psi);
    %
    derfunbase=zeros(2,numpuntos);
    derfunbase(1,:)=-1/2*ones(size(psi));
    derfunbase(2,:)=1/2*ones(size(psi));
elseif a==2  %verdad si el elemento es cuadratico
    funbase=zeros(3,numpuntos);
    funbase(1,:)=(1/2)*psi.*(psi-1);
    funbase(2,:)=1-psi.^2;
    funbase(3,:)=(1/2)*psi.*(psi+1);
    %
    derfunbase=zeros(3,numpuntos);
    derfunbase(1,:)=psi-1/2;
    derfunbase(2,:)=-2*psi;
    derfunbase(3,:)=psi+1/2;     
elseif a==3  %verdad si el elemento es cubico de lagrange
    funbase=zeros(4,numpuntos);
    funbase(1,:)=-(9/16)*(psi+1/3).*(psi-1/3).*(psi-1);
    funbase(2,:)=(27/16)*(psi+1).*(psi-1/3).*(psi-1);
    funbase(3,:)=(-27/16)*(psi+1).*(psi+1/3).*(psi-1);
    funbase(4,:)=(9/16)*(psi+1).*(psi+1/3).*(psi-1/3);
    %
    derfunbase=zeros(4,numpuntos);
    derfunbase(1,:)=(-27/16)*psi.^2+(9/8).*psi+1/16;
    derfunbase(2,:)=81/16*psi.^2-(9/8).*psi-27/16;
    derfunbase(3,:)=-81/16*psi.^2-(9/8).*psi+27/16;
    derfunbase(4,:)=27/16*psi.^2+(9/8).*psi-1/16;
end

