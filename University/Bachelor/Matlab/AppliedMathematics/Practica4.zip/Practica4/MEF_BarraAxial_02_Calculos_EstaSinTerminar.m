%% MEF para una barra axial. PARTE 2. C�LCULOS
% El programa completo se compone de dos archivos, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: MEF_BarraAxial_01_Datos_ALUMNOS
% 2. Procesado: C�lculo de dbarra (desplazamiento aproximado en todos los
% nudos): MEF_BarraAxial_02_Calculos_ALUMNOS. Este programa a su vez hace
% llamadas a un function file externo:
% - FunBase: para cada tipo de elemento, proporciona el valor de las funciones de base del elemento est�ndar y de sus derivadas evaluadas en los puntos que se deseen. 
%% C�lculos
%
format short e
s=size(CON,1); % n�mero de elementos
n=length(COOR); % n�mero de nudos
p=length(inddD); % n�mero de componentes en las que el desplazamiento es dato
m=n-p; % n�mero de componentes en las que el desplazamiento es inc�gnita
%
Kbarra=zeros(n);% Inicializaci�n
Fbarra=zeros(n,1);% Inicializaci�n

%% Nudos de integraci�n en el intervalo est�ndar [-1,1]. Usaremos integraci�n gaussiana con 3 nudos.
 gamma=0.774596;
 psiint=[-gamma 0 gamma]; %cada nudo es una componente de psiint
 coefint=[5/9, 8/9, 5/9]; %vector con los coeficientes
 
%% Ensamblaje de la contribuci�n de la fuerza distribuida a Kbarra y a Fbarra
for e=1:s
tipo=TIPELEM(e);
ngl=tipo+1;
%
%Cambio
a=(MALLA(e+1)-MALLA(e))/2;
b=(MALLA(e+1)+MALLA(e))/2;
xint=a*psiint+b;
[Ngorro,Ngorroder]=FunBase(psiint,tipo);
fenxint=FuerzaDist(xint);
ModElastEnxint=ModElast(xint);
AreaEnxint=Area(xint);
 for i=1:ngl
    %calcular feibarra (provisional/sinfuerzas puntuales) y ensamblar en Fbarra
    feibarra=a*sum(coefint.*fenxint.*Ngorro(i,:));
    I=CON(e,i);
    Fbarra(I)=Fbarra(I)+feibarra;
     for j=i:ngl %i en vez de 1 para ahorrar tiempo
     %calcular keij y ensamblar en Kbarra
     keij=sum(coefint.*AreaEnxint.*ModElastEnxint.*Ngorroder(i,:).*Ngorroder(j,:))/a;
     J=CON(e,j);
     Kbarra(I,J)=Kbarra(I,J)+keij;
     if i~=j %i distinto de j
     Kbarra(J,I)=Kbarra(J,I)+keij;
     end
     end 
  end
end

%% Incorporacion al vector Fbarra de las contribuciones de Fpunt (fuerzas puntuales + condiciones Neumman + condiciones Robin)
nfuerpunt=size(Fpunt,1); %numero total de fuerzas puntuales (incluidas las de Neumann)
for k=1:nfuerpunt    
   ck=Fpunt(k,1);
   Fck=Fpunt(k,2);
   e=max(find(ck<=MALLA,1)-1,1);
   %
   a=(MALLA(e+1)-MALLA(e))/2;
   b=(MALLA(e+1)+MALLA(e))/2;
   psick=(ck-b)/a;
   tipo=TIPELEM(e);
   Ngorro=FunBase(psick,tipo);
   for i=1:(tipo+1)
       q=Fck*Ngorro(i);
       I=CON(e,i);
       Fbarra(I)=Fbarra(I)+q;
   end
end %fin del bucle para las fuerzas puntuales 

%% Incorporacion a Kbarra de las contribuciones de las condiciones de Robin (almacenadas en indCondRobin y valorCCondRobin)
% EST� SIN HACER

%% USO DEL M�TODO III exacto. Introducci�n de los datos en Kbarra*dbarra=Fbarra para construir
% el sistema "verdadero" Kaux*dbarra=Faux (M�todo 3 exacto)

Kaux*dbarra=Faux
%% Resoluci�n del sistema "verdadero" Kaux*dbarra=Faux
dbarra=Kaux\Faux % c�lculo de los desplazamientos en los nudos

%% C�lculo de las coordenadas finales de los nudos
COORTrasDeformacion=COOR+dbarra; % coordenadas de los nudos tras cargar
