%% MEF para una barra axial. PARTE 1. DATOS
% El programa completo se compone de dos archivos script, que hay que ejecutar en orden:
% 1. Introducci�n de los datos: MEF_BarraAxial_01_Datos.
% 2. Procesado: C�lculo de dbarra (desplazamiento aproximado en todos los
% nudos): MEF_BarraAxial_02_Calculos. Este programa a su vez hace
% llamadas a un function file externo:
% - FunBase: para cada tipo de elemento, proporciona el valor de las funciones de base del elemento est�ndar y de sus derivadas evaluadas en los puntos que se deseen. 
%% Datos (expresados en unidades del sistema internacional). 
% L: longitud de la barra
L=1;
% MALLA es un vector fila con las coordenadas de los puntos que definen los elementos
MALLA=[0 0.2 0.5 0.7 0.85 1];
% TIPELEM vector columna con tantas componentes como elementos y en el que su componente i especifica el tipo del elemento i
%        - 1 indica elemento lineal
%        - 2 indica elemento cuadratico (nudos equiespaciados)
%        - 3 indica elemento cubico de Lagrange (nudos equiespaciados)
TIPELEM=[
1 % elemento 1
2 % elemento 2
3 % elemento 3
2 % elemento 4
3 % elemento 5
];
%
% COOR es un vector columna que contiene las coordenadas de los nudos (en el sistema sin deformar) 
COOR=[
0          % nudo 1
0.2        % nudo 2
0.35       % nudo 3
0.5        % nudo 4
0.5667     % nudo 5
0.6333     % nudo 6
0.7        % nudo 7
0.775      % nudo 8
0.85       % nudo 9
0.90       % nudo 10
0.95       % nudo 11
1          % nudo 12
];
%
% CON es la matriz de conectividad
CON=[
1 2 0 0   % elemento 1
2 3 4 0   % elemento 2
4 5 6 7   % elemento 3
7 8 9 0    % elemento 4
9 10 11 12 % elemento 5
];
% 
% indD es un vector columna que contiene los �ndices de los nudos para los que el desplazamiento es dato. 
inddD=[
1 % �ndice del primer nudo para el que el desplazamiento es dato (condici�n esencial)
12 % �ndice del segundo nudo para el que el desplazamiento es dato (condici�n esencial)
];
%
% dD es un vector columna con las mismas dimensiones de indD que contiene el dato de desplazamiento en los nudos cuyos �ndices estan en inddD. 
dD=[ 
1.7e-3    % desplazamiento en el primer nudo para el que el desplazamiento es dato (condici�n esencial)
2.3e-3  % desplazamiento en el segundo nudo para el que el desplazamiento es dato (condici�n esencial)
];
%
% Las condiciones de Robin son del tipo: 
% * Cau(a)-A(a)E(a)u'(a)=Ra (en el extremo de la izquierda)
% * Cbu(b)+A(b)E(b)u'(b)=Rb (en el extremo de la derecha)
% Los t�rminos Ra y Rb se deben incluir en Fpunt para ensamblarlos en
% Fbarra, pues se comportan como fuerzas puntuales aplicadas en a y en b respectivamente.
% Los t�rminos Ca y Cb se ensamblan en Kbarra.
indCondRobin=[]; % �ndices de los nudos en los que hay condiciones de Robin
valorCCondRobin=[]; % valor de C en los nudos en los que hay condiciones de Robin
%
% Fpunt: es una matriz con dos columnas. Cada fila contiene la coordenada en la que se aplica 
%          una fuerza puntual y el valor de dicha fuerza puntual. Esta
%          matriz ya incluye el valor de las condiciones de Neumann
%          (fuerzas puntuales aplicadas en los extremos) y de los valores
%          de R correspondientes a las condiciones de Robin
Fpunt=[
    0.55 2e7  % Fuerza 1
    0.3 2.2e7 % Fuerza 2
    ];
%
% Fuerza distribuida, m�dulo de elasticidad y �rea secci�n.
FuerzaDist=@(x) 2e6*(1+cos(x)-1.5*exp(x.^2));
ModElast=@(x) 1.2e9*(1-(x-0.5).^2);
Area=@(x) 1*ones(size(x)); % n�tese la sintaxis que se utiliza para que Area se pueda evaluar en un vector componente a componente. 



