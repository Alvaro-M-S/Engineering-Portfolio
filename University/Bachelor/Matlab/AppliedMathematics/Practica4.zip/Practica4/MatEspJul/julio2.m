fromat short e
MALLA=[0 0.2 0.5 0.8 1];
CON=[
1 2 3;
3 4 5;
5 6 7;
7 8 9
];
COOR=[0 0.1 0.2 0.35 0.5 0.65 0.8 0.9 1];

L=1;
a=1/2;
b=1/2;
cambiovar=@(x) a.*x+b;
nudoscuadrat
psi=cambiovar