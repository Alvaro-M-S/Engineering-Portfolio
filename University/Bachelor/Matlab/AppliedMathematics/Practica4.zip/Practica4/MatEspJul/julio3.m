%% DATOS

T=100;% instante final en la simulaci�n

%

inddD=[2 4];

inddI=[1 3 5];

%

dInicdI=[

1.4e-2 % nudo 1

-2.1e-2 % nudo 3

1.3e-2 % nudo 5

];

%

vInicdI=[

1.3e-1 % nudo 1

-1.1e-1 % nudo 3

0.9e-1 % nudo 5

];

%% Desp, veloc y acel en los nudos de inddD

d2=@(t) 1e-3+0*t; % nudo 2;

v2=@(t) 0*t; % nudo 2;

a2=@(t) 0*t; % nudo 2;

%

A4=-6.3e-2;

omega4=0.3;

%

d4=@(t) A4*cos(omega4*t); % nudo 4;

v4=@(t) -A4*omega4*sin(omega4*t); % nudo 4

a4=@(t) -A4*omega4^2*cos(omega4*t); % nudo 4

%% Fuerza en los nudos en que d es inc�gnita

A1=2.5e3;

omega1=0.4;

lambda1=-0.09;

F1=@(t) A1*cos(omega1*t); % nudo 1

%

A3=1.7e3;

omega3=0.2;

F3=@(t) A3*cos(omega3*t); % nudo 3

%

F5=@(t) 0*t;

%% Matrices K, M y C

K =[200000 -200000 0 0 0

-200000 400000 -200000 0 0

0 -200000 560000 -360000 0

0 0 -360000 670000 -310000

0 0 0 -310000 310000];

M =[ 600000 0 0 0 0

0 240000 0 0 0

0 0 310000 0 0

0 0 0 160000 0

0 0 0 0 220000 ];

C =[

75 -75 0 0 0

-75 170 -95 0 0

0 -95 113 -18 0

0 0 -18 30 -12

0 0 0 -12 12];

format short e

G=1e15;

Maux=M;
Kaux=K;
Caux=C;

l=length(inddD);

for i=1:l
    
    Maux(inddD(i),inddD(i))=G;
    Kaux(inddD(i),inddD(i))=G;
    Caux(inddD(i),inddD(i))=G;
    
end 


a=norm(Kaux)
b=norm(Maux)



%zp= @(t,z) [z(2); (Faux -Caux.*z(2) - Kaux.*z(1))/Maux];

%[ts, ds]=ode45(zp,[0 T],[])