function Dynamics_LagrangeEquations_Modelo3_1_18240(Model) 

     close all 
     clc 

     %% General variables 

     Model = 'Modelo3_1_18240';

     neq = 1; 
     ngdl = 1; 
     neqBG = 0; 

     % Model parameters 
     Param= Parameters_Modelo3_1_18240(0,zeros(1,1));

     y10= Param.y10;
 
     %% Define initial conditions 
     q = [0.35]; 

     t = 0;
     %% Solve mechanism initial position 
     figure('Name', 'Initial position dined by the user', 'Color', 'white'); 
     Animation_Modelo3_1_18240(q);

     S = Displacements_(Model, q, t); 
     q0 = S; 
     figure('Name', 'Adjusted initial postion', 'Color', 'white'); 
     Animation_Modelo3_1_18240(S);

     %% Number of differential-agebraic equations to be solved 
     numberofDAEequations = 2*neq+(neq-ngdl)+neqBG; 

     %% Initial conditions for dynamic analysis 
     x = zeros(numberofDAEequations,1); 

     xp=zeros(numberofDAEequations,1); 
     fixed_x0=zeros(numberofDAEequations,1); 
     fixed_xp0=zeros(numberofDAEequations,1); 

     tspan = [0:0.02:10]; 

     x = zeros(numberofDAEequations,1);  
     x(neq+1:2*neq)= q0; %% Initial position  
     xp=zeros(numberofDAEequations,1);  
     fixed_x0=zeros(numberofDAEequations,1);  
     fixed_xp0=zeros(numberofDAEequations,1);  

     solver = 'ode23t'; 
     y0_guess = x;    
     yp_guess = zeros(numberofDAEequations,1); 
     % Model responding to the form Mq'=f(t,q) 
     % with Differential Algebraic Equations (DAE) 
     % The function f(t,q) uses the semiexplicit equations form
     MassMatrixLagrange = str2func(sprintf('MassMatrixLagrange_%s',Model)); 
     Systemode23t_Lagrange = str2func(sprintf('eqLagrangeSemiexplicit_%s',Model)); 
     ImplicitDAE = @(time,y,yp) MassMatrixLagrange(q0,time,y)*yp - Systemode23t_Lagrange(q0,time,y);
     [x_0,xp_0,resnrm] = decic(ImplicitDAE,0,x,fixed_x0,xp,fixed_xp0); %Determine consistent yp0
     options = odeset('Mass', @(time,y) MassMatrixLagrange(q0,time,y), 'InitialSlope', xp_0, 'RelTol',1.0e-3, 'AbsTol', 1.0e-5);
     [t1,x] = ode23t(@(time,y) Systemode23t_Lagrange(q0,time,y), tspan, x_0, options);

     tini=tspan(1);
     tend=tspan(end);
     deltat=(tend-tini)/(length(tspan)-1);
     xp= diff(x,1,1)/deltat;
     xp(end+1,:)= xp(end,:);

     h = now;
     dir = pwd;
     save Modelo3_1_18240;

     %% Plots for Dynamics 
     figure('Name', 'x-y plots for Dynamics', 'Color', 'white'); 
     Subplots_Dynamics_Modelo3_1_18240(q0,t1,x,xp);

     figure('Name', 'x-y plots for Energy', 'Color', 'white'); 
     Subplots_Energy_Modelo3_1_18240(q0,t1,x);

     %% Dynamics Animation 
     figure('Name', 'Dynamics Animation', 'Color', 'white'); 
     Animation_Modelo3_1_18240(x(:,neq+1:2*neq)');

end

function equations = eqLagrangeSemiexplicit_Modelo3_1_18240(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo3_1_18240(t,x);

       K1= Param.K1;
       M1= Param.M1;
       R1= Param.R1;
       g= Param.g;
       y10= Param.y10;


 %% Semiexplicit Equations 
       equations(1,1) = K1*y10 - K1*x(2) - M1*g - R1*x(1); 
       equations(2,1) = x(1); 

       dispstat(sprintf('  t = %8.2f',t));
 
end 

function Mass_equations = MassMatrixLagrange_Modelo3_1_18240(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo3_1_18240(t,x);

       M1= Param.M1;

 %% Mass Matrix for Lagrange Equations 
       Mass_equations(1,:) = [ M1, 0];
       Mass_equations(2,:) = [ 0, 1];
 
end 

function equations = eqLagrangeExplicit_Modelo3_1_18240(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo3_1_18240(t,x);

       K1= Param.K1;
       M1= Param.M1;
       R1= Param.R1;
       g= Param.g;
       y10= Param.y10;


 %% Explicit Equations 
       equations(1,1) = -(M1*g + K1*x(2) - K1*y10 + R1*x(1))/M1; 
       equations(2,1) = x(1); 

       dispstat(sprintf('  t = %8.2f',t));
 
end 

function U = Subplots_Dynamics_Modelo3_1_18240(x_0,t,x_,xp_)

     %% Model parameters 
     Param= Parameters_Modelo3_1_18240(t,x_);

 
 %% Subplots definition 

     subplot(3,1,1);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = x_(i,2);
     end
     plot(X_,Y_);
     xlabel('Tiempo (s)');
     title('Desplazamiento y cuerpo 1 (m)');
     grid

     subplot(3,1,2);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = x_(i,1);
     end
     plot(X_,Y_);
     xlabel('Tiempo (s)');
     title('Velocidad y cuerpo 1 (m/2)');
     grid

     subplot(3,1,3);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,1);
     end
     plot(X_,Y_);
     xlabel('Tiempo (s)');
     title('Aceleracion y cuerpo 1 (m/s2)');
     grid

 
end 

function U = Subplots_Energy_Modelo3_1_18240(x_0,t,x)

     for i=1:size(x,1)
     %% Model Parameters 
         Param= Parameters_Modelo3_1_18240(t(i),x(i,:));

         M1= Param.M1;
         R1= Param.R1;
         K1= Param.K1;
         M1= Param.M1;
         g= Param.g;
         y10= Param.y10;
 
         X(i) = t(i);
         YT(1, i) = (M1*x(i,1)^2)/2;
         YV(1, i) = M1*g*x(i,2);
         YV(2, i) = (K1*(y10 - x(i,2))^2)/2;
         YR(1, i) = (R1*x(i,1)^2)/2;
     end
 %% Energy subplots 

     subplot(3,2,1);
     title('Kinetic Energy');
     hold on;
     plot(X, YT(1,:));
     T_Tot = sum(YT,1);
     grid on
     box on
     legend('T1');
     hold off

     subplot(3,2,2);
     title('Potential Energy');
     hold on;
     V_Tot = sum(YV,1);
     plot(X, YV(1,:), X, YV(2,:));
     grid on
     box on
     legend('V1', 'V2');
     hold off

     subplot(3,2,3);
     title('Disipative Energy');
     hold on;
     plot(X, YR(1,:));
     R_Tot = sum(YR,1);
     legend('R1');
     grid on
     box on
     hold off

     subplot(3,2,4);
     title('Energy in couplings');
     hold on;
     Force_Tot = 0;
     grid on
     box on
     hold off

     subplot(3,2,[5,6]);
     title('Total Energy');
     hold on;
     plot(X, T_Tot);
     plot(X, V_Tot);
     plot(X, T_Tot+V_Tot);
     plot(X, T_Tot+V_Tot+R_Tot);
     plot(X, T_Tot+V_Tot+R_Tot+Force_Tot,'LineWidth',2,'Color','red')
     grid on
     box on
     legend('T','V','T+V','T+V+R','T+V+R+F');
     hold off

 
end 

function Animation_Modelo3_1_18240(y) 

%% Model parameters 
     t=0; x=0; 
     Param= Parameters_Modelo3_1_18240(t,x);
     l= Param.l;
     y10= Param.y10;
     d= Param.d;
     l= Param.l;
     l= Param.l;

%% Bodies to be animated 
     Body{1} = [ d, 0.1, d, 0; 
                 d, 0, -1.1*d, 0; 
                 -1.1*d, 0, -1.1*d, 0.1; 
                 -1.1*d, 0.1, d, 0.1]; 

     Body{2} = [ l, 0.01, l, -0.01; 
                 l, -0.01, -l, -0.01; 
                 -l, -0.01, -l, 0.01; 
                 -l, 0.01, l, 0.01]; 

     Body{3} = [ l, 0.01, l, -0.01; 
                 l, -0.01, -l, -0.01; 
                 -l, -0.01, -l, 0.01; 
                 -l, 0.01, l, 0.01]; 

     NumberOfBodies = length(Body);
     NumberOfLines = 1;

 %% Animation viewport 
     axis equal 
     axis ([ -1.5 1.5 0 1]);
     grid on 

     definecolor = {'r' 'g' 'b' 'm' 'k' 'r'}; 

% Begin Animation
     y = transpose(y);
     sizeoft=size(y,1);
     for j=1:NumberOfBodies
         bodydraw{j}=line(zeros(size(Body{j},1)),zeros(size(Body{j},1)));
     end
     for j=1:1
         linedraw{j}=line(zeros(1,1),zeros(1,1));
     end
     for i1=1:sizeoft
        ynew(1,i1) = 0;
        ynew(2,i1) = y(i1, 1);
        ynew(3,i1) = 0;
        ynew(4,i1) = l*(1 - y10^2/(4*l^2))^(1/2) - l*(1 - y(i1, 1)^2/(4*l^2))^(1/2);
        ynew(5,i1) = y(i1, 1)/2;
        ynew(6,i1) = asin(y(i1, 1)/(2*l));
        ynew(7,i1) = l*(1 - y10^2/(4*l^2))^(1/2) - l*(1 - y(i1, 1)^2/(4*l^2))^(1/2);
        ynew(8,i1) = y(i1, 1)/2;
        ynew(9,i1) = -asin(y(i1, 1)/(2*l));
        lineplot(1,1,i1) = 0.97;
        lineplot(1,2,i1) = 0;
        lineplot(1,3,i1) = 0.97;
        lineplot(1,4,i1) = y(i1, 1);
        for j=1:NumberOfBodies
             colorindex= j - floor((j-1)/5)*5;
             for i=1:size(Body{j},1)
                 R_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,1:2));
                 S_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,3:4));
                 set(bodydraw{j}(i),'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',definecolor{colorindex},'LineWidth',1);
             end
         end
         for j=1:1
             colorindex= j - floor((j-1)/5)*5;
             R_= [lineplot(j,1,i1); lineplot(j,2,i1)];
             S_= [lineplot(j,3,i1); lineplot(j,4,i1)];
             set(linedraw{j},'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',[0.494 0.184 0.556], 'LineStyle', '--');
         end
         drawnow nocallbacks;
    end
end
