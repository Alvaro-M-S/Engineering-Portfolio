function Constraints_ = Constraints_Modelo3_1_18240(q,t)

%% Model parameters 
      Param= Parameters_Modelo3_1_18240(t,q);

      y10= Param.y10;
 
%% Kinematic constraints 
 
%% Drivers 
      Constraints_(1) = q(1) - y10; 
 
end 

