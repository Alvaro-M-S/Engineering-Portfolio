function Construct_(Model)

%% Check values of parameters

    Model.Parameters={};
    for i=1:length(Model.Values)
        fprintf('.');
        if ~strcmp(Model.Values{i},'')
            try
                CheckModelValues = str2sym(Model.Values{i});
                Model.Parameters=[Model.Parameters, transpose(symvar(Model.Values{i}))];
            catch
                fprintf ('\nERROR.� in the definition of value %s\n\n',Model.Values{i}); 
                output= false;
                return
            end
        end     
    end
    Model.Parameters=str2sym(Model.Parameters);
    fprintf ('\nParameters definition checked\n'); 

%% Check system variables    
    q = Model.System_variables;
    j=0;
    for i=1:length(q)
        fprintf('.');
        if ~strcmp(q{i},'')
            try
                q_check = str2sym(q{i,1});
                q_new{j+1,1} = q{i,1};
                j=j+1;
            catch
                fprintf ('\nERROR.� in the definition of variable %s\n\n',q{i,1}); 
                output= false;
                return
            end
        end     
    end
    fprintf ('\nSystem variables definition checked\n'); 
    
    q = Model.System_variables;
    qdot = strcat(q,'dot');
    qdotdot = strcat(qdot,'dot');
    initialpositions = strcat(q,'_0');

    Model.System_variables= q;
    Model.q = cell2sym(q);
    Model.qdot = cell2sym(qdot);
    Model.qdotdot = cell2sym(qdotdot);
    Model.q0 = cell2sym(initialpositions);
    q0=Model.q0;
    for i=1:length(q)
        Q0(i) = str2sym(sprintf('x_0(%.0f)',i));
    end
    Model.Q0 = transpose(Q0);
    
    syms t
    Qstr = strcat(q,'(t)');
    Qdotstr = strcat('diff(',Qstr,',t)');
    Qdotdotstr = strcat('diff(',Qdotstr,',t)');
    for i=1:length(Qstr)
        try
            Model.Q(i,1)=str2sym(Qstr(i));
        catch
            fprintf ('\nERROR.� in the definition of variable %s (sintax error or not allowed variable name) \n\n',Qstr{i}); 
            fprintf ('\n\n'); 
            output= false;
            return  
        end
    end
%     Model.Q = str2sym(Qstr);
    Model.Qdot = str2sym(Qdotstr);
    Model.Qdotdot = str2sym(Qdotdotstr);

    Model.Qdotdot = cell2sym(strcat('Vel',q));
    Model.veldot = cell2sym(strcat('Vel',q,'dot'));
    velstr = strcat('Vel',q);
    Velstr = strcat('Vel',q,'(t)');
    veldot = Model.veldot;
    Veldotstr = strcat('diff(',Velstr,',t)');
    Model.vel = str2sym(velstr);
    Model.Vel = str2sym(Velstr);
    Model.Veldot = str2sym(Veldotstr);
    
    if length(Model.q) ~= length(Model.Drivers)+length(Model.Constraints)
        fprintf ('\nERROR.�: Incompatibity between number of variables, constraints and drivers.\n\n'); 
        fprintf ('\n\n'); 
        output= false;
        return  
    end

    if ~strcmp(Model.AnalysisType,'Kinematics')
        if length(Model.q) - length(Model.Drivers)>0
            if length(Model.Constraints) ~= length(Model.ConstraintForces)
                fprintf ('\nERROR.�: Different number of Constraints and Constraint Forces \n\n'); 
                fprintf ('\n\n'); 
                output= false;
                return  
            end          
            Model.NumOfLagrangeMultipliers= length(Model.q) - length(Model.Drivers);
            for i=1:length(Model.q) - length(Model.Drivers)
                LagrangeMultipliers(i,1) = str2sym(sprintf('lambda%.0f',i));
                LagrangeMultipliersdot(i,1) = str2sym(sprintf('lambda%.0fdot',i));
                LM(i,1) = str2sym(sprintf('lambda%.0f(t)',i));
                LMdot(i,1) = str2sym(sprintf('diff(lambda%.0f(t),t)',i));
                LabelConstraintForce(i,1)= str2sym(Model.ConstraintForces(i));
            end

            Model.LagrangeMultipliers = LagrangeMultipliers;
            Model.LagrangeMultipliersdot = LagrangeMultipliersdot;
            Model.NumOfLagrangeMultipliers= length(LagrangeMultipliers);
            Model.LM = LM;
            Model.LMdot = LMdot;
            Model.LabelConstraintForce= LabelConstraintForce;
            Model.x = [Model.vel; Model.q; Model.LagrangeMultipliers];
            Model.xdot = [Model.veldot; Model.qdot; Model.LagrangeMultipliersdot];
            Model.X = [Model.Vel; Model.Q; Model.LM];
            Model.Xdot = [Model.Veldot; Model.Qdot; Model.LMdot];
        else
            Model.NumOfLagrangeMultipliers= 0;
            Model.x = [Model.vel; Model.q];
            Model.xdot = [veldot; qdot];
            Model.X = [Model.Vel; Model.Q];
            Model.Xdot = [Model.Veldot; Model.Qdot];
        end
    end
    
%% Check drivers    
    try
        for i=1:length(Model.Drivers)
            fprintf('.');
            try
                driver(i,1)= str2sym(replace(Model.Drivers{i},' ',''));
            catch
                fprintf ('\nERROR.� in the definition of driver #%0.f \n\n',i); 
                fprintf ('\n\n'); 
                output= false;
                return  
            end
        end
        Model.NumberofDrivers= length(Model.Drivers);
        Model.Drivers= driver;
        fprintf ('\nDrivers definition checked\n'); 
    catch
        Model.NumberofDrivers= 0;
    end
    Feval=driver;
    syms t
    for i=1:length(Model.Drivers)
        try
            Feval(i)=subs(Feval(i),q,repmat(rand,length(q),1));
            Feval(i)=subs(Feval(i),Model.Parameters,repmat(rand,1,length(Model.Parameters)));
            Feval(i)=subs(Feval(i),t,rand);
            var= symvar(Feval(i));
            Out=double(Feval(i));
        catch
            fprintf ('\nERROR.� in the definition of driver #%0.f \n',i); 
            fprintf ('      Variable ''%s'' not defined \n\n',var); 
            output = false;
            return
        end
    end
        
 
%% Check constraints    
    try
        for i=1:length(Model.Constraints)
           fprintf('.');
           try    
                Constraint(i,1) = str2sym(replace(Model.Constraints{i},' ',''));
            catch
                fprintf ('\nERROR.� in the definition of constraint #%0.f \n\n',i); 
                output= false;
                return
            end
        end
        Model.NomberofConstraints= length(Model.Constraints);
        Model.Constraints= Constraint;
        fprintf ('\nConstraints definition checked\n'); 
    catch
        Model.NomberofConstraints= 0;
        Model.Constraints= {};
    end

    if Model.NomberofConstraints
        Feval=Constraint;
        for i=1:length(Model.Constraints)
            try
                Feval(i)=subs(Feval(i),q,repmat(rand,length(q),1));
                Feval(i)=subs(Feval(i),Model.Parameters,repmat(rand,1,length(Model.Parameters)));
                var= symvar(Feval(i));
                Out=double(Feval(i));
            catch
                fprintf ('\nERROR.� in the definition of constraint #%0.f \n',i); 
                fprintf ('      Variable ''%s'' not defined \n\n',var); 
                output = false;
                return
            end
        end
    end

%% Check constraint forces 
    if ~strcmp(Model.AnalysisType,'Kinematics')
        try
            ConstraintForces = Model.ConstraintForces;
            j=0;
            for i=1:length(ConstraintForces)
                fprintf('.');
                if ~strcmp(ConstraintForces{i},'')
                    try
                        ConstraintForces_check = str2sym(ConstraintForces{i,1});
                        ConstraintForces_new{j+1,1} = ConstraintForces{i,1};
                        j=j+1;
                    catch
                        fprintf ('\nERROR.� in the definition of constraint force %s\n\n',ConstraintForces{i,1}); 
                        output= false;
                        return
                    end
                end     
            end
            Model.ConstraintForces= ConstraintForces_new;
            Model.NumberofConstraintForces=length(Model.ConstraintForces);
        catch
            Model.NumberofConstraintForces=0;
        end

        if Model.NumberofConstraintForces ~= Model.NomberofConstraints
            fprintf ('\nERROR.� number of constraints #%0.f different to number of constraint forces #%0.f \n\n', Model.NomberofConstraints, Model.NumberofConstraintForces); 
            fprintf ('\n\n'); 
            output= false;
            return
        end   
        fprintf ('\nConstraint forces definition checked\n'); 
    end
    
    
%% Check viewports    
    try
        existviewport= Model.Viewport;
        try 
            ModelViewport = str2sym(Model.Viewport);
            if length(ModelViewport) ~= 4
                fprintf ('\nERROR.� in definition of Model Viewport \n\n'); 
                output= false;
                return
            end
            Model.Viewport= ModelViewport;
            Model.ExistViewport=true;
        catch
            Model.ExistViewport=false;
            fprintf ('\nERROR.� in definition of Model Viewport \n\n'); 
            fprintf ('\n\n'); 
            output= false;
            return
        end
        fprintf ('Model viewport definition checked\n'); 
    catch
        Model.ExistViewport=false;
    end
    
%% Check bodies movements
%     try
%     for i=1:length(Model.Body)
%     end
%     catch
%     end
    try
        if length(Model.Body) ~= size(Model.BodyMovements,1)
            fprintf ('\nERROR.� number of bodies #%0.f different to number of movements #%0.f \n\n', length(Model.Body), size(Model.BodyMovements,1)); 
            fprintf ('\n\n'); 
            output= false;
            return
        end
        if size(Model.BodyMovements,2)~=3
            fprintf ('\nERROR.� in the definition of movements \n\n'); 
            fprintf ('\n\n'); 
            output= false;
            return
        end
    catch
    end
    
    try
        for i=1:size(Model.BodyMovements,1)
            fprintf('.');
            for j=1:size(Model.BodyMovements,2)
                try
                    Movim = str2sym(Model.BodyMovements(i,j));
                catch
                    fprintf ('\nERROR.� in the definition of movement #%0.f position #%0.f\n\n',i,j); 
                    output= false;
                    return
                end
            end
        end
        Model.NumberofBodyMovements= size(Model.BodyMovements,1);
        fprintf ('\nBodies movements definition checked\n'); 
    catch
        Model.NumberofBodyMovements= 0;
    end
    
%% Check bodies
    try
        for i=1:length(Model.Body)
            BodyTemp= Model.Body{i};
%             if size(BodyTemp,2)~=4
%                 fprintf ('\nERROR.� incorrect definition of the bodies \n\n'); 
%                 fprintf ('\n\n'); 
%                 output= false;
%                 return
%             end
            for j=1:size(BodyTemp,1)
                 fprintf('.');
                 for k=1:size(BodyTemp,2)  
                    try  
                        checkbody= str2sym(BodyTemp(j,k));                        
                        Feval=subs(checkbody,q,repmat(rand,length(q),1));
                        Feval=subs(Feval,q,repmat(rand,length(q),1));
                        Feval=subs(Feval,Model.Parameters,repmat(rand,1,length(Model.Parameters)));
                        var= symvar(Feval);
                        Out=double(Feval);
                    catch
                        fprintf ('\nERROR.� in definition of row #%0.f in body #%0.f \n\n', j, i); 
                        fprintf ('\n\n'); 
                        output= false;
                        return
                    end
                  end
            end
        end
        Model.NumberofBodies= length(Model.Body);
        fprintf ('\nBodies definition checked\n'); 
    catch
        Model.NumberofBodies= 0;
    end
    
%% Check lines
    try
        for i=1:size(Model.Lines,1)
           fprintf('.');
           for j=1:size(Model.Lines,2)
                try
                    Linecheck = str2sym(Model.Lines(i,j));
                catch
                    fprintf ('\nERROR.� in the definition of line #%0.f position #%0.f\n\n',i,j); 
                    output= false;
                    return
                end
            end
        end
        Model.NumberofLines= size(Model.Lines,1);
        Model.Lines= str2sym(Model.Lines);
        fprintf ('\nLines definition checked\n'); 
    catch
        Model.NumberofLines= 0;
    end
    
%     if Model.NumberofBodies ~= Model.NumberofBodyMovements
%         fprintf ('\nERROR.� number of bodies #%0.f different to number of movements #%0.f \n\n', Model.NumberofBodies, Model.NumberofBodyMovements); 
%         fprintf ('\n\n'); 
%         output= false;
%         return
%     end
% 
    if Model.NumberofBodies && Model.NumberofBodyMovements && Model.ExistViewport
        Model.ConstructAnimation= true;
    else
        Model.ConstructAnimation= false;
    end
   
 %% Check initial conditions
    try
        for i=1:size(Model.Initial_conditions,1)
            fprintf('.');
            try
                InitCond = str2sym(Model.Initial_conditions(i));
            catch
                fprintf ('\nERROR.� in the definition of initial condition #%0.f \n\n',i,j); 
                output= false;
                return
            end
        end
        Model.Initial_conditions =  str2sym(Model.Initial_conditions);
        if length(Model.Initial_conditions) ~= length(Model.q)
            fprintf ('\nERROR.�: number of initial conditions (%0.f) is different to number of variables (%0.f) \n\n', length(Model.Initial_conditions), length(Model.q)); 
            output= false;
        return
        end
        fprintf ('\nInitial conditions definition checked\n'); 
    catch
        fprintf ('\nERROR.�: you must define initial conditions \n\n'); 
        output= false;
        return
    end
    
%% Check links    
    try
        Model.ExistLinks = Model.Links;
        for i=1:size(Model.Links,1)
            fprintf('.');
            if ~strcmp(Model.Links,'')
                try
                    for j=1:size(Model.Links,2)
                        Links2(i,j) = str2sym(Model.Links(i,j));
                    end
                catch
                    fprintf ('\nERROR.� in the definition of Link #%0.f',i); 
                    fprintf ('\n\n'); 
                    output= false;
                    return
                end
            end
        end
        Model.Links = Links2;
        Model.ExistLinks = true; 
        neqBG = 0;
%         syms t;
        nVariables = length(Model.q);
        ngdl= length(Model.Drivers);
        nequations= 3*nVariables-ngdl;
        if ~strcmp(Model.Links,'') 
            Links=subs(Model.Links, Model.q, Model.Q);
            for i=1:size(Links,1)
                Xinput=Links(i,1:4);
                Vinput = simplify(diff(sqrt((Xinput(3) - Xinput(1))^2 + (Xinput(4) - Xinput(2))^2),t));
                Input(i,1) = Vinput;
                Linkfunction = str2func(string(Links(i,6)));
                Model.OutputVariable(i,1)= Links(i,5);
                Model.Parameters= [Model.Parameters, Model.OutputVariable(i,1)];
                try
                    Model.output{i}= Linkfunction(Input(i)); %%%% CHEQUEAR ESTO
                catch
                    fprintf ('\nERROR in the definition of Link #%0.f. Model %s does not exist\n',i,Links(i,6)); 
                    return
                end
                try
                    Model.neqBGi(i)= Model.output{i}.nequations;
                    nequations= nequations + Model.neqBGi(i);
                    Model.x=[Model.x; Model.output{i}.q];
                    Model.output{i}.Q= str2sym(strcat(string(Model.output{i}.q),'(t)'));
                    Model.xdot=[Model.xdot; Model.output{i}.qdot];
                    Model.X=[Model.X; Model.output{i}.Q];
                    Model.Xdot=[Model.Xdot; diff(Model.output{i}.Q,t)];
                    Model.OutputForce(i,1)= Model.output{i}.outputs;
                    Model.ModelLink(i,1)= Links(i,5);    
                    Model.output{i}.ModelParameters= Model.output{i}.Parameters;
                    Model.Parameters= [Model.Parameters, Model.output{i}.ModelParameters]; %%%%%% REVISAR !!
                    Model.Values= [Model.Values; Model.output{i}.Values];  
                catch
                    fprintf ('\nERROR in the Submodel %s\n\n',Links(i,6)); 
                    return
               end
            end
            Model.neqBG= sum(Model.neqBGi);
            Model.OutputForce = subs(Model.OutputForce, Model.x(nequations- Model.neqBG+1:nequations), Model.X(nequations- Model.neqBG+1:nequations));
            Model.OutputForce = subs(Model.OutputForce, Model.xdot(nequations- Model.neqBG+1:nequations), Model.Xdot(nequations- Model.neqBG+1:nequations));
        end
        Model.NumberofLinks= size(Links,1);
        fprintf ('\nLinks definition checked\n'); 
    catch
        Model.NumberofLinks= 0;
    end
            
%% Check Type of Analysis (Kinematics, Newton-Euler or Lagrange)
    if strcmp(Model.AnalysisType, 'Kinematics')
        Model.FileAnalysisName= 'Kinematics_';
    elseif strcmp(Model.AnalysisType, 'Lagrange')
        Model.FileAnalysisName= 'Dynamics_LagrangeEquations_';
    elseif strcmp(Model.AnalysisType, 'Newton-Euler')
        Model.FileAnalysisName= 'Dynamics_NewtonEulerEquations_';
    else
       fprintf ('\nERROR in definition of Type of Analysis\n\n'); 
       output= false;
       return
    end

%% Check Solver
    if ~strcmp(Model.AnalysisType, 'Kinematics')
        if ~strcmp(Model.Solver, 'implicit') && ~strcmp(Model.Solver, 'nonstiffsemiexplicit') && ~strcmp(Model.Solver, 'stiffsemiexplicit')
           fprintf ('\nERROR in definition of Solver (%s)\n\n',Model.Solver); 
           output= false;
           return
        end
    end

    Model.filename= fopen(strcat(Model.FileAnalysisName,Model.Name,'.m'), 'w');

%% Kinematics    
    if strcmp(Model.AnalysisType, 'Kinematics')
       try
           ExistKinematicPlots= Model.NumSubplotsKinematics;
           ExistKinematicPlots= Model.SubplotsKinematics;    
           num_subplots= cell2mat(Model.NumSubplotsKinematics);
           Subplots=  Model.SubplotsKinematics;
           if  size(Subplots,1) ~= num_subplots(1,1)*num_subplots(1,2)
               fprintf ('\nERROR in definition of number of Subplots\n\n'); 
               output= false;
               return
           end              

           for i=1:size(Subplots,1)
              for j=1:2:size(Subplots,2)
                 fprintf('.');
                 try
                     subplot = str2sym(Model.SubplotsKinematics(i,j));
                  catch
                      fprintf ('\nERROR in definition of Subplot #%0.f for Kinematics\n\n',i); 
                      output= false;
                      return
                 end
              end
           end
%            syms t
           qxplot = str2sym(Subplots(:,1));
           qyplot = str2sym(Subplots(:,3));
           Labels(:,1) = Subplots(:,2);
           Labels(:,2) = Subplots(:,4);

           syms x;
           xplot= [Model.qdot; Model.q];
           for i=1:length(xplot)
              VectorofX(i,1)=str2sym(sprintf('x(%.0f)',i));
           end

           qxplot= subs(qxplot, xplot, VectorofX);
           qyplot= subs(qyplot, xplot, VectorofX);
         
           try
               for i=1:length(qxplot)  
                   qxplot_check= subs(qxplot(i),[VectorofX;t],rand(length(VectorofX)+1,1));
                   qxplot_check= subs(qxplot_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                   try
                       qxplot_check= double(qxplot_check);
                   catch
                       fprintf ('\nERROR in definition of X axis of plot #%0.f\n\n', i); 
                       output=false;
                       return
                   end
               end
               for i=1:length(qyplot)  
                   qyplot_check= subs(qyplot(i),[VectorofX;t],rand(length(VectorofX)+1,1));
                   qyplot_check= subs(qyplot_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                   try
                       qyplot_check= double(qyplot_check);
                   catch
                       fprintf ('\nERROR in definition of Y axis of plot #%0.f\n\n', i); 
                       output=false;
                       return
                   end
               end
               output=true;
           catch
               output=false;
           end
           Model.ExistKinematicPlots=true;
           fprintf ('\nSubplots definition checked\n'); 
       catch 
           Model.ExistKinematicPlots=false;
       end  
       Construct_Kinematics_(Model);
       Construct_Parameters_(Model);
       Construct_Constraints_and_Jacobian_(Model);
       Construct_Velocities_(Model);
       if ~Construct_Subplots_Kinematics_(Model)
          return
       end
  end
    
%% Dynamics    

    if strcmp(Model.AnalysisType, 'Lagrange') || strcmp(Model.AnalysisType, 'Newton-Euler')
        try
            ExistDynamicPlots= Model.NumSubplotsDynamics;
            ExistDynamicPlots= Model.SubplotsDynamics;      
            num_subplots= cell2mat(Model.NumSubplotsDynamics);
            Subplots=  Model.SubplotsDynamics;
            if  size(Subplots,1) ~= num_subplots(1,1)*num_subplots(1,2)
                fprintf ('\nERROR.� in definition of number of Subplots\n\n'); 
                output= false;
                return
            end              
            for i=1:size(Model.SubplotsDynamics,1)
                for j=1:2:size(Model.SubplotsDynamics,2)
                    fprintf('.');
                    try
                        subplot = str2sym(Model.SubplotsDynamics(i,j));
                    catch
                        fprintf ('\nERROR.� in definition of Subplot #%0.f for Dynamics\n\n',i); 
                        output= false;
                        return
                    end
                end
            end
            x=Model.x;
            xdot=Model.xdot;
            xplot= x;
            Model.xplot= subs(xplot,x(1:length(Model.q)),xdot(1+length(Model.q):2*length(Model.q)));
            try
                Forceplot= Model.OutputForce;
                Forceplot=subs(Forceplot,Model.Xdot,Model.xdot);
                Model.Forceplot=subs(Forceplot,Model.X,Model.x); 
            catch
            end
            Model.ExistDynamicPlots=true;
            
            num_subplots= cell2mat(Model.NumSubplotsDynamics);
            Subplots=  Model.SubplotsDynamics;

%             syms t

            qxplot = str2sym(Subplots(:,1));
            qyplot = str2sym(Subplots(:,3));
            Labels(:,1) = Subplots(:,2);
            Labels(:,2) = Subplots(:,4);

% %             syms x;
% %             xplot1= Model.xplot;
% %             x=Model.x;
% %             xplot2= subs(x, Model.qdot, Model.vel);
% %             for i=1:length(xplot1)
% %                 VectorofX(i,1)=str2sym(sprintf('x(%.0f)',i));
% %             end
% %             if Model.NumberofLinks
% %                 qyplot= subs(qyplot, Model.OutputVariable, Model.Forceplot);
% %             end
            syms x;
            xplot1= Model.xplot;
            x=Model.x;
            xplot2= subs(x, Model.qdot, Model.vel);
            for i=1:length(xplot1)
                VectorofX(i,1)=str2sym(sprintf('x(%.0f)',i));
                VectorofXp(i,1)=str2sym(sprintf('xp(%.0f)',i));
            end
            if Model.NumOfLagrangeMultipliers
                for i=1:length(Model.LabelConstraintForce)
                    qyplot= subs(qyplot, Model.LabelConstraintForce(i), str2sym(sprintf('xp(%.0f)',i+2*length(q))));
                end
            end
            for i=1:length(q)
                qyplot= subs(qyplot, Model.qdotdot(i), str2sym(sprintf('xp(%.0f)',i)));
            end
            if Model.NumberofLinks
                qyplot= subs(qyplot, Model.OutputVariable, Model.Forceplot);
            end            
               
            qxplot= subs(qxplot, xplot1, VectorofX);
            qyplot= subs(qyplot, xplot1, VectorofX);
            qyplot= subs(qyplot, xplot2, VectorofX);

            try
                for i=1:length(qxplot)  
                    qxplot_check= subs(qxplot(i),[VectorofX;t],rand(length(VectorofX)+1,1));
                    qxplot_check= subs(qxplot_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                    try
                        qxplot_check= double(qxplot_check);
                    catch
                        fprintf ('\nERROR in definition of X axis of plot #%0.f\n\n', i); 
                        output=false;
                        return
                    end
                end
                for i=1:length(qyplot)  
                    qyplot_check= subs(qyplot(i),[VectorofX;VectorofXp;t],rand(2*length(VectorofX)+1,1));
                    qyplot_check= subs(qyplot_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                    for ii=1:length(Model.q0)
                        qyplot_check = subs(qyplot_check, Model.q0(ii), rand);
                    end
                    try
                        qyplot_check= double(qyplot_check);
                    catch
                        fprintf ('\nERROR in definition of Y axis of plot #%0.f\n\n', i); 
                        output=false;
                        return
                    end
                end
                output=true;
            catch
                output=false;
                return
            end

            for i=1:length(Model.q0)
                qxplot = subs(qxplot, Model.q0(i), str2sym(sprintf('x_0(%.0f)',i)));
                qyplot = subs(qyplot, Model.q0(i), str2sym(sprintf('x_0(%.0f)',i)));
            end
            fprintf ('\nSubplots definition checked\n'); 
            
        catch
            Model.ExistDynamicPlots=false;
        end
    end
  
    if strcmp(Model.AnalysisType, 'Lagrange')
        try
            for i=1:length(Model.T)
                try
                    T1(i) = str2sym(Model.T(i));
                catch
                    fprintf ('\nERROR.� in definition of T in row #%0.f \n', i); 
                    output= false;
                    return
                end
            end
            Model.T=T1;
            Model.NumberofT=length(Model.T);        
            for i=1:length(Model.T)
                T0=Model.T(i);
                T_check= subs(T0,q,rand(length(q),1));
                T_check= subs(T_check,qdot,rand(length(q),1));
                T_check= subs(T_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                try
                    variablenotfound=symvar(T_check);
                    T_check= double(T_check);
                catch
                    fprintf ('\nERROR.� in definition of term #%0.f of T\n', i); 
                    fprintf ('      Variable ''%s'' not defined\n', variablenotfound); 
                    return
                end
            end
        catch
            Model.NumberofT=0;
        end

        try
            for i=1:length(Model.V)
                try
                    V1(i) = str2sym(Model.V(i));
                catch
                    fprintf ('\nERROR.� in definition of V in row #%0.f \n', i); 
                    output= false;
                    return
                end
            end
            Model.V= V1; 
            Model.NumberofV=length(Model.V);
            syms t
            for i=1:length(Model.V)
                V0=Model.V(i);
                V_check= subs(V0,q,rand(length(q),1));
                V_check= subs(V_check,q0,rand(length(q),1));
                V_check= subs(V_check,qdot,rand(length(q),1));
                V_check= subs(V_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                V_check= subs(V_check,t,rand); 
                try
                    variablenotfound=symvar(V_check);
                    V_check= double(V_check);
                catch
                    fprintf ('\nERROR.� in definition of term #%0.f of V\n', i); 
                    fprintf ('      Variable ''%s'' not defined\n', variablenotfound); 
                    return
                end
            end
        catch
            Model.NumberofV=0;
        end
        
        try
            for i=1:length(Model.R)
                try
                    R1(i) = str2sym(Model.R(i));
                catch
                    fprintf ('\nERROR.� in definition of R in row #%0.f \n', i); 
                    output= false;
                    return
                end
            end
            Model.NumberofR=length(Model.R);
            Model.R=R1;
            for i=1:length(Model.R)
                R0=Model.R(i);
                R_check= subs(R0,q,rand(length(q),1));
                R_check= subs(R_check,q0,rand(length(q),1));
                R_check= subs(R_check,qdot,rand(length(q),1));
                R_check= subs(R_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                try
                    variablenotfound=symvar(R_check);
                    R_check= double(R_check);
                catch
                    fprintf ('\nERROR.� in definition of term #%0.f of R\n', i); 
                    fprintf ('      Variable ''%s'' not defined\n', variablenotfound); 
                    return
                end 
            end
        catch
            Model.NumberofR=0;
        end
        
        Construct_Lagrange_(Model);
        Construct_Constraints_and_Jacobian_(Model);
                
        %% Construct subplots
        if Model.ExistDynamicPlots
            try
                Forceplot= Model.OutputForce;
                Forceplot=subs(Forceplot,Model.Xdot,Model.xdot);
                Model.Forceplot=subs(Forceplot,Model.X,Model.x); 
                Construct_Subplots_Dynamics_(Model);
                Construct_Subplots_Energy_(Model);
            catch
                Construct_Subplots_Dynamics_(Model);
                Construct_Subplots_Energy_(Model);
            end
        end
    end
%%%%%%%%%%%%
    if strcmp(Model.AnalysisType, 'Newton-Euler')
        %% Check Mass matrix
        try
            for i=1:size(Model.MassMatrix,1)
%                 for j=1:size(Model.MassMatrix,2)
                    try
                        MassMatrix1(i,i) = str2sym(Model.MassMatrix(i));
                    catch
                        fprintf ('\nERROR.� in definition of Mass Matrix in row #%0.f column #%0.f \n', i,j); 
                        output= false;
                        return
                    end
%                 end
            end
            Model.MassMatrix=MassMatrix1;
            Model.SizeofMassMatrix=size(Model.MassMatrix);        
            for i=1:size(Model.MassMatrix,1)
                for j=1:size(Model.MassMatrix,2)
                    MassMatrix0=Model.MassMatrix(i,j);
                    MassMatrix_check= subs(MassMatrix0,q,rand(length(q),1));
                    MassMatrix_check= subs(MassMatrix_check,qdot,rand(length(q),1));
                    MassMatrix_check= subs(MassMatrix_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                    try
                        variablenotfound=symvar(MassMatrix_check);
                        T_check= double(MassMatrix_check);
                    catch
                        fprintf ('\nERROR.� in definition of Mass Matrix in row #%0.f column #%0.f \n', i,j); 
                        fprintf ('      Variable ''%s'' not defined\n', variablenotfound); 
                        return
                    end
                end
            end
        catch
            Model.SizeofMassMatrix=0;
        end
        
        %% Check linear and angular momentum
        try
            for i=1:length(Model.LinearAngularMomentum)
                try
                    LinearAngularMomentum1(i,1) = str2sym(Model.LinearAngularMomentum(i));
                catch
                    fprintf ('\nERROR.� in definition of Linear and Angular Momentum in row #%0.f\n', i); 
                    output= false;
                    return
                end
            end
            Model.LinearAngularMomentum= LinearAngularMomentum1;
            Model.SizeofinearAngularMomentum= length(Model.LinearAngularMomentum);        
            for i=1:length(Model.LinearAngularMomentum)
                LinearAngularMomentum0=Model.LinearAngularMomentum(i,1);
                LinearAngularMomentum_check= subs(LinearAngularMomentum0,q,rand(length(q),1));
                LinearAngularMomentum_check= subs(LinearAngularMomentum_check,qdot,rand(length(q),1));
                LinearAngularMomentum_check= subs(LinearAngularMomentum_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                try
                    variablenotfound=symvar(LinearAngularMomentum_check);
                    LinearAngularMomentum_check= double(LinearAngularMomentum_check);
                catch
                    fprintf ('\nERROR.� in definition of Linear and Angular Momentum in row #%0.f\n', i); 
                    fprintf ('      Variable ''%s'' not defined\n', variablenotfound); 
                    return
                end
            end
        catch
            Model.SizeofLinearAngularMomentum=0;
        end
        
        %% Check Forces
        try
            for i=1:length(Model.Forces)
                try
                    Forces1(i,1) = str2sym(Model.Forces(i));
                catch
                    fprintf ('\nERROR.� in definition of Forces in row #%0.f\n', i); 
                    output= false;
                    return
                end
            end
            Model.Forces= Forces1;
            Model.SizeofForces= length(Model.Forces);        
            for i=1:length(Model.Forces)
                Forces0=Model.Forces(i,1);
                Forces_check= subs(Forces0,q,rand(length(q),1));
                Forces_check= subs(Forces_check,q0,rand(length(q),1));
                Forces_check= subs(Forces_check,qdot,rand(length(q),1));
                Forces_check= subs(Forces_check,Model.Parameters,rand(1,length(Model.Parameters))); 
                try
                    variablenotfound=symvar(Forces_check);
                    Forces_check= double(Forces_check);
                catch
                    fprintf ('\nERROR.� in definition of Forces in row #%0.f\n', i); 
                    fprintf ('      Variable ''%s'' not defined\n', variablenotfound); 
                    return
                end
            end
        catch
            Model.SizeofForces=0;
        end
        
        Construct_NewtonEuler_(Model);
        Construct_Constraints_and_Jacobian_(Model);
                
        %% Construct subplots
        if Model.ExistDynamicPlots
            try
                Forceplot= Model.OutputForce;
                Forceplot=subs(Forceplot,Model.Xdot,Model.xdot);
                Model.Forceplot=subs(Forceplot,Model.X,Model.x); 
                Construct_Subplots_Dynamics_(Model);
            catch
                Construct_Subplots_Dynamics_(Model);
            end
        end
        
    end
    
%%  Construct animation if requested
    if Model.NumberofBodies && Model.NumberofBodyMovements && Model.ExistViewport
        Construct_Animation_(Model);
    end

    
%         if Construye_Fuerzas_(Modelo, Model.q, Model.qdot, Model.q0, Force, Links, Parametros_modelo)==false
%             return
%         end
%         Construye_Dinamica_(Modelo, Parametros_modelo, Parametros_drivers, Model.q, Model.qdot, Model.q0, Restriccion, Valor, t, Driver, Ecuacion_Driver, Valor_driver, Masas, Fuerza, Links, Condiciones_Iniciales, Cuerpo, Ventana, Solver);
    fclose(Model.filename);

end