clear all
clc

%% Model name
   Model.Name='Modelo3_2_18240';


%% Model parameters values
   Model.Values = {'l = 1'; 'd = 1.2'; ...
             'M1 = 250'; 'J1 = 100';  ...
             'g = 9.8'; 'K1 = 5000'; 'R1 = 500'; ...
             'y10=0.7'}; 


%% Model variables list  
    Model.System_variables= {'x1'; 'y1';'phi1'; 'x2'; 'y2'; 'phi2';'x3'; 'y3'; 'phi3';};

%% Kinematic constraints 
    Model.Constraints = { 'x2 + l*cos(phi2)';
                          'y2 + l*sin(phi2)';
                          'x2 - x3';
                          'y2 - y3';
                          'x1 -x3 + cos(phi1)*d - cos(phi3)*l';
                          'y1-y3-sin(phi3)*l+d*sin(phi1)';
                          'cos(phi1)*(y2 - y1 - l*sin(phi2))-sin(phi1)*(x2-x1-l*cos(phi2))';
                          'y3 - l*sin(phi3)'};
                      
%% Constraint Forces                
       Model.ConstraintForces = { 'RBx'; 'RBy'; 'RDx'; 'RDy'; 'RCx'; 'RCy'; 'RNA' ;'RNE'};

%% Driver equations
    Model.Drivers = {'y1 - y10'}

%% Type of Analysis (Kinematics, Newton-Euler or Lagrange)
    Model.AnalysisType= 'Lagrange';
    
%% Dynamics using Lagrange equations
      Model.T = {'M1*y1dot^2/2'};
        Model.V = {'M1*g*y1';
                   '(K1*(y1 - y10)^2)/2'};
        Model.R = {'R1*y1dot^2/2'};      
    
%% Time span
    Model.t= '[0:0.005:10]';
    
%% Initial conditions
    Model.Initial_conditions = {'0'; 'y10'; '0'; '0'; 'y10/2'; '-pi/4' ; '0'; 'y10/2'; 'pi/4'};
    
%% Solver for dynamics: Use 'implict', 'nonstiffsemiexplicit' or 'stiffsemiexplicit'
    Model.Solver = 'nonstiffsemiexplicit';
%     Model.Solver = 'implicit';
    
%% Define animation
    % Objet to be animated, defined by polygons in local body coordinates
    Model.Body{1} = {'d', '0.1', 'd', '0';
                     'd', '0', '-1.1*d', '0';
                     '-1.1*d', '0', '-1.1*d', '0.1';
                     '-1.1*d', '0.1', 'd', '0.1'};
                 
    Model.Body{2} =  {'l', '0.01', 'l', '-0.01';
                     'l', '-0.01', '-l', '-0.01';
                     '-l', '-0.01', '-l', '0.01';
                     '-l', '0.01', 'l', '0.01'};  
                 
    Model.Body{3} = {'l', '0.01', 'l', '-0.01';
                     'l', '-0.01', '-l', '-0.01';
                     '-l', '-0.01', '-l', '0.01';
                     '-l', '0.01', 'l', '0.01'}; 
    % Body movements for animation
    Model.BodyMovements = {'x1',  'y1',  'phi1';
                           'x2',  'y2',  'phi2';
                           'x3',  'y3',  'phi3'};      
    % Lines for animation
    Model.Lines = {'0', '0', '0',  'y1'};      
    
    % Viewport for animation
    Model.Viewport = {'-5 ', '5', ' -1.5', ' 1.5'};

%% Plots x-y for Dynamics
    Model.NumSubplotsDynamics = {4, 2};
    Model.SubplotsDynamics = {'t', 'Time (s)', 'x2 + l/2*cos(phi2)', 'X displacement - slider (m)';
                              'x1', 'X displacement - crank (m)', 'y1', 'Y displacement - crank (m)';
                              'x2', 'X displacement - slider (m)', 'y2', 'Y displacement - slider (m)';
                              't', 'Time (s)', 'x2dotdot', 'X acceleration - COG slider (m2/s)';
                              't', 'Time (s)', 'RDx', 'Constraint Force X at A (N)';
                              't', 'Time (s)', 'RDy', 'Constraint Force Y at A (N)';
                              't', 'Time (s)', 'RBx', 'Constraint Force X at B (N)';
                              't', 'Time (s)', 'RBy', 'Constraint Force Y at B (N)'};

%% Construction of MatLab model. DO NOT MODIFY
    Construct_(Model);
