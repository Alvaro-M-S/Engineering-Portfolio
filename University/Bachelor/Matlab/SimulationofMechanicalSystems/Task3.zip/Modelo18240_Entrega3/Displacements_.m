function S = Displacements_(Model, q, t)
    % Newton_Raphson algorithm for solving nonlinear equations

    neq=length(q);
    S = zeros(neq,1); 
    
    modeljacobian = str2func(sprintf('Jacobian_%s',Model));
    modelconstraints = str2func(sprintf('Constraints_%s',Model));

    for i = 1:length(t)
        n = 1000;
        e = 0.00001;
        j = 0;
        while (j < n)  
            J = modeljacobian(q, t);
            if rank(J)<neq
                formatSpec = 'Warning: Jacobian rank (%3i) < number of equations (%3i) \n\n';
                fprintf(formatSpec,rank(J),neq);
            end
            F = modelconstraints(q, t(i));
            q_sig = q - J \ F';    
            if (all(abs(q_sig - q) < e))
                q = q_sig;
                break;
            else
                q = q_sig;
                j = j+1;
            end
        end
        if j>=n
            formatSpec = 'ERROR: Maximum number of iterations =% 3i exceeded. The system does not converge to any solution \n\n';
            fprintf(formatSpec,n);
            break
        end
        S(:,i) = q;
        dispstat(sprintf('  t = %8.2f \n',t(i))); 
    end
end
    