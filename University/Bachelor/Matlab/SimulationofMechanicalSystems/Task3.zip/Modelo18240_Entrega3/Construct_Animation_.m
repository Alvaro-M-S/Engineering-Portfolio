function output= Construct_Animation_(Model)
      
    filename= Model.filename;

    Body= Model.Body;
    BodyMovement= Model.BodyMovements;
    q= Model.q;
    for i=1:length(q)
        VectorofY(i,1)=str2sym(sprintf('y(i1,%.0f)',i));
    end
    
    NumberofBodies = length(Body);
    NumberofLines = Model.NumberofLines;
    BodyMovement=str2sym(BodyMovement);
    
    fprintf(filename, '%s \n\n', strcat('function Animation_',Model.Name,'(y)'));
    fprintf(filename, '%s \n', '%% Model parameters');
    fprintf(filename, '     t=0; x=0; \n');
    fprintf(filename, '     Param= Parameters_%s(t,x);\n',Model.Name);
    s1=symvar([q;'t']);
    s2=symvar(BodyMovement);
    for i=1:length(Body)
        s2= [s2, symvar(str2sym(Body{i}))];
    end
    if NumberofLines
        for i=1:size(Model.Lines,1)
            for j=1:size(Model.Lines,2)
                s2= [s2, symvar(Model.Lines(i,j))];
            end
        end
    end
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, '\n');
    
    fprintf(filename, '%s \n', '%% Bodies to be animated');
    for i=1:length(Body)
        fprintf(filename, '     Body{%0.f} = [', i);
        BodyTemp= Body{i};
        for j=1:size(BodyTemp,1)
            for k=1:size(BodyTemp,2)  
                if j>1 && k==1
                   fprintf(filename, '                 %s', string(BodyTemp(j,k)));
                elseif j==1 || k>1
                   fprintf(filename, ' %s', string(BodyTemp(j,k)));
                end 
                if k<size(BodyTemp,2) 
                   fprintf(filename, ',');
                end
            end
            
            if size(Body{i},1)==1
               fprintf(filename, ']; \n\n');
            elseif j<size(Body{i},1)
                fprintf(filename, '; \n');
            else
                fprintf(filename, ']; \n\n');
            end
        end
    end
    
    fprintf(filename, sprintf('     NumberOfBodies = length(Body);\n'));              
    fprintf(filename, sprintf('     NumberOfLines = %0.f;\n',Model.NumberofLines));              
    
    ModelViewport = Model.Viewport;

    fprintf(filename, '\n %s \n', '%% Animation viewport');
    fprintf(filename, '     axis equal \n');
    fprintf(filename, '     axis ([');
    for i=1:length(ModelViewport)
        fprintf(filename, ' %s', ModelViewport(i));
    end
    fprintf(filename, ']);\n');
    fprintf(filename, '     grid on \n\n');
    
    fprintf(filename, '     definecolor = {''r'' ''g'' ''b'' ''m'' ''k'' ''r''}; \n\n');

    fprintf(filename, '%% Begin Animation\n');
    fprintf(filename, '     y = transpose(y);\n');
    
    fprintf(filename, '     sizeoft=size(y,1);\n');
    fprintf(filename, '     for j=1:NumberOfBodies\n');
    fprintf(filename, '         bodydraw{j}=line(zeros(size(Body{j},1)),zeros(size(Body{j},1)));\n');
    fprintf(filename, '     end\n');
    
    fprintf(filename, '     for j=1:%0.f\n',Model.NumberofLines); 
    fprintf(filename, '         linedraw{j}=line(zeros(1,1),zeros(1,1));\n'); 
    fprintf(filename, '     end\n');
    
    try
        existmodelanimation= Model.Animation;
    catch
        Model.Animation = false;
    end
    
    if Model.Animation
        fprintf(filename, '     %s; \n', strcat('v = VideoWriter(''AnimationFile_',Model.Name,''',''MPEG-4'')'));
        fprintf(filename, '     open(v);\n\n');
    end
    
    
    fprintf(filename, '     for i1=1:sizeoft\n');
    for i=1:NumberofBodies
        for j=1:3
            fprintf(filename,sprintf('        ynew(%0.f,i1) = %s;\n',3*(i-1)+j,subs(BodyMovement(i,j),q,VectorofY)));
        end
    end
    for i=1:NumberofLines
        for j=1:4
            fprintf(filename,sprintf('        lineplot(%0.f,%0.f,i1) = %s;\n',i,j,subs(Model.Lines(i,j),q,VectorofY)));
        end
    end
    fprintf(filename, '        for j=1:NumberOfBodies\n');
    fprintf(filename, '             colorindex= j - floor((j-1)/5)*5;\n');
    fprintf(filename, '             for i=1:size(Body{j},1)\n');
    fprintf(filename, '                 R_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,1:2));\n');
    fprintf(filename, '                 S_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,3:4));\n');
    fprintf(filename, '                 set(bodydraw{j}(i),''XData'',[R_(1),S_(1)],''YData'',[R_(2),S_(2)],''Color'',definecolor{colorindex},''LineWidth'',1);\n');
    fprintf(filename, '             end\n');
    fprintf(filename, '         end\n');
    fprintf(filename, '         for j=1:%0.f\n',Model.NumberofLines); 
    fprintf(filename, '             colorindex= j - floor((j-1)/5)*5;\n');
    fprintf(filename, '             R_= [lineplot(j,1,i1); lineplot(j,2,i1)];\n');
    fprintf(filename, '             S_= [lineplot(j,3,i1); lineplot(j,4,i1)];\n');
    fprintf(filename, '             set(linedraw{j},''XData'',[R_(1),S_(1)],''YData'',[R_(2),S_(2)],''Color'',[0.494 0.184 0.556], ''LineStyle'', ''--'');\n');
    fprintf(filename, '         end\n');
    fprintf(filename, '         drawnow nocallbacks;\n');
    if Model.Animation
        fprintf(filename, '         frame = getframe(gcf);\n');
        fprintf(filename, '         writeVideo(v,frame);\n\n');
    end
    fprintf(filename, '    end\n');
    if Model.Animation
        fprintf(filename, '    close(v);\n\n');
    end
    fprintf(filename, 'end\n');
    fprintf(strcat('Constructed Animation_',Model.Name,'.m  \n'));
    
end