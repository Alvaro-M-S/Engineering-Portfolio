function output= Construct_Subplots_Dynamics_(Model)
    
    num_subplots= cell2mat(Model.NumSubplotsDynamics);
    Subplots=  Model.SubplotsDynamics;
    
    syms t
    
	qxplot = str2sym(Subplots(:,1));
	qyplot = str2sym(Subplots(:,3));
    Labels(:,1) = Subplots(:,2);
    Labels(:,2) = Subplots(:,4);

    syms x;
    xplot1= Model.xplot;
    x=Model.x;
    xplot2= subs(x, Model.qdot, Model.vel);
    for i=1:length(xplot1)
        VectorofX(i,1)=str2sym(sprintf('x_(%.0f)',i));
    end
    if Model.NumOfLagrangeMultipliers
        for i=1:length(Model.LabelConstraintForce)
            qyplot= subs(qyplot, Model.LabelConstraintForce(i), str2sym(sprintf('xp_(%.0f)',i+2*length(Model.q))));
        end
    end
    for i=1:length(Model.q)
        qyplot= subs(qyplot, Model.qdotdot(i), str2sym(sprintf('xp_(%.0f)',i)));
    end
    for i=1:length(Model.q)
        qyplot= subs(qyplot, Model.q0(i), str2sym(sprintf('x_0(%.0f)',i)));
    end
    
    if Model.NumberofLinks
        qyplot= subs(qyplot, Model.OutputVariable, Model.Forceplot);
    end
    qxplot= subs(qxplot, xplot1, VectorofX);
    qyplot= subs(qyplot, xplot1, VectorofX);
    qyplot= subs(qyplot, xplot2, VectorofX);

    filename=Model.filename;
    fprintf(filename, 'function U = Subplots_Dynamics_%s(x_0,t,x_,xp_)\n\n', Model.Name);

%% Model parameters    
    fprintf(filename, '%s \n', '     %% Model parameters');
    fprintf(filename, '     Param= Parameters_%s(t,x_);\n\n',Model.Name);
    s1=[symvar(xplot1),symvar(xplot2),'t'];
    s2=symvar(qyplot);
    for i=1:length(s2)
        if ~ismember(s2(i),s1)
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, ' \n');
    
    fprintf(filename, ' %s \n\n', '%% Subplots definition');

    subplotsrows = num_subplots(1);
    subplotscolumns = num_subplots(2);
    for i=1:subplotsrows
        for j=1:subplotscolumns
            plotindex = (i-1)*subplotscolumns+j;
            plot=Labels(plotindex,:);     
            fprintf(filename, '     subplot(%.f,%.f,%.f);\n',subplotsrows, subplotscolumns, plotindex);
            fprintf(filename, '     for i=1:size(x_,1)\n');
            if strcmp(string(qxplot(plotindex)),"t")            
                str1=replace(string(qxplot(plotindex)), 't', 't(i)');
            else
                str1=replace(string(qxplot(plotindex)), 'x_(', 'x_(i,');
            end
            if strcmp(string(qyplot(plotindex)),"t") 
                str2=replace(string(qyplot(plotindex)), 't', 't(i)');
            else
                str2=replace(string(qyplot(plotindex)), 'x_(', 'x_(i,');
                str2=replace(str2, 'xp_(', 'xp_(i,');
            end
            fprintf(filename, '         X_(i) = %s;\n',str1);
            fprintf(filename, '         Y_(i) = %s;\n',str2);
            fprintf(filename, '     end\n');
            fprintf(filename, '     plot(X_,Y_);\n');
            fprintf(filename, '     xlabel(''%s'');\n', string(Labels(plotindex,1)));
            fprintf(filename, '     title(''%s'');\n', string(Labels(plotindex,2)));
            if str1~="t(i)"
                fprintf(filename, '     axis(''equal'')\n');
            end
            fprintf(filename, '     grid\n\n');            
        end
        fprintf('.');
    end

    fprintf(filename, ' \n%s \n\n', 'end');
    
    fprintf('\nConstructed %s \n', sprintf('Subplots_Dynamics_%s.m',Model.Name));

    output = true;

end
