function output= Construct_Subplots_Kinematics_(Model)
 
    num_subplots= cell2mat(Model.NumSubplotsKinematics);
    Subplots=  Model.SubplotsKinematics;
    
    syms t
    
	qxplot = str2sym(Subplots(:,1));
	qyplot = str2sym(Subplots(:,3));
    Labels(:,1) = Subplots(:,2);
    Labels(:,2) = Subplots(:,4);

    syms x;
    xplot= [Model.qdot; Model.q];
    for i=1:length(xplot)
        VectorofX(i,1)=str2sym(sprintf('x(%.0f)',i));
    end
    
    qxplot= subs(qxplot, xplot, VectorofX);
    qyplot= subs(qyplot, xplot, VectorofX);
% 
%     try
%         for i=1:length(qxplot)  
%             qxplot_check= subs(qxplot(i),[VectorofX;t],rand(length(VectorofX)+1,1));
%             qxplot_check= subs(qxplot_check,Model.Parameters,rand(1,length(Model.Parameters))); 
%             try
%                 qxplot_check= double(qxplot_check);
%             catch
%                 fprintf ('ERROR in definition of X axis of plot #%0.f\n\n', i); 
%                 output=false;
%                 return
%             end
%         end
%         for i=1:length(qyplot)  
%             qyplot_check= subs(qyplot(i),[VectorofX;t],rand(length(VectorofX)+1,1));
%             qyplot_check= subs(qyplot_check,Model.Parameters,rand(1,length(Model.Parameters))); 
%             try
%                 qyplot_check= double(qyplot_check);
%             catch
%                 fprintf ('ERROR in definition of Y axis of plot #%0.f\n\n', i); 
%                 output=false;
%                 return
%             end
%         end
%         output=true;
%     catch
%         output=false;
%     end
%       
%     for i=1:length(Model.q0)
%         qxplot = subs(qxplot, Model.q0(i), str2sym(sprintf('x_0(%.0f)',i)));
%         qyplot = subs(qyplot, Model.q0(i), str2sym(sprintf('x_0(%.0f)',i)));
%     end

    %% Build Plots function 
% % %     filename = fopen(sprintf('Subplots_Kinematics_%s.m', Model.Name), 'w');
    filename = Model.filename;

    fprintf(filename, 'function U = Subplots_Kinematics_%s(x_0,t,x,xdot)\n\n', Model.Name);

%% Model Parameters    
    fprintf(filename, '%s \n', '     %% Model Parameters');
    fprintf(filename, '     Param= Parameters_%s(0,zeros(%.0f,1));\n\n',Model.Name,length(Model.q));
    s1=[symvar(xplot),'t'];
    s2=symvar(qyplot);
    for i=1:length(s2)
        if ~ismember(s2(i),s1)
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, ' \n');
    
    fprintf(filename, ' %s \n\n', '%% Subplots definition');

    subplotsrows = num_subplots(1);
    subplotscolumns = num_subplots(2);
    for i=1:subplotsrows
        for j=1:subplotscolumns
            plotIndex = (i-1)*subplotscolumns+j;
            plot=Labels(plotIndex,:);     
            fprintf(filename, '     subplot(%.f,%.f,%.f);\n',subplotsrows, subplotscolumns, plotIndex);
            fprintf(filename, '     for i=1:size(x,1)\n');
            if strcmp(string(qxplot(plotIndex)),"t")            
                str1=replace(string(qxplot(plotIndex)), 't', 't(i)');
            else
                str1=replace(string(qxplot(plotIndex)), 'x(', 'x(i,');
                str1=replace(str1, 'xdot(', 'xdot(i,');
            end
            if strcmp(string(qyplot(plotIndex)),"t") 
                str2=replace(string(qyplot(plotIndex)), 't', 't(i)');
            else
                str2=replace(string(qyplot(plotIndex)), 'x(', 'x(i,');
                str2=replace(str2, 'xdot(', 'xdot(i,');
            end
            fprintf(filename, '         X(i) = %s;\n',str1);
            fprintf(filename, '         Y(i) = %s;\n',str2);
            fprintf(filename, '     end\n');
            fprintf(filename, '     plot(X,Y);\n');
            fprintf(filename, '     xlabel(''%s'');\n', string(Labels(plotIndex,1)));
            fprintf(filename, '     title(''%s'');\n', string(Labels(plotIndex,2)));
            if str1~="t(i)"
                fprintf(filename, '     axis(''equal'')\n');
            end
            fprintf(filename, '     grid\n\n');            
        end
        fprintf('.');
    end

    fprintf(filename, ' \n%s \n\n', 'end');
    
    fprintf('\nConstructed %s \n', sprintf('Subplots_Kinematics_%s.m', Model.Name));

    output = true;

end
