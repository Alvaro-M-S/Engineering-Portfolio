
clear all
clc

%% Model name
    Model.Name= 'Modelo3_1_18240';

%% Model parameters values
     Model.Values = {'M1 = 250'; 
                     'g = 9.8'; 'K1 = 10000'; 'R1 = 1000'; ...
                     'y10 = 0.5'; 'l=1'; 'd=1.2';};
%% Model variables    
    Model.System_variables= {'y1'};

%% Kinematic constraints  
    Model.Constraints = {};

%% Driver equations
    Model.Drivers = {'y1 - y10'}; 

%% Type of Analysis (Kinematics, Newton-Euler or Lagrange)
    Model.AnalysisType= 'Lagrange';
                     
%% Dynamics using Lagrange equations
        Model.T = {'M1*y1dot^2/2'};
        Model.V = {'M1*g*y1';
                   '(K1*(y1 - y10)^2)/2'};
        Model.R = {'R1*y1dot^2/2'};

%% Time span
    Model.t= '[0:0.02:10]';
    
%% Initial conditions
    Model.Initial_conditions = {'0.35'};  

%% Solver for dynamics: Use 'implict', 'nonstiffsemiexplicit' or 'stiffsemiexplicit'
    Model.Solver = 'nonstiffsemiexplicit';
    
%% Define animation
    % Objet to be animated, defined by polygons in local body coordinates
    %Cabina
    Model.Body{1} = {'d', '0.1', 'd', '0';
                     'd', '0', '-1.1*d', '0';
                     '-1.1*d', '0', '-1.1*d', '0.1';
                     '-1.1*d', '0.1', 'd', '0.1'};
                 
    Model.Body{2} =  {'l', '0.01', 'l', '-0.01';
                     'l', '-0.01', '-l', '-0.01';
                     '-l', '-0.01', '-l', '0.01';
                     '-l', '0.01', 'l', '0.01'};  
                 
    Model.Body{3} = {'l', '0.01', 'l', '-0.01';
                     'l', '-0.01', '-l', '-0.01';
                     '-l', '-0.01', '-l', '0.01';
                     '-l', '0.01', 'l', '0.01'}; 

    % Body movements for animation
    Model.BodyMovements = {'0',  'y1',  '0';
                           '-l*cos(asin(y1/(2*l))) + l*cos(asin(y10/(2*l)))', 'y1/2' , 'asin(y1/(2*l))';
                           '-l*cos(asin(y1/(2*l))) + l*cos(asin(y10/(2*l)))', 'y1/2' , '-asin(y1/(2*l))'};
                           
                           
    
    % Lines for animation
    Model.Lines = {'0.97', '0', '0.97',  'y1'};      

                       
%% Ventana para representar animacion
    Model.Viewport = {'-1.5 ', '1.5', ' 0', ' 1'};

%% Plots x-y for Dynamics
    Model.NumSubplotsDynamics = {3, 1};
    Model.SubplotsDynamics= {'t', 'Tiempo (s)', 'y1', 'Desplazamiento y cuerpo 1 (m)';
                             't', 'Tiempo (s)', 'y1dot', 'Velocidad y cuerpo 1 (m/2)';
                             't', 'Tiempo (s)', 'y1dotdot', 'Aceleracion y cuerpo 1 (m/s2)'};    

%% Construction of MatLab model. DO NOT MODIFY
    Construct_(Model);


