function output= Construct_Constraints_and_Jacobian_(Model)

    F= [Model.Constraints; Model.Drivers];
    q= Model.q;
    J= jacobian(F, q);
 
    driver= Model.Drivers;
    
    neq = length(F);
    model_rank = rank(J);
    model_size = length(q);
    ngdl = length(driver);
    
    if  neq ~= model_size
        fprintf ('ERROR: Incorrect definition of constraints \n');
        fprintf ('       Number of constraints (%2.f) different to Number of variables (%2.f)\n', neq, model_size);
        fprintf ('       It is not possible to construct Kinematics_%s.m \n\n',Model.Name);
        output = false;
        return
    elseif  model_rank < model_size
        fprintf ('ERROR: Incorrect definition of constraints\n');
        fprintf ('       Number of independent constraints (%2.f) < Number of variables (%2.f)\n', model_rank, model_size);
        fprintf ('       It is not possible to construct Kinematics_%s.m \n\n',Model.Name);
        output = false;
        return
    end
    
    for i=1:length(q)
        F = subs(F, q(i), str2sym(sprintf('q(%.0f)',i)));
        J = subs(J, q(i), str2sym(sprintf('q(%.0f)',i)));
        fprintf('.');
    end
    
    for i=1:length(F)
        model_constraints{i,1}= sprintf('     Constraints_(%.0f)= %s;', i, F(i));
        fprintf('.');
   end

    for i=1:size(J,1)
        model_jacobian{i,1}= sprintf('     Jacobian_(%.0f,:)= [ ', i);
        for j=1:size(J,2)
            if j<size(J,2)
                model_jacobian{i,1}= strcat(model_jacobian{i,1}, sprintf(' %s, ', J(i,j)));
            else
                model_jacobian{i,1}= strcat(model_jacobian{i,1}, sprintf(' %s ', J(i,j)));
            end
        end
        model_jacobian{i,1}= strcat(model_jacobian{i,1}, sprintf('];'));
        fprintf('.');
    end

%% Construct constraints function
    fileconstraints = fopen(sprintf('Constraints_%s.m', Model.Name), 'w');

    fprintf(fileconstraints, 'function Constraints_ = Constraints_%s(q,t)\n\n', Model.Name);

    fprintf(fileconstraints, '%s \n', '%% Model parameters');
    fprintf(fileconstraints, '      Param= Parameters_%s(t,q);\n\n',Model.Name);
    s1=[symvar(q),'t'];
    s2=symvar(F);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(fileconstraints, '      %s= Param.%s;\n',s2(i),s2(i));
        end
    end   
    
    fprintf(fileconstraints, ' \n');
  
    fprintf(fileconstraints, '%s \n', '%% Kinematic constraints');
    for i=1:length(F)-length(driver)
        fprintf(fileconstraints, ' %s \n', model_constraints{i,1});
    end
    fprintf(fileconstraints, ' \n');

    fprintf(fileconstraints, '%s \n', '%% Drivers');
    for i=length(F)-length(driver)+1:length(F)
        Fsubs = subs(F(i), driver(i-length(F)+length(driver)), str2sym(sprintf('driver(%.0f);', i-length(F)+length(driver))));
        fprintf(fileconstraints, '      Constraints_(%.0f) = %s; \n', i, Fsubs);
    end

    fprintf(fileconstraints, ' \n%s \n\n', 'end');
    fclose(fileconstraints);
    
%% Construct Jacobian function
    fileconstraints = fopen(sprintf('Jacobian_%s.m',Model.Name), 'w');

    fprintf(fileconstraints, 'function Jacobian_ = Jacobian_%s(q,t)\n',Model.Name);

    fprintf(fileconstraints, '%s \n', '%% Model parameters');
    fprintf(fileconstraints, '      Param= Parameters_%s(t,q);\n\n',Model.Name);
    s1=symvar(q);
    s2=symvar(J);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(fileconstraints, '      %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(fileconstraints, '\n');

    fprintf(fileconstraints, '%s \n', '%% Jacobian matrix. Rows correspondring to the kinematic constraints');
    for i=1:length(F)-length(driver)
        fprintf(fileconstraints, ' %s \n', model_jacobian{i,1});
    end

    fprintf(fileconstraints, '\n%s \n', '%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers');
    for i=length(F)-length(driver)+1:length(F)
        fprintf(fileconstraints, ' %s \n', model_jacobian{i,1});
    end

    fprintf(fileconstraints, '\n%s\n', 'end');
    fclose(fileconstraints);

    fprintf('\nConstructed %s and %s\n', sprintf('Constraints_%s.m', Model.Name), sprintf('Jacobian_%s.m', Model.Name));

    output = true;
    
end
