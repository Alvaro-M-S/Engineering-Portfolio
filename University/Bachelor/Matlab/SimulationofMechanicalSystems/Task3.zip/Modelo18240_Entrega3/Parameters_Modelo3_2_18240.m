function Param = Parameters_Modelo3_2_18240(t,x)

%% Model Parameters 
    l = 1; 
    d = 1.2; 
    M1 = 250; 
    J1 = 100; 
    g = 9.8; 
    K1 = 5000; 
    R1 = 500; 
    y10=0.7; 

    Param.l = l; 
    Param.d = d; 
    Param.M1 = M1; 
    Param.J1 = J1; 
    Param.g = g; 
    Param.K1 = K1; 
    Param.R1 = R1; 
    Param.y10 = y10; 
 
end 

