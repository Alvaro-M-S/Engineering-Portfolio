function Jacobian_ = Jacobian_Modelo3_2_18240(q,t)
%% Model parameters 
      Param= Parameters_Modelo3_2_18240(t,q);

      d= Param.d;
      l= Param.l;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      Jacobian_(1,:)= [ 0, 0, 0, 1, 0, -l*sin(q(6)), 0, 0, 0]; 
      Jacobian_(2,:)= [ 0, 0, 0, 0, 1, l*cos(q(6)), 0, 0, 0]; 
      Jacobian_(3,:)= [ 0, 0, 0, 1, 0, 0, -1, 0, 0]; 
      Jacobian_(4,:)= [ 0, 0, 0, 0, 1, 0, 0, -1, 0]; 
      Jacobian_(5,:)= [ 1, 0, -d*sin(q(3)), 0, 0, 0, -1, 0, l*sin(q(9))]; 
      Jacobian_(6,:)= [ 0, 1, d*cos(q(3)), 0, 0, 0, 0, -1, -l*cos(q(9))]; 
      Jacobian_(7,:)= [ sin(q(3)), -cos(q(3)), cos(q(3))*(q(1) - q(4) + l*cos(q(6))) + sin(q(3))*(q(2) - q(5) + l*sin(q(6))), -sin(q(3)), cos(q(3)), - l*cos(q(3))*cos(q(6)) - l*sin(q(3))*sin(q(6)), 0, 0, 0]; 
      Jacobian_(8,:)= [ 0, 0, 0, 0, 0, 0, 0, 1, -l*cos(q(9))]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      Jacobian_(9,:)= [ 0, 1, 0, 0, 0, 0, 0, 0, 0]; 

end
