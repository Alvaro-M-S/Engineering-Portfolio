function output= Construct_Subplots_Energy_(Model)
    numberofsubplots= Model.NumSubplotsDynamics;
    
    syms t
    xplot= Model.xplot;
    neq= length(xplot);
    
    syms x t;
 
    for i=1:length(xplot)
        xvarplot(i,1) = str2sym(sprintf('x(%.0f)',i));
    end
    tvarplot(1,1) = str2sym(sprintf('t(%.0f)',1));
    
    if Model.NumberofT
       T= Model.T;
       Tplot = subs(T, xplot, xvarplot);
    else
       Tplot = '';
    end
    
    if Model.NumberofV
        V= Model.V;
        for j=1:length(V)
            Vplot(j) = V(j);
            if Model.NumberofLinks
                if contains(string(Vplot(j)),string(Model.OutputVariable))
                    Vplot(j)=0;
                end
            end
            fprintf('.');
        end
        Vplot = subs(Vplot, xplot, xvarplot);
        Vplot = subs(Vplot, t, tvarplot);
        for i=1:length(Model.q)
            Vplot = subs(Vplot, Model.q0(i), str2sym(sprintf('x_0(%.0f)',i)));
        end
%         syms t
%         Vplot = subs(Vplot, t, str2sym(sprintf('t(%c)','i')));
    else
        Vplot = '';
    end
    

    if Model.NumberofR
       R= Model.R;
       Rplot = subs(R, xplot, xvarplot);
    else
       Rplot = '' ;  
    end
        
    try
        Forceplot= Model.Forceplot;
        Forceplot = subs(Forceplot, xplot, xvarplot);
    catch
        Forceplot='';  
    end
        

    %% Construct Subplots_Energy_
% % %     filename = fopen(sprintf('Subplots_Energy_%s.m', Model.Name), 'w');
	filename=Model.filename;
    fprintf(filename, 'function U = Subplots_Energy_%s(x_0,t,x)\n\n', Model.Name);

%% Model Parameters    
    fprintf(filename, '     for i=1:size(x,1)\n');
    fprintf(filename, '%s \n', '     %% Model Parameters');
    fprintf(filename, '         Param= Parameters_%s(t(i),x(i,:));\n\n',Model.Name);
    s1=[symvar(xplot),'t'];
    s2=[symvar(Tplot), symvar(Rplot), symvar(Vplot), symvar(Forceplot), ];
    for i=1:length(s2)
        if ~ismember(s2(i),s1)
            fprintf(filename, '         %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, ' \n');
    fprintf(filename, '         X(i) = t(i);\n');
    for i=1:length(Tplot)
        str1 = sprintf('         YT(%0.f, i) = %s;\n',i,Tplot(i));
        str1=replace(str1, 'x(', 'x(i,');
        fprintf(filename, '%s',str1);
    end
    for i=1:length(Vplot)
%         Vplot = subs(Vplot, t, str2sym(sprintf('t(%c)','i')));
        str1 = sprintf('         YV(%0.f, i) = %s;\n',i,Vplot(i));
        str1=replace(str1, 'x(', 'x(i,');
        str1=replace(str1, 't(1)', 't(i)');
        fprintf(filename, '%s',str1);
    end
    if ~isempty(Rplot)
        for i=1:length(Rplot)
            str1 = sprintf('         YR(%0.f, i) = %s;\n',i,Rplot(i));
            str1=replace(str1, 'x(', 'x(i,');
            fprintf(filename, '%s',str1);
        end
    end
    
    fprintf(filename, '     end\n');
    
    fprintf(filename, ' %s \n\n', '%% Energy subplots');

    filasgraficas = 3;
    columnasgraficas = 2;
    
%% Plot T    
    fprintf(filename, '     subplot(3,2,1);\n');
    fprintf(filename, '     title(''Kinetic Energy'');\n');
    fprintf(filename, '     hold on;\n');
    fprintf(filename, '     plot(');
    for i=1:length(Tplot)
        fprintf(filename, 'X, YT(%0.f,:)', i);
        if i<length(Tplot)
            fprintf(filename, ', ');
        else
            fprintf(filename, ');\n');
        end
    end
    fprintf(filename, '     T_Tot = sum(YT,1);\n');
    fprintf(filename, '     grid on\n');            
    fprintf(filename, '     box on\n'); 
    fprintf(filename, '     legend(');
    for i=1:length(Tplot)
        fprintf(filename, '''T%0.f''', i);
        if i<length(Tplot)
            fprintf(filename, ', ');
        else
            fprintf(filename, ');\n');
        end
    end
    fprintf(filename, '     hold off\n\n');

%% Plot V
    fprintf(filename, '     subplot(3,2,2);\n');
    fprintf(filename, '     title(''Potential Energy'');\n');
    fprintf(filename, '     hold on;\n');
    fprintf(filename, '     V_Tot = sum(YV,1);\n');
    fprintf(filename, '     plot(');
    for i=1:length(Vplot)
        fprintf(filename, 'X, YV(%0.f,:)', i);
        if i<length(Vplot)
            fprintf(filename, ', ');
        else
            fprintf(filename, ');\n');
        end
    end
    fprintf(filename, '     grid on\n');            
    fprintf(filename, '     box on\n'); 
    fprintf(filename, '     legend(');
    for i=1:length(Vplot)
        fprintf(filename, '''V%0.f''', i);
        if i<length(Vplot)
            fprintf(filename, ', ');
        else
            fprintf(filename, ');\n');
        end
    end
    fprintf(filename, '     hold off\n\n');
    
%% Plot R
    fprintf(filename, '     subplot(3,2,3);\n');
    fprintf(filename, '     title(''Disipative Energy'');\n');
    fprintf(filename, '     hold on;\n');
    if ~isempty(Rplot)
        fprintf(filename, '     plot(');
        for i=1:length(Rplot)
            fprintf(filename, 'X, YR(%0.f,:)', i);
            if i<length(Rplot)
                fprintf(filename, ', ');
            else
                fprintf(filename, ');\n');
            end
        end
        fprintf(filename, '     R_Tot = sum(YR,1);\n');
        fprintf(filename, '     legend(');
        for i=1:length(Rplot)
            fprintf(filename, '''R%0.f''', i);
            if i<length(Rplot)
                fprintf(filename, ', ');
            else
                fprintf(filename, ');\n');
            end
        end
    else
        fprintf(filename, '     R_Tot = 0;\n');        
    end
    fprintf(filename, '     grid on\n');            
    fprintf(filename, '     box on\n'); 
    fprintf(filename, '     hold off\n\n');

 %% Plot Forces  
    fprintf(filename, '     subplot(3,2,4);\n');
    fprintf(filename, '     title(''Energy in couplings'');\n');
    fprintf(filename, '     hold on;\n');
    if ~isempty(Forceplot)
        fprintf(filename, '     for i=1:size(x,1)\n');
        fprintf(filename, '         X(i) = t(i);\n');
        for i=1:length(Forceplot)
            if Forceplot(i)==0
                str1 = sprintf('         YR(%0.f, i) = %s;\n',i,'0');
            else
                str1 = sprintf('         YR(%0.f, i) = %s;\n',i,Forceplot(i));
            end
            str1=replace(str1, 'x(', 'x(i,');
            fprintf(filename, '%s',str1);
        end
        fprintf(filename, '     end\n');
        fprintf(filename, '     plot(');
        for i=1:length(Forceplot)
            fprintf(filename, 'X, YR(%0.f,:)', i);
            if i<length(Forceplot)
                fprintf(filename, ', ');
            else
                fprintf(filename, ');\n');
            end
        end
        fprintf(filename, '     Force_Tot = -sum(YR,1);\n');
        fprintf(filename, '     legend(');
        for i=1:length(Forceplot)
            fprintf(filename, '''Force%0.f''', i);
            if i<length(Forceplot)
                fprintf(filename, ', ');
            else
                fprintf(filename, ');\n');
            end
        end
    else
        fprintf(filename, '     Force_Tot = 0;\n');        
    end
    fprintf(filename, '     grid on\n');            
    fprintf(filename, '     box on\n'); 
    fprintf(filename, '     hold off\n\n');

%% Plot all
    fprintf(filename, '     subplot(3,2,[5,6]);\n');
    fprintf(filename, '     title(''Total Energy'');\n');
    fprintf(filename, '     hold on;\n');
    fprintf(filename, '     plot(X, T_Tot);\n');
    fprintf(filename, '     plot(X, V_Tot);\n');
    fprintf(filename, '     plot(X, T_Tot+V_Tot);\n');
    fprintf(filename, '     plot(X, T_Tot+V_Tot+R_Tot);\n');
    fprintf(filename, '     plot(X, T_Tot+V_Tot+R_Tot+Force_Tot,''LineWidth'',2,''Color'',''red'')\n');
    fprintf(filename, '     grid on\n');            
    fprintf(filename, '     box on\n'); 
    fprintf(filename, '     legend(''T'',''V'',''T+V'',''T+V+R'',''T+V+R+F'');\n');
    fprintf(filename, '     hold off\n\n');

    fprintf(filename, ' \n%s \n\n', 'end');
    
    fprintf('\nConstructed %s \n\n', sprintf('Subplots_Energy_%s.m', Model.Name));

    output = true;

end
