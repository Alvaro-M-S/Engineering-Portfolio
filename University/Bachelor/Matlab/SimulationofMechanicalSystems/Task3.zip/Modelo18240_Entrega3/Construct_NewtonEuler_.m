function output = Construct_NewtonEuler_(Model)
        
    syms t x xdot;
    
    Constraint= Model.Constraints;
    Driver= Model.Drivers;
    q= Model.q;
    Q= Model.Q;
    q0= Model.q0;
    qdot= Model.qdot;
    Qdot= Model.Qdot;
    vel= Model.vel;
    veldot= Model.veldot;
    Vel= Model.Vel;
    Veldot= Model.Veldot;
   
    nVariables = length(Model.q);
    neq = length(Model.Constraints);
    ngdl= length(Model.Drivers);
    
    J = jacobian(Constraint, q);
    
    for i=1:nVariables
        J = subs(J, q(i), Q(i));
        J = subs(J, qdot(i), Qdot(i));
        fprintf('.');
    end

    NumberOfMultipliers = Model.NumOfLagrangeMultipliers;
    if NumberOfMultipliers
        LagrangeMultipliers = Model.LagrangeMultipliers;
        LagrangeMultipliersdot = Model.LagrangeMultipliersdot;
        LM = Model.LM;
        LMdot = Model.LMdot;
    end
    x = Model.x;
    xdot = Model.xdot;
    X = Model.X;
    Xdot = Model.Xdot;
    
%% Forces. Momentum and MassMatrix
    try
        forces = Model.Forces;
    catch
        forces = zeros(length(q),1);
    end
    
    try
        massMatrix = Model.MassMatrix;
    catch
        massMatrix = zeros(length(q),length(q));
    end

    try
        momentum = Model.LinearAngularMomentum;
    catch
        momentum = zeros(length(q),1);
    end
    
    Q0 = Model.Q0;

    Momentum= subs(momentum, [q;qdot], [Q;diff(Q,t)]);
    Forces= subs(forces, [q;qdot;q0], [Q;diff(Q,t);Q0]);
    MassMatrix= subs(massMatrix, [q;qdot], [Q;diff(Q,t)]);
    dMomentumdt = simplify(diff(Momentum,t));

    if NumberOfMultipliers>0
        LagrangeMultipliersTerm = J.'*LMdot;
    else
        LagrangeMultipliersTerm = 0;
    end
    Model.NewtonEulerEquations = simplify(dMomentumdt - LagrangeMultipliersTerm - Forces);

%% Construction of Newton-Euler equations    
    Model.IntegralEquations = Qdot- Vel ;
    Model.ConstraintsEquations = J*Qdot;

    ntotalequations= 3*nVariables-ngdl;
    
    Parameters= Model.Parameters;
    
%% Add Links
    if Model.NumberofLinks
        neqBG = sum(Model.neqBGi);
        if ~strcmp(Model.Links,'') 
            Links=subs(Model.Links,q,Q);
            OutputForce = Model.OutputForce;

            for i=1:size(Links,1)
                Model.SubmodelEquations{i}= transpose(Model.output{i}.equations);
            end
            ntotalequations= ntotalequations + neqBG;
        end
    else
        neqBG = 0;
    end

%% Construct parameters    
    Construct_Parameters_(Model);
    
%% Construct equations 
    if Model.NumOfLagrangeMultipliers
        Model.NewtonEulerEquations = subs(Model.NewtonEulerEquations, [diff(Q,t,t); diff(Q,t); Q; diff(LM,t)], [veldot; vel; q; LagrangeMultipliersdot]);
        Model.IntegralEquations = subs(Model.IntegralEquations, [diff(Q,t); Vel], [qdot; vel]);
        Model.ConstraintsEquations = subs(Model.ConstraintsEquations, [Qdot; Q], [vel; q]);
        Model.SystemEquations = [Model.NewtonEulerEquations; Model.IntegralEquations; Model.ConstraintsEquations];
    else
        Model.NewtonEulerEquations = subs(Model.NewtonEulerEquations, [diff(Q,t,t); diff(Q,t); Q], [veldot; vel; q]);
        Model.IntegralEquations = subs(Model.IntegralEquations, [diff(Q,t); Vel], [qdot; vel]);
        Model.SystemEquations = [Model.NewtonEulerEquations; Model.IntegralEquations];
    end
    if Model.NumberofLinks
        for i=1:Model.NumberofLinks
            Model.SubmodelEquations{i} = subs(Model.SubmodelEquations{i}, [Qdot; Q], [vel; q]);
            Model.SystemEquations = [Model.SystemEquations; Model.SubmodelEquations{i}];
            Model.OutputsEquations(i) = subs(Model.OutputForce(i), [diff(Q,t); Q; Model.output{i}.Q], [vel; q; Model.output{i}.q]);
        end
    end
    SystemEquations= subs(Model.SystemEquations,[Xdot;X],[xdot;x]);

    JacobianVars=jacobian(SystemEquations,x);
    JacobianVarsdot=jacobian(SystemEquations,xdot);
    
    NewtonEulerEquations_Implicit= SystemEquations;
    JacobianVars_Implicit = JacobianVars;
    JacobianVarsdot_Implicit = JacobianVarsdot;
    
    NewtonEulerEquations_SemiExplicit = expand(JacobianVarsdot*xdot - SystemEquations);
    JacobianVars_SemiExplicit = JacobianVars;
    JacobianVarsdot_SemiExplicit = JacobianVarsdot;

    for i=1:ntotalequations
       VectorofVariablesdot(i,1)= str2sym(sprintf('xdot(%.0f)',i));
       VectorofVariables(i,1)= str2sym(sprintf('x(%.0f)',i));
       fprintf('.');
    end
    
    if Model.NumberofLinks
        Model.OutputsEquations = subs(Model.OutputsEquations, [xdot; x], [VectorofVariablesdot; VectorofVariables]);
    end

%% Construct NewtonEuler_Dynamics_    
    filename= Model.filename;
    
    fprintf(filename, '%s \n\n', strcat('function Dynamics_NewtonEulerEquations_',Model.Name,'(Model)'));
    
    fprintf(filename, '%s \n', '     close all');
    fprintf(filename, '%s \n\n', '     clc');
    
    fprintf(filename, '%s \n\n', '     %% General variables'); 
    fprintf(filename, '     Model = ''%s'';\n\n', Model.Name);

    fprintf(filename, '     neq = %.0f; \n', neq+ngdl);
    fprintf(filename, '     ngdl = %.0f; \n', ngdl);
    fprintf(filename, '     neqBG = %.0f; \n\n', sum(neqBG));
 
 %% Parametros del Modelo    
    fprintf(filename, '     %% Model parameters \n');
    fprintf(filename, '     Param= Parameters_%s(0,zeros(%.0f,1));\n\n',Model.Name,neq+ngdl+sum(neqBG));
    s1=[symvar(q),'t'];
    s2=symvar(Model.Initial_conditions);
    try
        s3=symvar(Links(:,5));
        for i=1:length(s2)
            if ~ismember(s2(i),s1) && ~ismember(s2(i),s3)
                fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
            end
        end
    catch
        for i=1:length(s2)
            if ~ismember(s2(i),s1) 
                fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
            end
        end
    end
    s1=symvar([s1, s2]);
    s2=symvar(Model.Drivers);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, ' \n');
   
    fprintf(filename, '%s \n', '     %% Define initial conditions'); 
    fprintf(filename, '     q = ['); 
    for i=1:length(Model.Initial_conditions)-1
        fprintf(filename, '%s; ', Model.Initial_conditions(i)); 
    end
    fprintf(filename, '%s]; \n\n', Model.Initial_conditions(end)); 
    
    if Model.NumberofLinks
        fprintf(filename, '%s \n', '     %% Define submodels initial conditions'); 
        fprintf(filename, '     qsubmod = ['); 
        for i=1:length(Model.output)
            for j=1:length(Model.output{i}.InitialConditions)
                if i==length(Model.output) && j==length(Model.output{i}.InitialConditions)
                    fprintf(filename, '%s', Model.output{i}.InitialConditions(j)); 
                else
                    fprintf(filename, '%s; ', Model.output{i}.InitialConditions(j)); 
                end
            end
        end
        fprintf(filename, ']; \n\n'); 
    end
    
    fprintf(filename, '     t = 0;\n');   
    fprintf('.');
    
    fprintf(filename, '%s \n', '     %% Solve mechanism initial position'); 
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     figure(''Name'', ''Initial position dined by the user'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(q);\n\n',Model.Name); 
    end
    fprintf(filename, '%s \n', '     S = Displacements_(Model, q, t);'); 
    fprintf(filename, '%s \n', '     q0 = S;'); 
    fprintf('.');
    
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     figure(''Name'', ''Adjusted initial postion'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(S);\n\n',Model.Name); 
        fprintf('.'); 
    end
    
    fprintf(filename, '%s \n', '     %% Number of differential-agebraic equations to be solved'); 
    fprintf(filename, '%s \n\n', '     numberofDAEequations = 2*neq+(neq-ngdl)+neqBG;'); 

    fprintf(filename, '%s \n', '     %% Initial conditions for dynamic analysis'); 
    fprintf(filename, '%s \n\n', '     x = zeros(numberofDAEequations,1);'); 
    fprintf('.');

    fprintf(filename, '%s \n', '     xp=zeros(numberofDAEequations,1);'); 
    fprintf(filename, '%s \n', '     fixed_x0=zeros(numberofDAEequations,1);'); 
    fprintf(filename, '%s \n\n', '     fixed_xp0=zeros(numberofDAEequations,1);'); 
    fprintf('.');
    
    %% Call to integrator
    fprintf(filename, '     tspan = %s; \n\n', Model.t);

    %% Initial conditions for dynamics 
    fprintf(filename, '%s \n', '     x = zeros(numberofDAEequations,1); ');
    fprintf(filename, '%s \n', '     x(neq+1:2*neq)= q0; %% Initial position ');
    if Model.NumberofLinks
        fprintf(filename, '%s \n', '     x(2*neq+(neq-ngdl)+1:2*neq+(neq-ngdl)+neqBG)= qsubmod; % Submodels initial positions'); 
    end
    fprintf(filename, '%s \n', '     xp=zeros(numberofDAEequations,1); ');
    fprintf(filename, '%s \n', '     fixed_x0=zeros(numberofDAEequations,1); ');
    fprintf(filename, '%s \n\n', '     fixed_xp0=zeros(numberofDAEequations,1); ');

    if strcmp(Model.Solver,'nonstiffsemiexplicit')
        Solver='ode23t';
    elseif strcmp(Model.Solver,'stiffsemiexplicit')
        Solver='ode15s';
    else
        Solver='ode15i';
    end
    
    fprintf(filename, '     solver = ''%s''; \n', Solver );
    fprintf(filename, '%s \n', '     y0_guess = x;   ');
    fprintf(filename, '%s \n', '     yp_guess = zeros(numberofDAEequations,1);');   
    
    if strcmp(Model.Solver,'nonstiffsemiexplicit') || strcmp(Model.Solver,'stiffsemiexplicit')
        fprintf(filename, '     %% Model responding to the form Mq''=f(t,q) \n');
        fprintf(filename, '     %% with Differential Algebraic Equations (DAE) \n');
        fprintf(filename, '     %% The function f(t,q) uses the semiexplicit equations form\n');
        fprintf(filename, '     MassMatrixNewtonEuler = str2func(sprintf(''MassMatrixNewtonEuler_%%s'',Model)); \n');
        fprintf(filename, '     System%s_NewtonEuler = str2func(sprintf(''eqNewtonEulerSemiexplicit_%%s'',Model)); \n',Solver);
        fprintf(filename, '     ImplicitDAE = @(time,y,yp) MassMatrixNewtonEuler(q0,time,y)*yp - System%s_NewtonEuler(q0,time,y);\n',Solver);
        fprintf(filename, '     [x_0,xp_0,resnrm] = decic(ImplicitDAE,0,x,fixed_x0,xp,fixed_xp0); %%Determine consistent yp0\n');
        fprintf(filename, '     options = odeset(''Mass'', @(time,y) MassMatrixNewtonEuler(q0,time,y), ''InitialSlope'', xp_0, ''RelTol'',1.0e-3, ''AbsTol'', 1.0e-5);\n'); 
        fprintf(filename, '     [t1,x] = %s(@(time,y) System%s_NewtonEuler(q0,time,y), tspan, x_0, options);\n\n',Solver,Solver); 
        fprintf(filename, '     tini=tspan(1);\n');
        fprintf(filename, '     tend=tspan(end);\n');
        fprintf(filename, '     deltat=(tend-tini)/(length(tspan)-1);\n');
        fprintf(filename, '     xp= diff(x,1,1)/deltat;\n');
        fprintf(filename, '     xp(end+1,:)= xp(end,:);\n\n');
    elseif strcmp(Model.Solver,'implicit')   
        fprintf(filename, '     %% Model responding to the form f(t,q,q'')=0 \n');
        fprintf(filename, '     %% with Differential Algebraic Equations (DAE) \n');
        fprintf(filename, '     %% The function f(t,q,q'') uses the implicit equations form \n');
        fprintf(filename, '     System%s_NewtonEuler = str2func(sprintf(''eqNewtonEulerImplicit_%%s'',Model));\n',Solver);
        fprintf(filename, '     JacobianSolver = str2func(sprintf(''JacobianSolver_%%s'',Model));\n');
        fprintf(filename, '     [x_0,xp_0,resnrm] = decic(@(time,y,yp) System%s_NewtonEuler(q0, time, y, yp),0,x,fixed_x0,xp,fixed_xp0); %%Determina yp0 Consistentes \n', Solver);
        fprintf(filename, '     options = odeset(''RelTol'',1.0E-3,''AbsTol'',1.0E-6,''Jacobian'', @(time,y,yp) JacobianSolver(x_0,time,y,yp));\n');
        fprintf(filename, '     [t1,x] = %s(@(time,y,yp) System%s_NewtonEuler(q0, time, y, yp), tspan, x_0, xp_0,options); \n\n',Solver,Solver);
        fprintf(filename, '     tini=tspan(1);\n');
        fprintf(filename, '     tend=tspan(end);\n');
        fprintf(filename, '     deltat=(tend-tini)/(length(tspan)-1);\n');
        fprintf(filename, '     xp= diff(x,1,1)/deltat;\n');
        fprintf(filename, '     xp(end+1,:)= xp(end,:);\n\n');
    else
        output=false;
        sprintf('     Incorrect solver definition (%s) \n\n',Model.Solver);
        return
    end
    fprintf('.');
    
    fprintf(filename, '     h = now;\n'); 
    fprintf(filename, '     dir = pwd;\n'); 
    fprintf(filename, '     save %s;\n\n',Model.Name); 

    if Model.ExistDynamicPlots
        fprintf(filename, '%s \n', '     %% Plots for Dynamics'); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''x-y plots for Dynamics'', ''Color'', ''white'');'); 
        fprintf(filename, '     Subplots_Dynamics_%s(q0,t1,x,xp);\n\n',Model.Name); 
    end
    
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     %% Dynamics Animation'); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''Dynamics Animation'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(x(:,neq+1:2*neq)'');\n\n',Model.Name); 
    end
    fprintf(filename, 'end\n\n');
    fprintf('.');

    fprintf('\nConstructed Dynamics_NewtonEulerEquations_%s.m \n',Model.Name);

%% Construct eqNewtonEulerImplicit
    if strcmp(Model.Solver,'implicit')
        fprintf(filename, 'function equations = eqNewtonEulerImplicit_%s(x_0, t, x, xdot)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=symvar(Parameters);
        try
            s2=symvar([NewtonEulerEquations_Implicit; OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch
            s2=symvar(NewtonEulerEquations_Implicit);
            for i=1:length(s2)
                if ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% NewtonEuler implicit equations');
        NewtonEulerEquations_Implicit = simplify(subs(NewtonEulerEquations_Implicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(NewtonEulerEquations_Implicit)
            fprintf(filename, '       equations(%0.f,1) = %s; \n', i, NewtonEulerEquations_Implicit(i));
            fprintf('.');
        end
        fprintf(filename, '\n       dispstat(sprintf(''  t = %%8.2f'',t));\n'); 
        fprintf(filename, ' \nend \n\n');   

        fprintf('\nConstructed eqNewtonEulerImplicit_%s.m \n',Model.Name);
    end

%% Construct eqNewtonEulerSemiexplicit
    if ~strcmp(Model.Solver,'implicit')

        fprintf(filename, 'function equations = eqNewtonEulerSemiexplicit_%s(x_0, t, x)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=symvar(Parameters);

        try
            s2=symvar([NewtonEulerEquations_SemiExplicit; OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch
            s2=symvar(NewtonEulerEquations_SemiExplicit);
            for i=1:length(s2)
                if ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% Semiexplicit Equations');
        NewtonEulerEquations_SemiExplicit = simplify(subs(NewtonEulerEquations_SemiExplicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(NewtonEulerEquations_SemiExplicit)
            fprintf(filename, '       equations(%0.f,1) = %s; \n', i, NewtonEulerEquations_SemiExplicit(i));
            fprintf('.');
        end
        fprintf(filename, '\n       dispstat(sprintf(''  t = %%8.2f'',t));\n'); 

        fprintf(filename, ' \n%s \n\n', 'end');   
        fprintf('\nConstructed eqNewtonEulerSemiexplicit_%s.m \n',Model.Name);
    end
    
%% Construct MassMatrixNewtonEuler  
    if ~strcmp(Model.Solver,'implicit')
        fprintf(filename, 'function Mass_equations = MassMatrixNewtonEuler_%s(x_0, t, x)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=[symvar(q),'t'];
        try
            s2=[symvar(JacobianVarsdot_SemiExplicit), symvar(Model.OutputForce)];
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ~ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch 
            s2=symvar(JacobianVarsdot_SemiExplicit);
            for i=1:length(s2)
                if ~ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% Mass Matrix for NewtonEuler Equations');
        JacobianVarsdot_SemiExplicit = simplify(subs(JacobianVarsdot_SemiExplicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(Model.SystemEquations)
            for j=1:length(Model.SystemEquations)
                if j==1
                    fprintf(filename, '       Mass_equations(%0.f,:) = [ %s, ', i, JacobianVarsdot_SemiExplicit(i,j));
                elseif j<length(Model.SystemEquations)
                    fprintf(filename, '%s, ', JacobianVarsdot_SemiExplicit(i,j));
                else
                    fprintf(filename, '%s];\n', JacobianVarsdot_SemiExplicit(i,j));
                end
            end
            fprintf('.');
        end
        fprintf(filename, ' \n%s \n\n', 'end');        
        fprintf('\nConstructed MassMatrixNewtonEuler_%s.m \n',Model.Name);
    end
    
%% Construct JacobianSolver
    if strcmp(Model.Solver,'implicit')
        fprintf(filename, 'function [dfdy, dfdp] = JacobianSolver_%s(x_0, t, x, xdot)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=[symvar(q),'t'];
        try
            s2=symvar([NewtonEulerEquations_Implicit; Model.OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ~ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch 
            s2=symvar(NewtonEulerEquations_Implicit);
            for i=1:length(s2)
                if ~ismember(s2(i),s1) 
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s\n', '%% Variables jacobian');
        JacobianVars_Implicit = simplify(subs(JacobianVars_Implicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(Model.SystemEquations)
            fprintf(filename, '       dfdy(%0.f,:) = [', i);
            for j=1:length(Model.SystemEquations)-1
                fprintf(filename, '%s, ', JacobianVars_Implicit(i,j));
            end
            fprintf(filename, '%s];\n', JacobianVars_Implicit(i,length(Model.SystemEquations)));
            fprintf('.');
        end
        fprintf(filename, '\n');   

        fprintf(filename, '%s\n', '%% Derivatives jacobian');
        JacobianVarsdot_Implicit = simplify(subs(JacobianVarsdot_Implicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));
        for i=1:length(Model.SystemEquations)
            fprintf(filename, '       dfdp(%0.f,:) = [', i);
            for j=1:length(Model.SystemEquations)-1
                fprintf(filename, '%s, ', JacobianVarsdot_Implicit(i,j));
            end
            fprintf(filename, '%s];\n', JacobianVarsdot_Implicit(i,length(Model.SystemEquations)));
            fprintf('.');
        end
        fprintf(filename, ' \n%s \n\n', 'end');   

        fprintf('\nConstructed JacobianSolver_%s.m \n',Model.Name);
    end   
        
    output = true;

end


