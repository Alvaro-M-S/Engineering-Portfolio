function Constraints_ = Constraints_Modelo3_2_18240(q,t)

%% Model parameters 
      Param= Parameters_Modelo3_2_18240(t,q);

      d= Param.d;
      l= Param.l;
      y10= Param.y10;
 
%% Kinematic constraints 
      Constraints_(1)= q(4) + l*cos(q(6)); 
      Constraints_(2)= q(5) + l*sin(q(6)); 
      Constraints_(3)= q(4) - q(7); 
      Constraints_(4)= q(5) - q(8); 
      Constraints_(5)= q(1) - q(7) + d*cos(q(3)) - l*cos(q(9)); 
      Constraints_(6)= q(2) - q(8) + d*sin(q(3)) - l*sin(q(9)); 
      Constraints_(7)= sin(q(3))*(q(1) - q(4) + l*cos(q(6))) - cos(q(3))*(q(2) - q(5) + l*sin(q(6))); 
      Constraints_(8)= q(8) - l*sin(q(9)); 
 
%% Drivers 
      Constraints_(9) = q(2) - y10; 
 
end 

