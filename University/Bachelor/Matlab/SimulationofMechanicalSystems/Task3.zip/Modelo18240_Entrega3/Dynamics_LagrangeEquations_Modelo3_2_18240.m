function Dynamics_LagrangeEquations_Modelo3_2_18240(Model) 

     close all 
     clc 

     %% General variables 

     Model = 'Modelo3_2_18240';

     neq = 9; 
     ngdl = 1; 
     neqBG = 0; 

     % Model parameters 
     Param= Parameters_Modelo3_2_18240(0,zeros(9,1));

     y10= Param.y10;
 
     %% Define initial conditions 
     q = [0; y10; 0; 0; y10/2; -pi/4; 0; y10/2; pi/4]; 

     t = 0;
     %% Solve mechanism initial position 
     figure('Name', 'Initial position dined by the user', 'Color', 'white'); 
     Animation_Modelo3_2_18240(q);

     S = Displacements_(Model, q, t); 
     q0 = S; 
     figure('Name', 'Adjusted initial postion', 'Color', 'white'); 
     Animation_Modelo3_2_18240(S);

     %% Number of differential-agebraic equations to be solved 
     numberofDAEequations = 2*neq+(neq-ngdl)+neqBG; 

     %% Initial conditions for dynamic analysis 
     x = zeros(numberofDAEequations,1); 

     xp=zeros(numberofDAEequations,1); 
     fixed_x0=zeros(numberofDAEequations,1); 
     fixed_xp0=zeros(numberofDAEequations,1); 

     tspan = [0:0.005:10]; 

     x = zeros(numberofDAEequations,1);  
     x(neq+1:2*neq)= q0; %% Initial position  
     xp=zeros(numberofDAEequations,1);  
     fixed_x0=zeros(numberofDAEequations,1);  
     fixed_xp0=zeros(numberofDAEequations,1);  

     solver = 'ode23t'; 
     y0_guess = x;    
     yp_guess = zeros(numberofDAEequations,1); 
     % Model responding to the form Mq'=f(t,q) 
     % with Differential Algebraic Equations (DAE) 
     % The function f(t,q) uses the semiexplicit equations form
     MassMatrixLagrange = str2func(sprintf('MassMatrixLagrange_%s',Model)); 
     Systemode23t_Lagrange = str2func(sprintf('eqLagrangeSemiexplicit_%s',Model)); 
     ImplicitDAE = @(time,y,yp) MassMatrixLagrange(q0,time,y)*yp - Systemode23t_Lagrange(q0,time,y);
     [x_0,xp_0,resnrm] = decic(ImplicitDAE,0,x,fixed_x0,xp,fixed_xp0); %Determine consistent yp0
     options = odeset('Mass', @(time,y) MassMatrixLagrange(q0,time,y), 'InitialSlope', xp_0, 'RelTol',1.0e-3, 'AbsTol', 1.0e-5);
     [t1,x] = ode23t(@(time,y) Systemode23t_Lagrange(q0,time,y), tspan, x_0, options);

     tini=tspan(1);
     tend=tspan(end);
     deltat=(tend-tini)/(length(tspan)-1);
     xp= diff(x,1,1)/deltat;
     xp(end+1,:)= xp(end,:);

     h = now;
     dir = pwd;
     save Modelo3_2_18240;

     %% Plots for Dynamics 
     figure('Name', 'x-y plots for Dynamics', 'Color', 'white'); 
     Subplots_Dynamics_Modelo3_2_18240(q0,t1,x,xp);

     figure('Name', 'x-y plots for Energy', 'Color', 'white'); 
     Subplots_Energy_Modelo3_2_18240(q0,t1,x);

     %% Dynamics Animation 
     figure('Name', 'Dynamics Animation', 'Color', 'white'); 
     Animation_Modelo3_2_18240(x(:,neq+1:2*neq)');

end

function equations = eqLagrangeSemiexplicit_Modelo3_2_18240(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo3_2_18240(t,x);

       K1= Param.K1;
       M1= Param.M1;
       R1= Param.R1;
       d= Param.d;
       g= Param.g;
       l= Param.l;
       y10= Param.y10;


 %% Semiexplicit Equations 
       equations(1,1) = 0; 
       equations(2,1) = K1*y10 - K1*x(11) - M1*g - R1*x(2); 
       equations(3,1) = 0; 
       equations(4,1) = 0; 
       equations(5,1) = 0; 
       equations(6,1) = 0; 
       equations(7,1) = 0; 
       equations(8,1) = 0; 
       equations(9,1) = 0; 
       equations(10,1) = x(1); 
       equations(11,1) = x(2); 
       equations(12,1) = x(3); 
       equations(13,1) = x(4); 
       equations(14,1) = x(5); 
       equations(15,1) = x(6); 
       equations(16,1) = x(7); 
       equations(17,1) = x(8); 
       equations(18,1) = x(9); 
       equations(19,1) = l*x(6)*sin(x(15)) - x(4); 
       equations(20,1) = - x(5) - l*x(6)*cos(x(15)); 
       equations(21,1) = x(7) - x(4); 
       equations(22,1) = x(8) - x(5); 
       equations(23,1) = x(7) - x(1) + d*x(3)*sin(x(12)) - l*x(9)*sin(x(18)); 
       equations(24,1) = x(8) - x(2) - d*x(3)*cos(x(12)) + l*x(9)*cos(x(18)); 
       equations(25,1) = x(2)*cos(x(12)) - x(5)*cos(x(12)) - x(1)*sin(x(12)) + x(4)*sin(x(12)) - x(3)*x(10)*cos(x(12)) + x(3)*x(13)*cos(x(12)) - x(3)*x(11)*sin(x(12)) + x(3)*x(14)*sin(x(12)) - l*cos(x(12) - x(15))*x(3) + l*cos(x(12) - x(15))*x(6); 
       equations(26,1) = l*x(9)*cos(x(18)) - x(8); 

       dispstat(sprintf('  t = %8.2f',t));
 
end 

function Mass_equations = MassMatrixLagrange_Modelo3_2_18240(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo3_2_18240(t,x);

       M1= Param.M1;
       d= Param.d;
       l= Param.l;

 %% Mass Matrix for Lagrange Equations 
       Mass_equations(1,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -sin(x(12)), 0];
       Mass_equations(2,:) = [ 0, M1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, cos(x(12)), 0];
       Mass_equations(3,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, d*sin(x(12)), -d*cos(x(12)), - cos(x(12))*(x(10) - x(13) + l*cos(x(15))) - sin(x(12))*(x(11) - x(14) + l*sin(x(15))), 0];
       Mass_equations(4,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, sin(x(12)), 0];
       Mass_equations(5,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, -cos(x(12)), 0];
       Mass_equations(6,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, l*sin(x(15)), -l*cos(x(15)), 0, 0, 0, 0, l*cos(x(12) - x(15)), 0];
       Mass_equations(7,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0];
       Mass_equations(8,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, -1];
       Mass_equations(9,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -l*sin(x(18)), l*cos(x(18)), 0, l*cos(x(18))];
       Mass_equations(10,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(11,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(12,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(13,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(14,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(15,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(16,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(17,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(18,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(19,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(20,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(21,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(22,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(23,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(24,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(25,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(26,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
 
end 

function U = Subplots_Dynamics_Modelo3_2_18240(x_0,t,x_,xp_)

     %% Model parameters 
     Param= Parameters_Modelo3_2_18240(t,x_);

     l= Param.l;
 
 %% Subplots definition 

     subplot(4,2,1);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = x_(i,13) + (l*cos(x_(i,15)))/2;
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('X displacement - slider (m)');
     grid

     subplot(4,2,2);
     for i=1:size(x_,1)
         X_(i) = x_(i,10);
         Y_(i) = x_(i,11);
     end
     plot(X_,Y_);
     xlabel('X displacement - crank (m)');
     title('Y displacement - crank (m)');
     axis('equal')
     grid

     subplot(4,2,3);
     for i=1:size(x_,1)
         X_(i) = x_(i,13);
         Y_(i) = x_(i,14);
     end
     plot(X_,Y_);
     xlabel('X displacement - slider (m)');
     title('Y displacement - slider (m)');
     axis('equal')
     grid

     subplot(4,2,4);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,4);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('X acceleration - COG slider (m2/s)');
     grid

     subplot(4,2,5);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,21);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force X at A (N)');
     grid

     subplot(4,2,6);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,22);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force Y at A (N)');
     grid

     subplot(4,2,7);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,19);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force X at B (N)');
     grid

     subplot(4,2,8);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,20);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force Y at B (N)');
     grid

 
end 

function U = Subplots_Energy_Modelo3_2_18240(x_0,t,x)

     for i=1:size(x,1)
     %% Model Parameters 
         Param= Parameters_Modelo3_2_18240(t(i),x(i,:));

         M1= Param.M1;
         R1= Param.R1;
         K1= Param.K1;
         M1= Param.M1;
         g= Param.g;
         y10= Param.y10;
 
         X(i) = t(i);
         YT(1, i) = (M1*x(i,2)^2)/2;
         YV(1, i) = M1*g*x(i,11);
         YV(2, i) = (K1*(y10 - x(i,11))^2)/2;
         YR(1, i) = (R1*x(i,2)^2)/2;
     end
 %% Energy subplots 

     subplot(3,2,1);
     title('Kinetic Energy');
     hold on;
     plot(X, YT(1,:));
     T_Tot = sum(YT,1);
     grid on
     box on
     legend('T1');
     hold off

     subplot(3,2,2);
     title('Potential Energy');
     hold on;
     V_Tot = sum(YV,1);
     plot(X, YV(1,:), X, YV(2,:));
     grid on
     box on
     legend('V1', 'V2');
     hold off

     subplot(3,2,3);
     title('Disipative Energy');
     hold on;
     plot(X, YR(1,:));
     R_Tot = sum(YR,1);
     legend('R1');
     grid on
     box on
     hold off

     subplot(3,2,4);
     title('Energy in couplings');
     hold on;
     Force_Tot = 0;
     grid on
     box on
     hold off

     subplot(3,2,[5,6]);
     title('Total Energy');
     hold on;
     plot(X, T_Tot);
     plot(X, V_Tot);
     plot(X, T_Tot+V_Tot);
     plot(X, T_Tot+V_Tot+R_Tot);
     plot(X, T_Tot+V_Tot+R_Tot+Force_Tot,'LineWidth',2,'Color','red')
     grid on
     box on
     legend('T','V','T+V','T+V+R','T+V+R+F');
     hold off

 
end 

function Animation_Modelo3_2_18240(y) 

%% Model parameters 
     t=0; x=0; 
     Param= Parameters_Modelo3_2_18240(t,x);
     d= Param.d;
     l= Param.l;
     l= Param.l;

%% Bodies to be animated 
     Body{1} = [ d, 0.1, d, 0; 
                 d, 0, -1.1*d, 0; 
                 -1.1*d, 0, -1.1*d, 0.1; 
                 -1.1*d, 0.1, d, 0.1]; 

     Body{2} = [ l, 0.01, l, -0.01; 
                 l, -0.01, -l, -0.01; 
                 -l, -0.01, -l, 0.01; 
                 -l, 0.01, l, 0.01]; 

     Body{3} = [ l, 0.01, l, -0.01; 
                 l, -0.01, -l, -0.01; 
                 -l, -0.01, -l, 0.01; 
                 -l, 0.01, l, 0.01]; 

     NumberOfBodies = length(Body);
     NumberOfLines = 1;

 %% Animation viewport 
     axis equal 
     axis ([ -5 5 -1.5 1.5]);
     grid on 

     definecolor = {'r' 'g' 'b' 'm' 'k' 'r'}; 

% Begin Animation
     y = transpose(y);
     sizeoft=size(y,1);
     for j=1:NumberOfBodies
         bodydraw{j}=line(zeros(size(Body{j},1)),zeros(size(Body{j},1)));
     end
     for j=1:1
         linedraw{j}=line(zeros(1,1),zeros(1,1));
     end
     for i1=1:sizeoft
        ynew(1,i1) = y(i1, 1);
        ynew(2,i1) = y(i1, 2);
        ynew(3,i1) = y(i1, 3);
        ynew(4,i1) = y(i1, 4);
        ynew(5,i1) = y(i1, 5);
        ynew(6,i1) = y(i1, 6);
        ynew(7,i1) = y(i1, 7);
        ynew(8,i1) = y(i1, 8);
        ynew(9,i1) = y(i1, 9);
        lineplot(1,1,i1) = 0;
        lineplot(1,2,i1) = 0;
        lineplot(1,3,i1) = 0;
        lineplot(1,4,i1) = y(i1, 2);
        for j=1:NumberOfBodies
             colorindex= j - floor((j-1)/5)*5;
             for i=1:size(Body{j},1)
                 R_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,1:2));
                 S_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,3:4));
                 set(bodydraw{j}(i),'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',definecolor{colorindex},'LineWidth',1);
             end
         end
         for j=1:1
             colorindex= j - floor((j-1)/5)*5;
             R_= [lineplot(j,1,i1); lineplot(j,2,i1)];
             S_= [lineplot(j,3,i1); lineplot(j,4,i1)];
             set(linedraw{j},'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',[0.494 0.184 0.556], 'LineStyle', '--');
         end
         drawnow nocallbacks;
    end
end
