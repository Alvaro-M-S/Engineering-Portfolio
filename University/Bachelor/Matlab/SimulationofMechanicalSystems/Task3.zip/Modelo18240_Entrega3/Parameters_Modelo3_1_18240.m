function Param = Parameters_Modelo3_1_18240(t,x)

%% Model Parameters 
    M1 = 250; 
    g = 9.8; 
    K1 = 10000; 
    R1 = 1000; 
    y10 = 0.5; 
    l=1; 
    d=1.2; 

    Param.M1 = M1; 
    Param.g = g; 
    Param.K1 = K1; 
    Param.R1 = R1; 
    Param.y10 = y10; 
    Param.l = l; 
    Param.d = d; 
 
end 

