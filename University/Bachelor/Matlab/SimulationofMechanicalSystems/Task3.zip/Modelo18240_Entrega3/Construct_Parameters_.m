function output= Construct_Parameters_(Model) 
        
    %% Construct parameters
    
    fileparameters = fopen(sprintf('Parameters_%s.m', Model.Name), 'w');
    
    fprintf(fileparameters, 'function Param = Parameters_%s(t,x)\n\n', Model.Name);

    fprintf(fileparameters, '%s \n', '%% Model Parameters'); 
    
    Values= Model.Values;
    Model_Parameters= Model.Parameters;
    
    for i=1:length(Values)
        fprintf(fileparameters, '    %s; \n', Values{i});
    end
    fprintf(fileparameters, '\n');
    
    for i=1:length(Model_Parameters)
        if sum(contains(Values, string(Model_Parameters(i))))
            fprintf(fileparameters, '    Param.%s = %s; \n', Model_Parameters(i), Model_Parameters(i));
            fprintf('.');
        end
    end

    fprintf(fileparameters, ' \nend \n\n');
    fclose(fileparameters);
    
    fprintf('\nConstructed %s \n', sprintf('Parameters_%s.m', Model.Name));

    output = true;

end
