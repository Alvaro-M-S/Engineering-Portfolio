function T= cambiocoord(phi)
    T= eye(2,2);
    T(1,1)=cos(phi);
    T(1,2)=-sin(phi);
    T(2,1)=sin(phi);
    T(2,2)=cos(phi);
end


