function output = Construct_Lagrange_(Model)
        
    syms t x xdot;
    
    constraint= Model.Constraints;
    Driver= Model.Drivers;
    q= Model.q;
    Q= Model.Q;
    q0= Model.q0;
    qdot= Model.qdot;
    Qdot= Model.Qdot;
    vel= Model.vel;
    veldot= Model.veldot;
    Vel= Model.Vel;
    Veldot= Model.Veldot;
   
    nVariables = length(Model.q);
    neq = length(Model.Constraints);
    ngdl= length(Model.Drivers);
    NumberOfConstraints=neq; 
    
    if NumberOfConstraints
        J = jacobian(constraint, q);
        Constraint=subs(constraint, q, Q);

        for i=1:nVariables
            J = subs(J, q(i), Q(i));
            J = subs(J, qdot(i), Qdot(i));
            fprintf('.');
        end
    else
        NumberOfConstraints=0; 
    end
    
    NumberOfMultipliers = Model.NumOfLagrangeMultipliers;
    if NumberOfMultipliers
        LagrangeMultipliers = Model.LagrangeMultipliers;
        LagrangeMultipliersdot = Model.LagrangeMultipliersdot;
        LM = Model.LM;
        LMdot = Model.LMdot;
    end
    
    x = Model.x;
    xdot = Model.xdot;
    X = Model.X;
    Xdot = Model.Xdot;
    
%% Lagrangian
%% T - Kinetic energy    
    try
        T = Model.T;
        Ttot = sum(T);
    catch
        Ttot = 0;
    end

%% V - Potential Energy       
    try
        V = Model.V;
        Vtot = sum(V);
    catch
        Vtot = 0;
    end

%% Non-conservative elements    
    try
        R = Model.R; 
        Rtot= sum(R);
    catch
        Rtot= 0;
    end
    
    L = Ttot - Vtot;
    
    dLdQdot = transpose(simplify(jacobian(L,qdot)));    
    dLdQdot = subs(dLdQdot, [q;qdot], [Q;diff(Q,t)]);
    dLdQdot = simplify(diff(dLdQdot,t));

    Q0 = Model.Q0;
    dLdQ = transpose(simplify(jacobian(L,q)));
    dLdQ = subs(dLdQ, [q; qdot; q0], [Q; diff(Q,t); Q0]);
    dRdQ = transpose(simplify(jacobian(Rtot,qdot)));
    dRdQ = subs(dRdQ, [q;qdot], [Q;diff(Q,t)]);

    if NumberOfMultipliers>0
        LagrangeMultipliersTerm = J.'*LMdot;
% %         LagrangeMultipliersTerm2 = J.'*LM;
% %         Vars=[Q;LM];
    else
        LagrangeMultipliersTerm = 0;
        LagrangeMultipliersTerm2 = 0;
        Vars=[Q];
   end
   Model.LagrangeEquations = simplify(dLdQdot - LagrangeMultipliersTerm - dLdQ + dRdQ);
% %     Model.LagrangeEquations2 = simplify(dLdQdot - LagrangeMultipliersTerm2 - dLdQ + dRdQ);
    
    
% %% Fuerzas
%     if Fuerza
%         Fuerza = str2sym(Fuerza);  
%         F_check= subs(Fuerza,q,rand(length(q),1));
%         F_check= subs(F_check,q0,rand(length(q),1));
%         F_check= subs(F_check,qdot,rand(length(q),1));
%         F_check= subs(F_check,Parametros_modelo,rand(1,length(Parametros_modelo))); 
%         F_check= subs(F_check,Parametros_drivers,rand(1,length(Parametros_drivers))); 
%         F_check= subs(F_check,t,rand); 
%         try
%             F_check= double(F_check);
%         catch
%             fprintf ('ATENCION: Error en la definicion de Fuerzas de las eq. de Lagrange ...'); 
%             fprintf ('\n\n\n'); 
%             return
%         end 
%     end

%% Construction of Lagrange equations    
    Model.IntegralEquations = Qdot- Vel ;
    
    if NumberOfConstraints
        Model.ConstraintsEquations = J*Qdot;
        Model.ConstraintsEquationsNew = J*Qdot;
    end

    ntotalequations= 3*nVariables-ngdl;
    
    Parameters= Model.Parameters;
    
%% Add Links
    if Model.NumberofLinks
        neqBG = sum(Model.neqBGi);
        if ~strcmp(Model.Links,'') 
            Links=subs(Model.Links,q,Q);
            OutputForce = Model.OutputForce;

            for i=1:size(Links,1)
                Model.SubmodelEquations{i}= transpose(Model.output{i}.equations);
            end
            ntotalequations= ntotalequations + neqBG;
        end
    else
        neqBG = 0;
    end

%% Construct parameters    
    Construct_Parameters_(Model);
    
% %     Model.SystemEquations1 = [Model.LagrangeEquations; Model.IntegralEquations; Model.ConstraintsEquations];
% %     Model.SystemEquations2 = [Model.LagrangeEquations2; Constraint];
% %     Incidence2=incidenceMatrix(Model.SystemEquations2,Vars);
% %     [Model.SystemEquations2,Vars] = reduceDifferentialOrder(Model.SystemEquations2,Vars);
% %     isLowIndex= isLowIndexDAE(Model.SystemEquations2,Vars);
% %     [Model.DAESystemEquations2,DAEVars2,R2] = reduceDAEIndex(Model.SystemEquations2,Vars);
% %     [Model.DAESystemEquations3,DAEVars3,R3] = reduceRedundancies(Model.DAESystemEquations2,DAEVars2);
    
%% Construct equations 
    if Model.NumOfLagrangeMultipliers
        Model.LagrangeEquations = subs(Model.LagrangeEquations, [diff(Q,t,t); diff(Q,t); Q; diff(LM,t)], [veldot; vel; q; LagrangeMultipliersdot]);
        Model.IntegralEquations = subs(Model.IntegralEquations, [diff(Q,t); Vel], [qdot; vel]);
        Model.ConstraintsEquations = subs(Model.ConstraintsEquations, [Qdot; Q], [vel; q]);
        Model.SystemEquations = [Model.LagrangeEquations; Model.IntegralEquations; Model.ConstraintsEquations];
    else
        Model.LagrangeEquations = subs(Model.LagrangeEquations, [diff(Q,t,t); diff(Q,t); Q], [veldot; vel; q]);
        Model.IntegralEquations = subs(Model.IntegralEquations, [diff(Q,t); Vel], [qdot; vel]);
        Model.SystemEquations = [Model.LagrangeEquations; Model.IntegralEquations];
    end
    if Model.NumberofLinks
        for i=1:Model.NumberofLinks
            Model.SubmodelEquations{i} = subs(Model.SubmodelEquations{i}, [Qdot; Q], [vel; q]);
            Model.SystemEquations = [Model.SystemEquations; Model.SubmodelEquations{i}];
            Model.OutputsEquations(i) = subs(Model.OutputForce(i), [diff(Q,t); Q; Model.output{i}.Q], [vel; q; Model.output{i}.q]);
        end
    end
    SystemEquations= subs(Model.SystemEquations,[Xdot;X],[xdot;x]);

    JacobianVars=jacobian(SystemEquations,x);
    JacobianVarsdot=jacobian(SystemEquations,xdot);
    
    LagrangeEquations_Implicit= SystemEquations;
    JacobianVars_Implicit = JacobianVars;
    JacobianVarsdot_Implicit = JacobianVarsdot;
    
    LagrangeEquations_SemiExplicit = expand(JacobianVarsdot*xdot - SystemEquations);
    if NumberOfConstraints==0 
%         LagrangeEquations_Explicit = expand(simplify(JacobianVarsdot\LagrangeEquations_SemiExplicit));
        LagrangeEquations_Explicit = simplify(JacobianVarsdot\LagrangeEquations_SemiExplicit);
    end
    JacobianVars_SemiExplicit = JacobianVars;
    JacobianVarsdot_SemiExplicit = JacobianVarsdot;

    for i=1:ntotalequations
       VectorofVariablesdot(i,1)= str2sym(sprintf('xdot(%.0f)',i));
       VectorofVariables(i,1)= str2sym(sprintf('x(%.0f)',i));
       fprintf('.');
    end
    
    if Model.NumberofLinks
        Model.OutputsEquations = subs(Model.OutputsEquations, [xdot; x], [VectorofVariablesdot; VectorofVariables]);
    end

%% Construct Lagrange_Dynamics_    
% % %     filename= fopen(strcat('Dynamics_LagrangeEq_',Model.Name,'.m'), 'w');
    filename= Model.filename;
    
    fprintf(filename, '%s \n\n', strcat('function Dynamics_LagrangeEquations_',Model.Name,'(Model)'));
    
    fprintf(filename, '%s \n', '     close all');
    fprintf(filename, '%s \n\n', '     clc');
    
    fprintf(filename, '%s \n\n', '     %% General variables'); 
    fprintf(filename, '     Model = ''%s'';\n\n', Model.Name);

    fprintf(filename, '     neq = %.0f; \n', neq+ngdl);
    fprintf(filename, '     ngdl = %.0f; \n', ngdl);
    fprintf(filename, '     neqBG = %.0f; \n\n', sum(neqBG));
 
 %% Parametros del Modelo    
    fprintf(filename, '     %% Model parameters \n');
    fprintf(filename, '     Param= Parameters_%s(0,zeros(%.0f,1));\n\n',Model.Name,neq+ngdl+sum(neqBG));
    s1=[symvar(q),'t'];
    s2=symvar(Model.Initial_conditions);
    try
        s3=symvar(Links(:,5));
        for i=1:length(s2)
            if ~ismember(s2(i),s1) && ~ismember(s2(i),s3)
                fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
            end
        end
    catch
        for i=1:length(s2)
            if ~ismember(s2(i),s1) 
                fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
            end
        end
    end
    s1=symvar([s1, s2]);
    s2=symvar(Model.Drivers);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, ' \n');
   
    fprintf(filename, '%s \n', '     %% Define initial conditions'); 
    fprintf(filename, '     q = ['); 
    for i=1:length(Model.Initial_conditions)-1
        fprintf(filename, '%s; ', Model.Initial_conditions(i)); 
    end
    fprintf(filename, '%s]; \n\n', Model.Initial_conditions(end)); 
    
    if Model.NumberofLinks
        fprintf(filename, '%s \n', '     %% Define submodels initial conditions'); 
        fprintf(filename, '     qsubmod = ['); 
        for i=1:length(Model.output)
            for j=1:length(Model.output{i}.InitialConditions)
                if i==length(Model.output) && j==length(Model.output{i}.InitialConditions)
                    fprintf(filename, '%s', Model.output{i}.InitialConditions(j)); 
                else
                    fprintf(filename, '%s; ', Model.output{i}.InitialConditions(j)); 
                end
            end
        end
        fprintf(filename, ']; \n\n'); 
    end
    
    fprintf(filename, '     t = 0;\n');   
    fprintf('.');
    
    fprintf(filename, '%s \n', '     %% Solve mechanism initial position'); 
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     figure(''Name'', ''Initial position dined by the user'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(q);\n\n',Model.Name); 
    end
    fprintf(filename, '%s \n', '     S = Displacements_(Model, q, t);'); 
    fprintf(filename, '%s \n', '     q0 = S;'); 
    fprintf('.');
    
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     figure(''Name'', ''Adjusted initial postion'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(S);\n\n',Model.Name); 
        fprintf('.'); 
    end
    
    fprintf(filename, '%s \n', '     %% Number of differential-agebraic equations to be solved'); 
    fprintf(filename, '%s \n\n', '     numberofDAEequations = 2*neq+(neq-ngdl)+neqBG;'); 

    fprintf(filename, '%s \n', '     %% Initial conditions for dynamic analysis'); 
    fprintf(filename, '%s \n\n', '     x = zeros(numberofDAEequations,1);'); 
    fprintf('.');

    fprintf(filename, '%s \n', '     xp=zeros(numberofDAEequations,1);'); 
    fprintf(filename, '%s \n', '     fixed_x0=zeros(numberofDAEequations,1);'); 
    fprintf(filename, '%s \n\n', '     fixed_xp0=zeros(numberofDAEequations,1);'); 
    fprintf('.');
    
    %% Call to integrator
    fprintf(filename, '     tspan = %s; \n\n', Model.t);

    %% Initial conditions for dynamics 
    fprintf(filename, '%s \n', '     x = zeros(numberofDAEequations,1); ');
    fprintf(filename, '%s \n', '     x(neq+1:2*neq)= q0; %% Initial position ');
    if Model.NumberofLinks
        fprintf(filename, '%s \n', '     x(2*neq+(neq-ngdl)+1:2*neq+(neq-ngdl)+neqBG)= qsubmod; % Submodels initial positions'); 
    end
    fprintf(filename, '%s \n', '     xp=zeros(numberofDAEequations,1); ');
    fprintf(filename, '%s \n', '     fixed_x0=zeros(numberofDAEequations,1); ');
    fprintf(filename, '%s \n\n', '     fixed_xp0=zeros(numberofDAEequations,1); ');

    if strcmp(Model.Solver,'nonstiffsemiexplicit')
        Solver='ode23t';
    elseif strcmp(Model.Solver,'stiffsemiexplicit')
        Solver='ode15s';
    else
        Solver='ode15i';
    end
    
    fprintf(filename, '     solver = ''%s''; \n', Solver );
    fprintf(filename, '%s \n', '     y0_guess = x;   ');
    fprintf(filename, '%s \n', '     yp_guess = zeros(numberofDAEequations,1);');   
    
    if strcmp(Model.Solver,'nonstiffsemiexplicit') || strcmp(Model.Solver,'stiffsemiexplicit')
        fprintf(filename, '     %% Model responding to the form Mq''=f(t,q) \n');
        fprintf(filename, '     %% with Differential Algebraic Equations (DAE) \n');
        fprintf(filename, '     %% The function f(t,q) uses the semiexplicit equations form\n');
        fprintf(filename, '     MassMatrixLagrange = str2func(sprintf(''MassMatrixLagrange_%%s'',Model)); \n');
        fprintf(filename, '     System%s_Lagrange = str2func(sprintf(''eqLagrangeSemiexplicit_%%s'',Model)); \n',Solver);
        fprintf(filename, '     ImplicitDAE = @(time,y,yp) MassMatrixLagrange(q0,time,y)*yp - System%s_Lagrange(q0,time,y);\n',Solver);
        fprintf(filename, '     [x_0,xp_0,resnrm] = decic(ImplicitDAE,0,x,fixed_x0,xp,fixed_xp0); %%Determine consistent yp0\n');
        fprintf(filename, '     options = odeset(''Mass'', @(time,y) MassMatrixLagrange(q0,time,y), ''InitialSlope'', xp_0, ''RelTol'',1.0e-3, ''AbsTol'', 1.0e-5);\n'); 
        fprintf(filename, '     [t1,x] = %s(@(time,y) System%s_Lagrange(q0,time,y), tspan, x_0, options);\n\n',Solver,Solver); 
        fprintf(filename, '     tini=tspan(1);\n');
        fprintf(filename, '     tend=tspan(end);\n');
        fprintf(filename, '     deltat=(tend-tini)/(length(tspan)-1);\n');
        fprintf(filename, '     xp= diff(x,1,1)/deltat;\n');
        fprintf(filename, '     xp(end+1,:)= xp(end,:);\n\n');
    elseif strcmp(Model.Solver,'implicit')   
        fprintf(filename, '     %% Model responding to the form f(t,q,q'')=0 \n');
        fprintf(filename, '     %% with Differential Algebraic Equations (DAE) \n');
        fprintf(filename, '     %% The function f(t,q,q'') uses the implicit equations form \n');
        fprintf(filename, '     System%s_Lagrange = str2func(sprintf(''eqLagrangeImplicit_%%s'',Model));\n',Solver);
        fprintf(filename, '     JacobianSolver = str2func(sprintf(''JacobianSolver_%%s'',Model));\n');
        fprintf(filename, '     [x_0,xp_0,resnrm] = decic(@(time,y,yp) System%s_Lagrange(q0, time, y, yp),0,x,fixed_x0,xp,fixed_xp0); %%Determina yp0 Consistentes \n', Solver);
        fprintf(filename, '     options = odeset(''RelTol'',1.0E-3,''AbsTol'',1.0E-6,''Jacobian'', @(time,y,yp) JacobianSolver(x_0,time,y,yp));\n');
        fprintf(filename, '     [t1,x] = %s(@(time,y,yp) System%s_Lagrange(q0, time, y, yp), tspan, x_0, xp_0,options); \n\n',Solver,Solver);
        fprintf(filename, '     tini=tspan(1);\n');
        fprintf(filename, '     tend=tspan(end);\n');
        fprintf(filename, '     deltat=(tend-tini)/(length(tspan)-1);\n');
        fprintf(filename, '     xp= diff(x,1,1)/deltat;\n');
        fprintf(filename, '     xp(end+1,:)= xp(end,:);\n\n');
    else
        output=false;
        sprintf('     Incorrect solver definition (%s) \n\n',Model.Solver);
        return
    end
    fprintf('.');
    
    fprintf(filename, '     h = now;\n'); 
    fprintf(filename, '     dir = pwd;\n'); 
    fprintf(filename, '     save %s;\n\n',Model.Name); 

    if Model.ExistDynamicPlots
        fprintf(filename, '%s \n', '     %% Plots for Dynamics'); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''x-y plots for Dynamics'', ''Color'', ''white'');'); 
        fprintf(filename, '     Subplots_Dynamics_%s(q0,t1,x,xp);\n\n',Model.Name); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''x-y plots for Energy'', ''Color'', ''white'');'); 
        fprintf(filename, '     Subplots_Energy_%s(q0,t1,x);\n\n',Model.Name); 
    end
    
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     %% Dynamics Animation'); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''Dynamics Animation'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(x(:,neq+1:2*neq)'');\n\n',Model.Name); 
    end
    fprintf(filename, 'end\n\n');
    fprintf('.');

    fprintf('\nConstructed Dynamics_LagrangeEquations_%s.m \n',Model.Name);

%% Construct eqLagrangeImplicit
    if strcmp(Model.Solver,'implicit')
        fprintf(filename, 'function equations = eqLagrangeImplicit_%s(x_0, t, x, xdot)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=symvar(Parameters);
        try
            s2=symvar([LagrangeEquations_Implicit; OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch
            s2=symvar(LagrangeEquations_Implicit);
            for i=1:length(s2)
                if ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% Lagrange implicit equations');
        LagrangeEquations_Implicit = simplify(subs(LagrangeEquations_Implicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(LagrangeEquations_Implicit)
            fprintf(filename, '       equations(%0.f,1) = %s; \n', i, LagrangeEquations_Implicit(i));
            fprintf('.');
        end
        fprintf(filename, '\n       dispstat(sprintf(''  t = %%8.2f'',t));\n'); 
        fprintf(filename, ' \nend \n\n');   

        fprintf('\nConstructed eqLagrangeImplicit_%s.m \n',Model.Name);
    end

%% Construct eqLagrangeSemiexplicit
    if ~strcmp(Model.Solver,'implicit')

        fprintf(filename, 'function equations = eqLagrangeSemiexplicit_%s(x_0, t, x)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=symvar(Parameters);

        try
            s2=symvar([LagrangeEquations_SemiExplicit; OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch
            s2=symvar(LagrangeEquations_SemiExplicit);
            for i=1:length(s2)
                if ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% Semiexplicit Equations');
        LagrangeEquations_SemiExplicit = simplify(subs(LagrangeEquations_SemiExplicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(LagrangeEquations_SemiExplicit)
            fprintf(filename, '       equations(%0.f,1) = %s; \n', i, LagrangeEquations_SemiExplicit(i));
            fprintf('.');
        end
        fprintf(filename, '\n       dispstat(sprintf(''  t = %%8.2f'',t));\n'); 

        fprintf(filename, ' \n%s \n\n', 'end');   
        fprintf('\nConstructed eqLagrangeSemiexplicit_%s.m \n',Model.Name);
    end
    
%% Construct MassMatrixLagrange  
    if ~strcmp(Model.Solver,'implicit')
        fprintf(filename, 'function Mass_equations = MassMatrixLagrange_%s(x_0, t, x)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=[symvar(q),'t'];
        try
            s2=[symvar(JacobianVarsdot_SemiExplicit), symvar(Model.OutputForce)];
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ~ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch 
            s2=symvar(JacobianVarsdot_SemiExplicit);
            for i=1:length(s2)
                if ~ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% Mass Matrix for Lagrange Equations');
        JacobianVarsdot_SemiExplicit = simplify(subs(JacobianVarsdot_SemiExplicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(Model.SystemEquations)
            for j=1:length(Model.SystemEquations)
                if j==1
                    fprintf(filename, '       Mass_equations(%0.f,:) = [ %s, ', i, JacobianVarsdot_SemiExplicit(i,j));
                elseif j<length(Model.SystemEquations)
                    fprintf(filename, '%s, ', JacobianVarsdot_SemiExplicit(i,j));
                else
                    fprintf(filename, '%s];\n', JacobianVarsdot_SemiExplicit(i,j));
                end
            end
            fprintf('.');
        end
        fprintf(filename, ' \n%s \n\n', 'end');        
        fprintf('\nConstructed MassMatrixLagrange_%s.m \n',Model.Name);
    end

%% Construct eqLagrangeExplicit
    if ~strcmp(Model.Solver,'implicit') && NumberOfConstraints==0

        fprintf(filename, 'function equations = eqLagrangeExplicit_%s(x_0, t, x)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=symvar(Parameters);

        try
            s2=symvar([LagrangeEquations_SemiExplicit; OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch
            s2=symvar(LagrangeEquations_SemiExplicit);
            for i=1:length(s2)
                if ismember(s2(i),s1)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s \n', ' %% Explicit Equations');
        LagrangeEquations_Explicit = simplify(subs(LagrangeEquations_Explicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(LagrangeEquations_Explicit)
            fprintf(filename, '       equations(%0.f,1) = %s; \n', i, LagrangeEquations_Explicit(i));
            fprintf('.');
        end
        fprintf(filename, '\n       dispstat(sprintf(''  t = %%8.2f'',t));\n'); 

        fprintf(filename, ' \n%s \n\n', 'end');   
        fprintf('\nConstructed eqLagrangeExplicit_%s.m \n',Model.Name);
    end
    
    
%% Construct JacobianSolver
    if strcmp(Model.Solver,'implicit')
        fprintf(filename, 'function [dfdy, dfdp] = JacobianSolver_%s(x_0, t, x, xdot)\n\n', Model.Name);

        fprintf(filename, '%s \n', '     %% Model parameters');
        fprintf(filename, '       Param= Parameters_%s(t,x);\n\n',Model.Name);
        s1=[symvar(q),'t'];
        try
            s2=symvar([LagrangeEquations_Implicit; Model.OutputForce]);
            s3=symvar(Links(:,5));
            for i=1:length(s2)
                if ~ismember(s2(i),s1) && ~ismember(s2(i),s3)
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        catch 
            s2=symvar(LagrangeEquations_Implicit);
            for i=1:length(s2)
                if ~ismember(s2(i),s1) 
                    fprintf(filename, '       %s= Param.%s;\n',s2(i),s2(i));
                end
            end
        end
        fprintf(filename, '\n');

        if Model.NumberofLinks
            fprintf(filename, '%s \n', ' %% Forces in Links');
            for i=1:size(Links,1)
                fprintf(filename, '       %s = %s; \n', Model.ModelLink(i), Model.OutputsEquations(i));
                fprintf('.');
            end
        end
        fprintf(filename, '\n');

        fprintf(filename, '%s\n', '%% Variables jacobian');
        JacobianVars_Implicit = simplify(subs(JacobianVars_Implicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));

        for i=1:length(Model.SystemEquations)
            fprintf(filename, '       dfdy(%0.f,:) = [', i);
            for j=1:length(Model.SystemEquations)-1
                fprintf(filename, '%s, ', JacobianVars_Implicit(i,j));
            end
            fprintf(filename, '%s];\n', JacobianVars_Implicit(i,length(Model.SystemEquations)));
            fprintf('.');
        end
        fprintf(filename, '\n');   

        fprintf(filename, '%s\n', '%% Derivatives jacobian');
        JacobianVarsdot_Implicit = simplify(subs(JacobianVarsdot_Implicit, [xdot; x], [VectorofVariablesdot; VectorofVariables]));
        for i=1:length(Model.SystemEquations)
            fprintf(filename, '       dfdp(%0.f,:) = [', i);
            for j=1:length(Model.SystemEquations)-1
                fprintf(filename, '%s, ', JacobianVarsdot_Implicit(i,j));
            end
            fprintf(filename, '%s];\n', JacobianVarsdot_Implicit(i,length(Model.SystemEquations)));
            fprintf('.');
        end
        fprintf(filename, ' \n%s \n\n', 'end');   

        fprintf('\nConstructed JacobianSolver_%s.m \n',Model.Name);
    end   
        
    output = true;

end


