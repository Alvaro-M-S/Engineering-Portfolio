function Jacobian_ = Jacobian_Modelo3_1_18240(q,t)
%% Model parameters 
      Param= Parameters_Modelo3_1_18240(t,q);


%% Jacobian matrix. Rows correspondring to the kinematic constraints 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      Jacobian_(1,:)= [ 1]; 

end
