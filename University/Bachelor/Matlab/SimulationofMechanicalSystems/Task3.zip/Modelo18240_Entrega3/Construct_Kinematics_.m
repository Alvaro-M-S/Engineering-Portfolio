function output = Construct_Kinematics_(Model)

    Variables= Model.System_variables;
    Restriccion= Model.Constraints;
    Driver= Model.Drivers;
    Condiciones_Iniciales= Model.Initial_conditions;
    Ecuacion_Driver= Model.Drivers;

    nVariables = length(Variables);
    neq = length(Restriccion);
    ngdl= length(Driver);

% % %     filename= fopen(strcat('Kinematics_',Model.Name,'.m'), 'w');
    filename= Model.filename;
    
    fprintf(filename, '%s \n\n', strcat('function Kinematics_',Model.Name,'(Model)'));
    
    fprintf(filename, '%s \n', '     close all');
    fprintf(filename, '%s \n\n', '     clc');
        
%% Parametros del Modelo    
    fprintf(filename, '%s \n', '%% Model parameters');
    fprintf(filename, '     Param= Parameters_%s(0,zeros(%.0f,1));\n',Model.Name,neq);
    s1=[transpose(Variables),'t'];
    s2=symvar(Condiciones_Iniciales);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    s1=symvar([s1, s2]);
    s2=symvar(Ecuacion_Driver);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(filename, '     %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, ' \n');
    
    fprintf(filename, '%s \n\n', '     %% Model Variables');
    fprintf(filename, '     Model = ''%s'';\n\n', Model.Name);
    fprintf(filename, '     neq = %.0f; \n', neq);
    fprintf(filename, '     ngdl = %.0f; \n\n', ngdl);

    fprintf(filename, '%s \n', '     %% Initial conditions'); 
    fprintf(filename, '     q = [');
    for i=1:length(Condiciones_Iniciales)
        fprintf(filename, ' %s', Condiciones_Iniciales(i));
        if i<length(Condiciones_Iniciales)
            fprintf(filename, ';');
        end
    end
    fprintf(filename, '];\n');
    fprintf(filename, '     t= 0;\n\n');
    
    fprintf(filename, '%s \n', '     %% Solve mechanism initial position'); 
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     figure(''Name'', ''Initial position defined by the user'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(q);\n\n',Model.Name); 
    end
    fprintf(filename, '%s \n', '     S = Displacements_(Model, q, t);'); 
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     figure(''Name'', ''Initial position adjusted by the solver'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(S);\n\n',Model.Name); 
    end
    
    fprintf(filename, '%s \n', '     %% Time span simulation'); 
    fprintf(filename, '     t = %s; \n\n', Model.t);
    
    fprintf(filename, '%s \n', '     %% Solve mechanism movement from the driver inputs'); 
    fprintf(filename, '%s \n\n', '     S = Displacements_(Model, q, t);'); 
    
    fprintf(filename, '%s \n', '     %% Solve mechanism velocities'); 
    fprintf(filename, '     V = Velocities_%s(Model, t(1:size(S,2)), S);\n\n',Model.Name); 
    
    fprintf(filename, '     h = now;\n'); 
    fprintf(filename, '     dir = pwd;\n'); 
    fprintf(filename, '     save %s;\n\n',Model.Name); 
    fprintf(filename, '%s \n', '');
    
    if Model.ExistKinematicPlots
        fprintf(filename, '%s \n', '     %% Plots for kinematics '); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''Kinematics x-y plots'', ''Color'', ''white'');'); 
        fprintf(filename, '%s \n', '     plots=V;'); 
        fprintf(filename, '%s \n', '     plots(size(S,1)+1:2*size(S,1),:)=S;'); 
        fprintf(filename, '%s \n', '     t=t(1:size(S,2));'); 
        fprintf(filename, '     Subplots_Kinematics_%s(q,t,plots''); \n\n', Model.Name);
    end
    
    if Model.ConstructAnimation
        fprintf(filename, '%s \n', '     %% Animation'); 
        fprintf(filename, '%s \n', '     figure(''Name'', ''Animation of Kinematics'', ''Color'', ''white'');'); 
        fprintf(filename, '     Animation_%s(S);\n\n',Model.Name); 
    end
    
    fprintf(filename, 'end\n\n');
    
    fprintf('\nConstructed Kinematics_%s.m \n',Model.Name);
    output = true;
    
end



