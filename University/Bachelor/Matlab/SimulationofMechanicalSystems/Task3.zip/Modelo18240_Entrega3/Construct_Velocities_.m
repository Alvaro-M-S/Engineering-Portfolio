function output= Construct_Velocities_(Model)

    F= Model.Constraints;
    q= Model.q;
    driver=Model.Drivers;
    Constraints=[F; driver];
    
    J= jacobian(Constraints, q);
    
    neq = length(Constraints);
    ngdl = length(driver);
    
    syms t
    Derivatives=-diff(Constraints,t);
    
    for i=1:neq
        tder{i,1}= sprintf('     tder(%.0f,:)= %s;', i, Derivatives(i));
    end
    
%% Construct velocities function
% % %     filename = fopen(sprintf('Velocities_%s.m', Model.Name), 'w');
    filename=Model.filename;
    fprintf(filename, 'function V = Velocities_%s(Model, t, S)\n\n', Model.Name);

%% Parametros del Modelo    
    fprintf(filename, '%s \n', '%% Model parameters');
    fprintf(filename, '      Param= Parameters_%s(0,S(:,1));\n',Model.Name);
    s1=symvar([q; 't']);
    s2=symvar(Derivatives);
    for i=1:length(s2)
        if ~ismember(s2(i),s1) 
            fprintf(filename, '      %s= Param.%s;\n',s2(i),s2(i));
        end
    end
    fprintf(filename, '\n');
    
    fprintf(filename, '%s \n', '%% Jacobian matrix');
    fprintf(filename, '      JacobianMatrix = @Jacobian_%s;\n\n',Model.Name);


    fprintf(filename, '%s \n', '%% Time derivative od constraints');
    fprintf(filename, '%s \n', '      tder=zeros(size(S));');

    for i=1:length(Constraints)
        fprintf(filename, ' %s \n', tder{i,1});
    end

    fprintf(filename, '\n      for i=1:size(S,2)\n');
    fprintf(filename, '          V(:,i)=JacobianMatrix(S(:,i),t)\\tder(:,i);\n');
    fprintf(filename, '      end\n');

    fprintf(filename, ' \n%s \n\n', 'end');
    
    output = true;
 
end
