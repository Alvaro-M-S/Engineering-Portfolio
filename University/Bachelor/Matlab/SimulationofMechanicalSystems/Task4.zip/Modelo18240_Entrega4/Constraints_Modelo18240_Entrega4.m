function Constraints_ = Constraints_Modelo18240_Entrega4(q,t)

%% Model parameters 
      Param= Parameters_Modelo18240_Entrega4(t,q);

      b= Param.b;
      d= Param.d;
      phi10= Param.phi10;
 
%% Kinematic constraints 
      Constraints_(1)= b*sin(q(1)) - d - 2*d*sin(q(2)); 
 
%% Drivers 
      Constraints_(2) = q(1) - phi10; 
 
end 

