clear all
clc

%% Model name
   Model.Name='Modelo18240_Entrega4';


%% Model parameters values

   Model.Values = {'b = 1'; 'd = 1.25';  ...
             'M1 = 100'; 'J1 = 100'; 'M2 = 1000'; 'J2 = 100'; ...
             'g = 9.8'; 'K = 4000'; 'R1 = 400'; ...
             'phi10 = -pi/4'}; 


%% Model variables list  
    Model.System_variables= {'phi1'; 'phi2'};


%% Kinematic constraints 
    Model.Constraints = { 'b*sin(phi1)-2*d*sin(phi2)-d'};

%% Constraint Forces                
    Model.ConstraintForces = { 'RAy'};

%% Driver equations
    Model.Drivers = {'phi1 - phi10'}; 

%% Type of Analysis (Kinematics, Newton-Euler or Lagrange)
    Model.AnalysisType= 'Lagrange';
    
%% Dynamics using Lagrange equations
    Model.T = {'1/2*M1*((b/2*phi1dot)^2)';
               '1/2*J1*phi1dot^2'; 
               '1/2*M2*((-phi1dot*b*sin(phi1)+phi2dot*d*sin(phi2))^2+(b*cos(phi1)*phi1dot-phi2dot*d*cos(phi2))^2)';
               '1/2*J2*phi2dot^2'};
    Model.V = {'M1*g*b/2*sin(phi1)';
               'M2*g*(b*sin(phi1)-d*sin(phi2))';
               '1/2*K*b/2*sin(phi1)'};
    Model.R = {'1/2*R1*(-b*phi1dot*sin(phi1)+d*phi2dot*sin(phi2))^2'};       
    
%% Time span
    Model.t= '[0:0.005:10]';
    
%% Initial conditions
    Model.Initial_conditions = {'-pi/4'; '29*pi/18'};  
    
%% Solver for dynamics: Use 'implict', 'nonstiffsemiexplicit' or 'stiffsemiexplicit'
    Model.Solver = 'nonstiffsemiexplicit';
%     Model.Solver = 'implicit';
    
%% Define animation
    % Objet to be animated, defined by polygons in local body coordinates
    Model.Body{1} = {'-b/2', '0.02', 'b/2', '0.02';
                     'b/2', '0.02', 'b/2', '-0.02';
                     ' b/2', '-0.02', '-b/2', '-0.02';
                     '-b/2', '-0.02', '-b/2', '0.02'};      

    Model.Body{2} = {'-d', '0.02', 'd', '0.02';
                     ' d', '0.02', 'd', '-0.02';
                     ' d', '-0.02', '-d', '-0.02';
                     '-d', '-0.02', '-d', '0.02'};       

    % Body movements for animation
    Model.BodyMovements = {'b/2*cos(phi1)','b/2*sin(phi1)','phi1';

                           'b*cos(phi1)-d*cos(phi2)','b*sin(phi1)-d*sin(phi2)','phi2'};      

    % Lines for animation
    Model.Lines = {'b/2*cos(phi1)', 'b/2*sin(phi1)', '0',  'b/2'};      

    % Viewport for animation
    Model.Viewport = {'-5 ', '5', ' -4', ' 4'};

%% Plots x-y for Dynamics
    Model.NumSubplotsDynamics = {};
    Model.SubplotsDynamics = {};

%% Construction of MatLab model. DO NOT MODIFY

    Construct_(Model);
