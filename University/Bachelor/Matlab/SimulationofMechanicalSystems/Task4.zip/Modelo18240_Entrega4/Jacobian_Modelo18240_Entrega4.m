function Jacobian_ = Jacobian_Modelo18240_Entrega4(q,t)
%% Model parameters 
      Param= Parameters_Modelo18240_Entrega4(t,q);

      b= Param.b;
      d= Param.d;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      Jacobian_(1,:)= [ b*cos(q(1)), -2*d*cos(q(2))]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      Jacobian_(2,:)= [ 1, 0]; 

end
