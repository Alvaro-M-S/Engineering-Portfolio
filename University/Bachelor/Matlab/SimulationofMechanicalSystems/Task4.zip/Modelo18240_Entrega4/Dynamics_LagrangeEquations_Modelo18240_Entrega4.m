function Dynamics_LagrangeEquations_Modelo18240_Entrega4(Model) 

     close all 
     clc 

     %% General variables 

     Model = 'Modelo18240_Entrega4';

     neq = 2; 
     ngdl = 1; 
     neqBG = 0; 

     % Model parameters 
     Param= Parameters_Modelo18240_Entrega4(0,zeros(2,1));

     phi10= Param.phi10;
 
     %% Define initial conditions 
     q = [-pi/4; (29*pi)/18]; 

     t = 0;
     %% Solve mechanism initial position 
     figure('Name', 'Initial position dined by the user', 'Color', 'white'); 
     Animation_Modelo18240_Entrega4(q);

     S = Displacements_(Model, q, t); 
     q0 = S; 
     figure('Name', 'Adjusted initial postion', 'Color', 'white'); 
     Animation_Modelo18240_Entrega4(S);

     %% Number of differential-agebraic equations to be solved 
     numberofDAEequations = 2*neq+(neq-ngdl)+neqBG; 

     %% Initial conditions for dynamic analysis 
     x = zeros(numberofDAEequations,1); 

     xp=zeros(numberofDAEequations,1); 
     fixed_x0=zeros(numberofDAEequations,1); 
     fixed_xp0=zeros(numberofDAEequations,1); 

     tspan = [0:0.005:10]; 

     x = zeros(numberofDAEequations,1);  
     x(neq+1:2*neq)= q0; %% Initial position  
     xp=zeros(numberofDAEequations,1);  
     fixed_x0=zeros(numberofDAEequations,1);  
     fixed_xp0=zeros(numberofDAEequations,1);  

     solver = 'ode23t'; 
     y0_guess = x;    
     yp_guess = zeros(numberofDAEequations,1); 
     % Model responding to the form Mq'=f(t,q) 
     % with Differential Algebraic Equations (DAE) 
     % The function f(t,q) uses the semiexplicit equations form
     MassMatrixLagrange = str2func(sprintf('MassMatrixLagrange_%s',Model)); 
     Systemode23t_Lagrange = str2func(sprintf('eqLagrangeSemiexplicit_%s',Model)); 
     ImplicitDAE = @(time,y,yp) MassMatrixLagrange(q0,time,y)*yp - Systemode23t_Lagrange(q0,time,y);
     [x_0,xp_0,resnrm] = decic(ImplicitDAE,0,x,fixed_x0,xp,fixed_xp0); %Determine consistent yp0
     options = odeset('Mass', @(time,y) MassMatrixLagrange(q0,time,y), 'InitialSlope', xp_0, 'RelTol',1.0e-3, 'AbsTol', 1.0e-5);
     [t1,x] = ode23t(@(time,y) Systemode23t_Lagrange(q0,time,y), tspan, x_0, options);

     tini=tspan(1);
     tend=tspan(end);
     deltat=(tend-tini)/(length(tspan)-1);
     xp= diff(x,1,1)/deltat;
     xp(end+1,:)= xp(end,:);

     h = now;
     dir = pwd;
     save Modelo18240_Entrega4;

     %% Dynamics Animation 
     figure('Name', 'Dynamics Animation', 'Color', 'white'); 
     Animation_Modelo18240_Entrega4(x(:,neq+1:2*neq)');

end

function equations = eqLagrangeSemiexplicit_Modelo18240_Entrega4(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo18240_Entrega4(t,x);

       K= Param.K;
       M1= Param.M1;
       M2= Param.M2;
       R1= Param.R1;
       b= Param.b;
       d= Param.d;
       g= Param.g;


 %% Semiexplicit Equations 
       equations(1,1) = M2*b*d*x(2)^2*cos(x(4))*sin(x(3)) - R1*b^2*x(1)*sin(x(3))^2 - (M1*b*g*cos(x(3)))/2 - M2*b*g*cos(x(3)) - M2*b*d*x(2)^2*cos(x(3))*sin(x(4)) - (K*b*cos(x(3)))/4 + R1*b*d*x(2)*sin(x(3))*sin(x(4)); 
       equations(2,1) = M2*d*g*cos(x(4)) - R1*d^2*x(2)*sin(x(4))^2 + M2*b*d*x(1)^2*cos(x(3))*sin(x(4)) - M2*b*d*x(1)^2*cos(x(4))*sin(x(3)) + R1*b*d*x(1)*sin(x(3))*sin(x(4)); 
       equations(3,1) = x(1); 
       equations(4,1) = x(2); 
       equations(5,1) = 2*d*x(2)*cos(x(4)) - b*x(1)*cos(x(3)); 

       dispstat(sprintf('  t = %8.2f',t));
 
end 

function Mass_equations = MassMatrixLagrange_Modelo18240_Entrega4(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo18240_Entrega4(t,x);

       J1= Param.J1;
       J2= Param.J2;
       M1= Param.M1;
       M2= Param.M2;
       b= Param.b;
       d= Param.d;

 %% Mass Matrix for Lagrange Equations 
       Mass_equations(1,:) = [ J1 + (M1*b^2)/4 + M2*b^2, -M2*b*d*cos(x(3) - x(4)), 0, 0, -b*cos(x(3))];
       Mass_equations(2,:) = [ -M2*b*d*cos(x(3) - x(4)), J2 + M2*d^2, 0, 0, 2*d*cos(x(4))];
       Mass_equations(3,:) = [ 0, 0, 1, 0, 0];
       Mass_equations(4,:) = [ 0, 0, 0, 1, 0];
       Mass_equations(5,:) = [ 0, 0, 0, 0, 0];
 
end 

function Animation_Modelo18240_Entrega4(y) 

%% Model parameters 
     t=0; x=0; 
     Param= Parameters_Modelo18240_Entrega4(t,x);
     b= Param.b;
     d= Param.d;
     b= Param.b;
     d= Param.d;
     b= Param.b;
     b= Param.b;
     b= Param.b;

%% Bodies to be animated 
     Body{1} = [ -b/2, 0.02, b/2, 0.02; 
                 b/2, 0.02, b/2, -0.02; 
                  b/2, -0.02, -b/2, -0.02; 
                 -b/2, -0.02, -b/2, 0.02]; 

     Body{2} = [ -d, 0.02, d, 0.02; 
                  d, 0.02, d, -0.02; 
                  d, -0.02, -d, -0.02; 
                 -d, -0.02, -d, 0.02]; 

     NumberOfBodies = length(Body);
     NumberOfLines = 1;

 %% Animation viewport 
     axis equal 
     axis ([ -5 5 -4 4]);
     grid on 

     definecolor = {'r' 'g' 'b' 'm' 'k' 'r'}; 

% Begin Animation
     y = transpose(y);
     sizeoft=size(y,1);
     for j=1:NumberOfBodies
         bodydraw{j}=line(zeros(size(Body{j},1)),zeros(size(Body{j},1)));
     end
     for j=1:1
         linedraw{j}=line(zeros(1,1),zeros(1,1));
     end
     for i1=1:sizeoft
        ynew(1,i1) = (b*cos(y(i1, 1)))/2;
        ynew(2,i1) = (b*sin(y(i1, 1)))/2;
        ynew(3,i1) = y(i1, 1);
        ynew(4,i1) = b*cos(y(i1, 1)) - d*cos(y(i1, 2));
        ynew(5,i1) = b*sin(y(i1, 1)) - d*sin(y(i1, 2));
        ynew(6,i1) = y(i1, 2);
        lineplot(1,1,i1) = (b*cos(y(i1, 1)))/2;
        lineplot(1,2,i1) = (b*sin(y(i1, 1)))/2;
        lineplot(1,3,i1) = 0;
        lineplot(1,4,i1) = b/2;
        for j=1:NumberOfBodies
             colorindex= j - floor((j-1)/5)*5;
             for i=1:size(Body{j},1)
                 R_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,1:2));
                 S_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,3:4));
                 set(bodydraw{j}(i),'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',definecolor{colorindex},'LineWidth',1);
             end
         end
         for j=1:1
             colorindex= j - floor((j-1)/5)*5;
             R_= [lineplot(j,1,i1); lineplot(j,2,i1)];
             S_= [lineplot(j,3,i1); lineplot(j,4,i1)];
             set(linedraw{j},'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',[0.494 0.184 0.556], 'LineStyle', '--');
         end
         drawnow nocallbacks;
    end
end
