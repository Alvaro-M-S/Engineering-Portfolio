function JacobianQdot_ = JacobianQdot_Modelo18240_Entrega4(q,qdot,t)
%% Model parameters 
      Param= Parameters_Modelo18240_Entrega4(t,q);

      b= Param.b;
      d= Param.d;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      JacobianQdot_(1,:)= [ -b*qdot(1)*sin(q(1)), 2*d*qdot(2)*sin(q(2))]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      JacobianQdot_(2,:)= [ 0, 0]; 

end
