function Jacobian_ = Jacobian_Modelo18240_Entrega2(q,t)
%% Model parameters 
      Param= Parameters_Modelo18240_Entrega2(t,q);

      b= Param.b;
      d= Param.d;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      Jacobian_(1,:)= [ 1, 0, (b*sin(q(3)))/2, 0, 0, 0]; 
      Jacobian_(2,:)= [ 0, 1, -(b*cos(q(3)))/2, 0, 0, 0]; 
      Jacobian_(3,:)= [ 1, 0, -(b*sin(q(3)))/2, -1, 0, d*sin(q(6))]; 
      Jacobian_(4,:)= [ 0, 1, (b*cos(q(3)))/2, 0, -1, -d*cos(q(6))]; 
      Jacobian_(5,:)= [ 0, 0, 0, 0, -1, d*cos(q(6))]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      Jacobian_(6,:)= [ 0, 0, 1, 0, 0, 0]; 

end
