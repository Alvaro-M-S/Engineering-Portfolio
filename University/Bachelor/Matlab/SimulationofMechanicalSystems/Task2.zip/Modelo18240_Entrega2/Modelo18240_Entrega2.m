clear all
clc

%% Model name
   Model.Name='Modelo18240_Entrega2';


%% Model parameters values
   Model.Values = {'b = 1'; 'd = 1';  ...
             'M1 = 100'; 'J1 = 100'; 'M2 = 100'; 'J2 = 100'; ...
             'g = 9.8'; 'K1 = 4000'; 'R1 = 400'; ...
             'phi10 = pi/4'}; 

%% Model variables list  
    Model.System_variables= {'x1'; 'y1'; 'phi1'; 'x2'; 'y2'; 'phi2'};

%% Kinematic constraints 
    Model.Constraints = { 'x1 - b/2*cos(phi1)';
                          'y1 - b/2*sin(phi1)';
                          'x1 + b/2*cos(phi1) - x2 - d*cos(phi2)';
                          'y1 + b/2*sin(phi1) - y2 - d*sin(phi2)';
                          '-y2 + d*sin(phi2) +d'};
                      
%% Fuerzas de restricion                
    Model.ConstraintForces = { 'ROx'; 'ROy'; 'RBx'; 'RBy'; 'RNC'};

%% Driver equations
    Model.Drivers = {'phi1 - phi10'}; 

%% Type of Analysis (Kinematics, Newton-Euler or Lagrange)
    Model.AnalysisType= 'Newton-Euler';
    
%% Dynamics using Newton-Euler equations
    % Linear and Angular Momentum
    Model.LinearAngularMomentum = {'M1*x1dot';
                                   'M1*y1dot';
                                   'J1*phi1dot';
                                   'M2*x2dot';
                                   'M2*y2dot';
                                   'J2*phi2dot'};
    % Forces
    Model.Forces = {'-K1*sqrt(x1^2+(y1-b/2)^2)*cos(acos(x1/sqrt(x1^2+(y1-b/2)^2)))';
    	            '-M1*g-K1*sqrt(x1^2+(y1-b/2)^2)*sin(acos(x1/sqrt(x1^2+(y1-b/2)^2)))';
    	            '0';
    	            '-R1*(x2dot + d*sin(phi2)*phi2dot)';
    	            '-M2*g';
                    '0'};
        
%% Time span
    Model.t= '[0:0.01:10]';
    
%% Initial conditions
    Model.Initial_conditions = {'0'; '0'; 'pi/2'; '-2*d'; 'b'; '0'};  
    
%% Solver for dynamics: Use 'implict', 'nonstiffsemiexplicit' or 'stiffsemiexplicit'
    Model.Solver = 'nonstiffsemiexplicit';
%     Model.Solver = 'implicit';
    
%% Define animation
    % Objet to be animated, defined by polygons in local body coordinates
    Model.Body{1} = {'-b/2', '0.02', 'b/2', '0.02';
                     'b/2', '0.02', 'b/2', '-0.02';
                     ' b/2', '-0.02', '-b/2', '-0.02';
                     '-b/2', '-0.02', '-b/2', '0.02'};      
    Model.Body{2} = {'-d', '0.02', 'd', '0.02';
                     ' d', '0.02', 'd', '-0.02';
                     ' d', '-0.02', '-d', '-0.02';
                     '-d', '-0.02', '-d', '0.02'};      

    % Body movements for animation
    Model.BodyMovements = {'x1',  'y1',  'phi1';
                           'x2',  'y2',  'phi2'};   
    Model.Lines = {'0', 'b/2', 'x1', 'y1'};                  
    
    % Viewport for animation
    Model.Viewport = {'-1.5 ', '3.5', ' -1.5', ' 1.5'};
    
    % Grabacion de la animacion   
    Model.Animation=true;
    
%% Plots x-y for Dynamics
    Model.NumSubplotsDynamics = {4, 2};
    Model.SubplotsDynamics = {'t', 'Time (s)', 'x2 + d*cos(phi2)', 'X displacement - slider (m)';
                              'x1', 'X displacement - crank (m)', 'y1', 'Y displacement - crank (m)';
                              'x2', 'X displacement - slider (m)', 'y2', 'Y displacement - slider (m)';
                              't', 'Time (s)', 'x2dotdot', 'X acceleration - COG slider (m2/s)';
                              't', 'Time (s)', 'ROx', 'Constraint Force X at A (N)';
                              't', 'Time (s)', 'ROy+RNC', 'Constraint Force Y at A+C (N)';
                              't', 'Time (s)', 'RBx', 'Constraint Force X at B (N)';
                              't', 'Time (s)', 'RBy', 'Constraint Force Y at B (N)'};


%% Construction of MatLab model. DO NOT MODIFY
    Construct_(Model);




