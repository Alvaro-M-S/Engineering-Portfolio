function Param = Parameters_Modelo18240_Entrega2(t,x)

%% Model Parameters 
    b = 1; 
    d = 1; 
    M1 = 100; 
    J1 = 100; 
    M2 = 100; 
    J2 = 100; 
    g = 9.8; 
    K1 = 4000; 
    R1 = 400; 
    phi10 = pi/4; 

    Param.b = b; 
    Param.d = d; 
    Param.M1 = M1; 
    Param.J1 = J1; 
    Param.M2 = M2; 
    Param.J2 = J2; 
    Param.g = g; 
    Param.K1 = K1; 
    Param.R1 = R1; 
    Param.phi10 = phi10; 
 
end 

