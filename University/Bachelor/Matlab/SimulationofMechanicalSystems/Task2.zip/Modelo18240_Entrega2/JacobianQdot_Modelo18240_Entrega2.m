function JacobianQdot_ = JacobianQdot_Modelo18240_Entrega2(q,qdot,t)
%% Model parameters 
      Param= Parameters_Modelo18240_Entrega2(t,q);

      b= Param.b;
      d= Param.d;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      JacobianQdot_(1,:)= [ 0, 0, (b*qdot(3)*cos(q(3)))/2, 0, 0, 0]; 
      JacobianQdot_(2,:)= [ 0, 0, (b*qdot(3)*sin(q(3)))/2, 0, 0, 0]; 
      JacobianQdot_(3,:)= [ 0, 0, -(b*qdot(3)*cos(q(3)))/2, 0, 0, d*qdot(6)*cos(q(6))]; 
      JacobianQdot_(4,:)= [ 0, 0, -(b*qdot(3)*sin(q(3)))/2, 0, 0, d*qdot(6)*sin(q(6))]; 
      JacobianQdot_(5,:)= [ 0, 0, 0, 0, 0, -d*qdot(6)*sin(q(6))]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      JacobianQdot_(6,:)= [ 0, 0, 0, 0, 0, 0]; 

end
