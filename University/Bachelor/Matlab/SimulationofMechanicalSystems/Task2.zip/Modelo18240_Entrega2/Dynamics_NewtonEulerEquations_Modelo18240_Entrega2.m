function Dynamics_NewtonEulerEquations_Modelo18240_Entrega2(Model) 

     close all 
     clc 

     %% General variables 

     Model = 'Modelo18240_Entrega2';

     neq = 6; 
     ngdl = 1; 
     neqBG = 0; 

     % Model parameters 
     Param= Parameters_Modelo18240_Entrega2(0,zeros(6,1));

     b= Param.b;
     d= Param.d;
     phi10= Param.phi10;
 
     %% Define initial conditions 
     q = [0; 0; pi/2; -2*d; b; 0]; 

     t = 0;
     %% Solve mechanism initial position 
     figure('Name', 'Initial position dined by the user', 'Color', 'white'); 
     Animation_Modelo18240_Entrega2(q);

     S = Displacements_(Model, q, t); 
     q0 = S; 
     figure('Name', 'Adjusted initial postion', 'Color', 'white'); 
     Animation_Modelo18240_Entrega2(S);

     %% Number of differential-agebraic equations to be solved 
     numberofDAEequations = 2*neq+(neq-ngdl)+neqBG; 

     %% Initial conditions for dynamic analysis 
     x = zeros(numberofDAEequations,1); 

     xp=zeros(numberofDAEequations,1); 
     fixed_x0=zeros(numberofDAEequations,1); 
     fixed_xp0=zeros(numberofDAEequations,1); 

     tspan = [0:0.01:10]; 

     x = zeros(numberofDAEequations,1);  
     x(neq+1:2*neq)= q0; %% Initial position  
     xp=zeros(numberofDAEequations,1);  
     fixed_x0=zeros(numberofDAEequations,1);  
     fixed_xp0=zeros(numberofDAEequations,1);  

     solver = 'ode23t'; 
     y0_guess = x;    
     yp_guess = zeros(numberofDAEequations,1); 
     % Model responding to the form Mq'=f(t,q) 
     % with Differential Algebraic Equations (DAE) 
     % The function f(t,q) uses the semiexplicit equations form
     MassMatrixNewtonEuler = str2func(sprintf('MassMatrixNewtonEuler_%s',Model)); 
     Systemode23t_NewtonEuler = str2func(sprintf('eqNewtonEulerSemiexplicit_%s',Model)); 
     ImplicitDAE = @(time,y,yp) MassMatrixNewtonEuler(q0,time,y)*yp - Systemode23t_NewtonEuler(q0,time,y);
     [x_0,xp_0,resnrm] = decic(ImplicitDAE,0,x,fixed_x0,xp,fixed_xp0); %Determine consistent yp0
     options = odeset('Mass', @(time,y) MassMatrixNewtonEuler(q0,time,y), 'InitialSlope', xp_0, 'RelTol',1.0e-3, 'AbsTol', 1.0e-5);
     [t1,x] = ode23t(@(time,y) Systemode23t_NewtonEuler(q0,time,y), tspan, x_0, options);

     tini=tspan(1);
     tend=tspan(end);
     deltat=(tend-tini)/(length(tspan)-1);
     xp= diff(x,1,1)/deltat;
     xp(end+1,:)= xp(end,:);

     h = now;
     dir = pwd;
     save Modelo18240_Entrega2;

     %% Plots for Dynamics 
     figure('Name', 'x-y plots for Dynamics', 'Color', 'white'); 
     Subplots_Dynamics_Modelo18240_Entrega2(q0,t1,x,xp);

     %% Dynamics Animation 
     figure('Name', 'Dynamics Animation', 'Color', 'white'); 
     Animation_Modelo18240_Entrega2(x(:,neq+1:2*neq)');

end

function equations = eqNewtonEulerSemiexplicit_Modelo18240_Entrega2(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo18240_Entrega2(t,x);

       K1= Param.K1;
       M1= Param.M1;
       M2= Param.M2;
       R1= Param.R1;
       b= Param.b;
       d= Param.d;
       g= Param.g;


 %% Semiexplicit Equations 
       equations(1,1) = -K1*x(7); 
       equations(2,1) = - M1*g - (K1*((b - 2*x(8))^2/(b^2 - 4*b*x(8) + 4*x(7)^2 + 4*x(8)^2))^(1/2)*(b^2 - 4*b*x(8) + 4*x(7)^2 + 4*x(8)^2)^(1/2))/2; 
       equations(3,1) = 0; 
       equations(4,1) = - R1*x(4) - R1*d*x(6)*sin(x(12)); 
       equations(5,1) = -M2*g; 
       equations(6,1) = 0; 
       equations(7,1) = x(1); 
       equations(8,1) = x(2); 
       equations(9,1) = x(3); 
       equations(10,1) = x(4); 
       equations(11,1) = x(5); 
       equations(12,1) = x(6); 
       equations(13,1) = - x(1) - (b*x(3)*sin(x(9)))/2; 
       equations(14,1) = (b*x(3)*cos(x(9)))/2 - x(2); 
       equations(15,1) = x(4) - x(1) + (b*x(3)*sin(x(9)))/2 - d*x(6)*sin(x(12)); 
       equations(16,1) = x(5) - x(2) - (b*x(3)*cos(x(9)))/2 + d*x(6)*cos(x(12)); 
       equations(17,1) = x(5) - d*x(6)*cos(x(12)); 

       dispstat(sprintf('  t = %8.2f',t));
 
end 

function Mass_equations = MassMatrixNewtonEuler_Modelo18240_Entrega2(x_0, t, x)

     %% Model parameters 
       Param= Parameters_Modelo18240_Entrega2(t,x);

       J1= Param.J1;
       J2= Param.J2;
       M1= Param.M1;
       M2= Param.M2;
       b= Param.b;
       d= Param.d;

 %% Mass Matrix for NewtonEuler Equations 
       Mass_equations(1,:) = [ M1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0];
       Mass_equations(2,:) = [ 0, M1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0];
       Mass_equations(3,:) = [ 0, 0, J1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -(b*sin(x(9)))/2, (b*cos(x(9)))/2, (b*sin(x(9)))/2, -(b*cos(x(9)))/2, 0];
       Mass_equations(4,:) = [ 0, 0, 0, M2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0];
       Mass_equations(5,:) = [ 0, 0, 0, 0, M2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1];
       Mass_equations(6,:) = [ 0, 0, 0, 0, 0, J2, 0, 0, 0, 0, 0, 0, 0, 0, -d*sin(x(12)), d*cos(x(12)), -d*cos(x(12))];
       Mass_equations(7,:) = [ 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(8,:) = [ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(9,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(10,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(11,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0];
       Mass_equations(12,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0];
       Mass_equations(13,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(14,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(15,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(16,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
       Mass_equations(17,:) = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
 
end 

function U = Subplots_Dynamics_Modelo18240_Entrega2(x_0,t,x_,xp_)

     %% Model parameters 
     Param= Parameters_Modelo18240_Entrega2(t,x_);

     d= Param.d;
 
 %% Subplots definition 

     subplot(4,2,1);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = x_(i,10) + d*cos(x_(i,12));
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('X displacement - slider (m)');
     grid

     subplot(4,2,2);
     for i=1:size(x_,1)
         X_(i) = x_(i,7);
         Y_(i) = x_(i,8);
     end
     plot(X_,Y_);
     xlabel('X displacement - crank (m)');
     title('Y displacement - crank (m)');
     axis('equal')
     grid

     subplot(4,2,3);
     for i=1:size(x_,1)
         X_(i) = x_(i,10);
         Y_(i) = x_(i,11);
     end
     plot(X_,Y_);
     xlabel('X displacement - slider (m)');
     title('Y displacement - slider (m)');
     axis('equal')
     grid

     subplot(4,2,4);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,4);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('X acceleration - COG slider (m2/s)');
     grid

     subplot(4,2,5);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,13);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force X at A (N)');
     grid

     subplot(4,2,6);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,14) + xp_(i,17);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force Y at A+C (N)');
     grid

     subplot(4,2,7);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,15);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force X at B (N)');
     grid

     subplot(4,2,8);
     for i=1:size(x_,1)
         X_(i) = t(i);
         Y_(i) = xp_(i,16);
     end
     plot(X_,Y_);
     xlabel('Time (s)');
     title('Constraint Force Y at B (N)');
     grid

 
end 

function Animation_Modelo18240_Entrega2(y) 

%% Model parameters 
     t=0; x=0; 
     Param= Parameters_Modelo18240_Entrega2(t,x);
     b= Param.b;
     d= Param.d;
     b= Param.b;

%% Bodies to be animated 
     Body{1} = [ -b/2, 0.02, b/2, 0.02; 
                 b/2, 0.02, b/2, -0.02; 
                  b/2, -0.02, -b/2, -0.02; 
                 -b/2, -0.02, -b/2, 0.02]; 

     Body{2} = [ -d, 0.02, d, 0.02; 
                  d, 0.02, d, -0.02; 
                  d, -0.02, -d, -0.02; 
                 -d, -0.02, -d, 0.02]; 

     NumberOfBodies = length(Body);
     NumberOfLines = 1;

 %% Animation viewport 
     axis equal 
     axis ([ -1.5 3.5 -1.5 1.5]);
     grid on 

     definecolor = {'r' 'g' 'b' 'm' 'k' 'r'}; 

% Begin Animation
     y = transpose(y);
     sizeoft=size(y,1);
     for j=1:NumberOfBodies
         bodydraw{j}=line(zeros(size(Body{j},1)),zeros(size(Body{j},1)));
     end
     for j=1:1
         linedraw{j}=line(zeros(1,1),zeros(1,1));
     end
     v = VideoWriter('AnimationFile_Modelo18240_Entrega2','MPEG-4'); 
     open(v);

     for i1=1:sizeoft
        ynew(1,i1) = y(i1, 1);
        ynew(2,i1) = y(i1, 2);
        ynew(3,i1) = y(i1, 3);
        ynew(4,i1) = y(i1, 4);
        ynew(5,i1) = y(i1, 5);
        ynew(6,i1) = y(i1, 6);
        lineplot(1,1,i1) = 0;
        lineplot(1,2,i1) = b/2;
        lineplot(1,3,i1) = y(i1, 1);
        lineplot(1,4,i1) = y(i1, 2);
        for j=1:NumberOfBodies
             colorindex= j - floor((j-1)/5)*5;
             for i=1:size(Body{j},1)
                 R_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,1:2));
                 S_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,3:4));
                 set(bodydraw{j}(i),'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',definecolor{colorindex},'LineWidth',1);
             end
         end
         for j=1:1
             colorindex= j - floor((j-1)/5)*5;
             R_= [lineplot(j,1,i1); lineplot(j,2,i1)];
             S_= [lineplot(j,3,i1); lineplot(j,4,i1)];
             set(linedraw{j},'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',[0.494 0.184 0.556], 'LineStyle', '--');
         end
         drawnow nocallbacks;
         frame = getframe(gcf);
         writeVideo(v,frame);

    end
    close(v);

end
