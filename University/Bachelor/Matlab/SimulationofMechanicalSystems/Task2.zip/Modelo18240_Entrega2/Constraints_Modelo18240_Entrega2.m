function Constraints_ = Constraints_Modelo18240_Entrega2(q,t)

%% Model parameters 
      Param= Parameters_Modelo18240_Entrega2(t,q);

      b= Param.b;
      d= Param.d;
      phi10= Param.phi10;
 
%% Kinematic constraints 
      Constraints_(1)= q(1) - (b*cos(q(3)))/2; 
      Constraints_(2)= q(2) - (b*sin(q(3)))/2; 
      Constraints_(3)= q(1) - q(4) + (b*cos(q(3)))/2 - d*cos(q(6)); 
      Constraints_(4)= q(2) - q(5) + (b*sin(q(3)))/2 - d*sin(q(6)); 
      Constraints_(5)= d - q(5) + d*sin(q(6)); 
 
%% Drivers 
      Constraints_(6) = q(3) - phi10; 
 
end 

