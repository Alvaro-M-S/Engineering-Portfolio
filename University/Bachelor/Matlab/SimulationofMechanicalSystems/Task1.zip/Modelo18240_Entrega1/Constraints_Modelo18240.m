function Constraints_ = Constraints_Modelo18240(q,t)

%% Model parameters 
      Param= Parameters_Modelo18240(t,q);

      d= Param.d;
      l1= Param.l1;
      l2= Param.l2;
      l3= Param.l3;
      phi0= Param.phi0;
      w= Param.w;
 
%% Kinematic constraints 
      Constraints_(1)= q(1) + (l1*cos(q(3)))/2; 
      Constraints_(2)= q(2) + (l1*sin(q(3)))/2; 
      Constraints_(3)= q(2)*cos(q(6)) - q(5)*cos(q(6)) - q(1)*sin(q(6)) + q(4)*sin(q(6)) + (l1*cos(q(3))*sin(q(6)))/2 - (l1*cos(q(6))*sin(q(3)))/2; 
      Constraints_(4)= q(8)*cos(q(6)) - q(5)*cos(q(6)) + q(4)*sin(q(6)) - q(7)*sin(q(6)) + (l3*cos(q(6))*sin(q(9)))/2 - (l3*cos(q(9))*sin(q(6)))/2; 
      Constraints_(5)= d + q(4) - (l2*cos(q(6)))/2; 
      Constraints_(6)= q(5) - (l2*sin(q(6)))/2; 
      Constraints_(7)= (l3*cos(q(9)))/2 - q(7) - d; 
      Constraints_(8)= q(9) - q(6) - (3*pi)/2; 
 
%% Drivers 
      Constraints_(9) = q(3) - phi0 - 2*t*w*pi; 
 
end 

