function JacobianQdot_ = JacobianQdot_Modelo18240(q,qdot,t)
%% Model parameters 
      Param= Parameters_Modelo18240(t,q);

      l1= Param.l1;
      l2= Param.l2;
      l3= Param.l3;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      JacobianQdot_(1,:)= [ 0, 0, -(l1*qdot(3)*cos(q(3)))/2, 0, 0, 0, 0, 0, 0]; 
      JacobianQdot_(2,:)= [ 0, 0, -(l1*qdot(3)*sin(q(3)))/2, 0, 0, 0, 0, 0, 0]; 
      JacobianQdot_(3,:)= [ -qdot(6)*cos(q(6)), -qdot(6)*sin(q(6)), qdot(6)*((l1*cos(q(3))*sin(q(6)))/2 - (l1*cos(q(6))*sin(q(3)))/2) - qdot(3)*((l1*cos(q(3))*sin(q(6)))/2 - (l1*cos(q(6))*sin(q(3)))/2), qdot(6)*cos(q(6)), qdot(6)*sin(q(6)), qdot(3)*((l1*cos(q(3))*sin(q(6)))/2 - (l1*cos(q(6))*sin(q(3)))/2) - qdot(1)*cos(q(6)) + qdot(4)*cos(q(6)) - qdot(2)*sin(q(6)) + qdot(5)*sin(q(6)) - qdot(6)*(q(2)*cos(q(6)) - q(5)*cos(q(6)) - q(1)*sin(q(6)) + q(4)*sin(q(6)) + (l1*cos(q(3))*sin(q(6)))/2 - (l1*cos(q(6))*sin(q(3)))/2), 0, 0, 0]; 
      JacobianQdot_(4,:)= [ 0, 0, 0, qdot(6)*cos(q(6)), qdot(6)*sin(q(6)), qdot(9)*((l3*cos(q(6))*sin(q(9)))/2 - (l3*cos(q(9))*sin(q(6)))/2) + qdot(4)*cos(q(6)) - qdot(7)*cos(q(6)) + qdot(5)*sin(q(6)) - qdot(8)*sin(q(6)) + qdot(6)*(q(5)*cos(q(6)) - q(8)*cos(q(6)) - q(4)*sin(q(6)) + q(7)*sin(q(6)) - (l3*cos(q(6))*sin(q(9)))/2 + (l3*cos(q(9))*sin(q(6)))/2), -qdot(6)*cos(q(6)), -qdot(6)*sin(q(6)), qdot(6)*((l3*cos(q(6))*sin(q(9)))/2 - (l3*cos(q(9))*sin(q(6)))/2) - qdot(9)*((l3*cos(q(6))*sin(q(9)))/2 - (l3*cos(q(9))*sin(q(6)))/2)]; 
      JacobianQdot_(5,:)= [ 0, 0, 0, 0, 0, (l2*qdot(6)*cos(q(6)))/2, 0, 0, 0]; 
      JacobianQdot_(6,:)= [ 0, 0, 0, 0, 0, (l2*qdot(6)*sin(q(6)))/2, 0, 0, 0]; 
      JacobianQdot_(7,:)= [ 0, 0, 0, 0, 0, 0, 0, 0, -(l3*qdot(9)*cos(q(9)))/2]; 
      JacobianQdot_(8,:)= [ 0, 0, 0, 0, 0, 0, 0, 0, 0]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      JacobianQdot_(9,:)= [ 0, 0, 0, 0, 0, 0, 0, 0, 0]; 

end
