clear all
clc

%% Model name
   Model.Name='Modelo18240';


%% Model parameters values
   Model.Values = {'l1 = 8'; 'l2 = 16'; 'l3 = 12';
             'phi0 = 0'; 'w = 0.3'; 'Amp = 0.5'; 'd = 10' }; 

%% Model variables list  
    Model.System_variables= {'x1'; 'y1'; 'phi1'; 'x2'; 'y2'; 'phi2'; 'x3'; 'y3'; 'phi3'};

%% Kinematic constraints 
    Model.Constraints = { 'x1 + l1/2*cos(phi1)';
                          'y1 + l1/2*sin(phi1)';
                          'y1*cos(phi2) - y2*cos(phi2) - l1/2*sin(phi1)*cos(phi2) - x1*sin(phi2) + x2*sin(phi2) + l1/2*cos(phi1)*sin(phi2)';
                          'y3*cos(phi2) - y2*cos(phi2) + l3/2*sin(phi3)*cos(phi2) - x3*sin(phi2) + x2*sin(phi2) - l3/2*cos(phi3)*sin(phi2)';
                          'x2 - l2/2*cos(phi2) + d';
                          'y2 - l2/2*sin(phi2)';
                          '-x3 + l3/2*cos(phi3) - d';
                          'phi3-phi2-3*pi*1/2'};

%% Driver equations
    Model.Drivers = {'phi1 - 2*pi*w*t - phi0'}; 


%% Type of Analysis (Kinematics, Newton-Euler or Lagrange)
    Model.AnalysisType= 'Kinematics';
    
%% Time span
    Model.t= '[0:0.02:20]';
    
%% Initial conditions
    Model.Initial_conditions = {'-l1/2'; 'l1/2'; 'pi*1.7'; '-d+l2/2'; 'l2/2'; 'pi/4'; '-d+l3/2'; '20-l3/2'; 'pi*1.75'};  
    
%% Define animation
    % Objet to be animated, defined by polygons in local body coordinates
    Model.Body{1} = {'-l1/2', '0.02', 'l1/2', '0.02';
                     'l1/2', '0.02', 'l1/2', '-0.02';
                     'l1/2', '-0.02', '-l1/2', '-0.02';
                     '-l1/2', '-0.02', '-l1/2', '0.02'};      
    Model.Body{2} = {'-l2/2', '0.02', 'l2/2', '0.02';
                     'l2/2', '0.02', 'l2/2', '-0.02';
                     'l2/2', '-0.02', '-l2/2', '-0.02';
                     '-l2/2', '-0.02', '-l2/2', '0.02'};      
    Model.Body{3}  = {'-l3/2', '0.02', 'l3/2', '0.02';
                     'l3/2', '0.02', 'l3/2', '-0.02';
                     'l3/2', '-0.02', '-l3/2', '-0.02';
                     '-l3/2', '-0.02', '-l3/2', '0.02'};     

    % Body movements for animation
    Model.BodyMovements = {'x1',  'y1',  'phi1';
                           'x2',  'y2',  'phi2';
                           'x3',  'y3',  'phi3'};      
    
    % Viewport for animation
    Model.Viewport = {'-20 ', '20', ' -20', ' 20'};

%% Plots x-y for Kinematics
    Model.NumSubplotsKinematics = {3, 3};
    Model.SubplotsKinematics = {'t', 'Time (s)', 'y2', 'Y displacement - slider (m)';
                                't', 'Time (s)', 'x2', 'X displacement - slider (m)';
                                't', 'Time (s)', 'x3', 'X displacement - piston (m)';
                                't', 'Time (s)', 'x1dot', 'X velocity crank (m)';
                                't', 'Time (s)', 'x2dot', 'X velocity slider (m)';
                                't', 'Time (s)', 'x3dot', 'X velocity piston (m)';
                                'x1', 'X displacement - crank (m)', 'y1', 'Y displacement - crank (m)';
                                'x2', 'X displacement - slider (m)', 'y2', 'Y displacement - slider (m)';
                                'x3', 'X displacement - piston (m)', 'y3', 'Y displacement - piston (m)'};

%% Construction of MatLab model. DO NOT MODIFY
    Construct_(Model);




