function Kinematics_Modelo18240(Model) 

     close all 
     clc 

%% Model parameters 
     Param= Parameters_Modelo18240(0,zeros(8,1));
     d= Param.d;
     l1= Param.l1;
     l2= Param.l2;
     l3= Param.l3;
     phi0= Param.phi0;
     w= Param.w;
 
     %% Model Variables 

     Model = 'Modelo18240';

     neq = 8; 
     ngdl = 1; 

     %% Initial conditions 
     q = [ -l1/2; l1/2; 1.7*pi; l2/2 - d; l2/2; pi/4; l3/2 - d; 20 - l3/2; 1.75*pi];
     t= 0;

     %% Solve mechanism initial position 
     figure('Name', 'Initial position defined by the user', 'Color', 'white'); 
     Animation_Modelo18240(q);

     S = Displacements_(Model, q, t); 
     figure('Name', 'Initial position adjusted by the solver', 'Color', 'white'); 
     Animation_Modelo18240(S);

     %% Time span simulation 
     t = [0:0.02:20]; 

     %% Solve mechanism movement from the driver inputs 
     S = Displacements_(Model, q, t); 

     %% Solve mechanism velocities 
     V = Velocities_Modelo18240(Model, t(1:size(S,2)), S);

     %% Solve mechanism accelerations 
     Acel = Accelerations_Modelo18240(Model, t(1:size(S,2)), S, V);

     h = now;
     dir = pwd;
     save Modelo18240;

 
     %% Plots for kinematics  
     figure('Name', 'Kinematics x-y plots', 'Color', 'white'); 
     plots=S; 
     plots(size(S,1)+1:2*size(S,1),:)=V; 
     plots(size(S,1)*2+1:3*size(S,1),:)=Acel; 
     t=t(1:size(S,2)); 
     Subplots_Kinematics_Modelo18240(q,t,plots'); 

     %% Animation 
     figure('Name', 'Animation of Kinematics', 'Color', 'white'); 
     Animation_Modelo18240(S);

end

function V = Velocities_Modelo18240(Model, t, S)

%% Model parameters 
      Param= Parameters_Modelo18240(0,S(:,1));
      w= Param.w;

%% Jacobian matrix 
      JacobianMatrix = @Jacobian_Modelo18240;

%% Time derivative of constraints 
      tdot=zeros(size(S)); 
      tdot(1,:)= 0; 
      tdot(2,:)= 0; 
      tdot(3,:)= 0; 
      tdot(4,:)= 0; 
      tdot(5,:)= 0; 
      tdot(6,:)= 0; 
      tdot(7,:)= 0; 
      tdot(8,:)= 0; 
      tdot(9,:)= 2*w*pi; 

      for i=1:size(S,2)
          V(:,i)=JacobianMatrix(S(:,i),t)\tdot(:,i);
      end
 
end 

function Acel = Accelerations_Modelo18240(Model, t, S, V)

%% Model parameters 
      Param= Parameters_Modelo18240(0,S(:,1));
      w= Param.w;

%% Jacobian matrix 
      JacobianMatrix = @Jacobian_Modelo18240;

      JacobianMatrixQdot = @JacobianQdot_Modelo18240;

%% Time derivative of constraints 
      tdot=zeros(size(S)); 
      tdotdot=zeros(size(S)); 
      tdot(1,:)= 0; 
      tdot(2,:)= 0; 
      tdot(3,:)= 0; 
      tdot(4,:)= 0; 
      tdot(5,:)= 0; 
      tdot(6,:)= 0; 
      tdot(7,:)= 0; 
      tdot(8,:)= 0; 
      tdot(9,:)= 2*w*pi; 
      tdotdot(1,:)= 0; 
      tdotdot(2,:)= 0; 
      tdotdot(3,:)= 0; 
      tdotdot(4,:)= 0; 
      tdotdot(5,:)= 0; 
      tdotdot(6,:)= 0; 
      tdotdot(7,:)= 0; 
      tdotdot(8,:)= 0; 
      tdotdot(9,:)= 0; 

      for i=1:size(S,2)
          Acel(:,i)=-JacobianMatrix(S(:,i),t)\(JacobianMatrixQdot(S(:,i),V(:,i),t)*V(:,i)+tdotdot(:,i));
      end
 
end 

function U = Subplots_Kinematics_Modelo18240(x_0,t,x,xdot,xdotdot)

     %% Model Parameters 
     Param= Parameters_Modelo18240(0,zeros(9,1));

 
 %% Subplots definition 

     subplot(3,3,1);
     for i=1:size(x,1)
         X(i) = t(i);
         Y(i) = x(i,5);
     end
     plot(X,Y);
     xlabel('Time (s)');
     title('Y displacement - slider (m)');
     grid

     subplot(3,3,2);
     for i=1:size(x,1)
         X(i) = t(i);
         Y(i) = x(i,4);
     end
     plot(X,Y);
     xlabel('Time (s)');
     title('X displacement - slider (m)');
     grid

     subplot(3,3,3);
     for i=1:size(x,1)
         X(i) = t(i);
         Y(i) = x(i,7);
     end
     plot(X,Y);
     xlabel('Time (s)');
     title('X displacement - piston (m)');
     grid

     subplot(3,3,4);
     for i=1:size(x,1)
         X(i) = t(i);
         Y(i) = x(i,10);
     end
     plot(X,Y);
     xlabel('Time (s)');
     title('X velocity crank (m)');
     grid

     subplot(3,3,5);
     for i=1:size(x,1)
         X(i) = t(i);
         Y(i) = x(i,13);
     end
     plot(X,Y);
     xlabel('Time (s)');
     title('X velocity slider (m)');
     grid

     subplot(3,3,6);
     for i=1:size(x,1)
         X(i) = t(i);
         Y(i) = x(i,16);
     end
     plot(X,Y);
     xlabel('Time (s)');
     title('X velocity piston (m)');
     grid

     subplot(3,3,7);
     for i=1:size(x,1)
         X(i) = x(i,1);
         Y(i) = x(i,2);
     end
     plot(X,Y);
     xlabel('X displacement - crank (m)');
     title('Y displacement - crank (m)');
     axis('equal')
     grid

     subplot(3,3,8);
     for i=1:size(x,1)
         X(i) = x(i,4);
         Y(i) = x(i,5);
     end
     plot(X,Y);
     xlabel('X displacement - slider (m)');
     title('Y displacement - slider (m)');
     axis('equal')
     grid

     subplot(3,3,9);
     for i=1:size(x,1)
         X(i) = x(i,7);
         Y(i) = x(i,8);
     end
     plot(X,Y);
     xlabel('X displacement - piston (m)');
     title('Y displacement - piston (m)');
     axis('equal')
     grid

 
end 

function Animation_Modelo18240(y) 

%% Model parameters 
     t=0; x=0; 
     Param= Parameters_Modelo18240(t,x);
     l1= Param.l1;
     l2= Param.l2;
     l3= Param.l3;

%% Bodies to be animated 
     Body{1} = [ -l1/2, 0.02, l1/2, 0.02; 
                 l1/2, 0.02, l1/2, -0.02; 
                 l1/2, -0.02, -l1/2, -0.02; 
                 -l1/2, -0.02, -l1/2, 0.02]; 

     Body{2} = [ -l2/2, 0.02, l2/2, 0.02; 
                 l2/2, 0.02, l2/2, -0.02; 
                 l2/2, -0.02, -l2/2, -0.02; 
                 -l2/2, -0.02, -l2/2, 0.02]; 

     Body{3} = [ -l3/2, 0.02, l3/2, 0.02; 
                 l3/2, 0.02, l3/2, -0.02; 
                 l3/2, -0.02, -l3/2, -0.02; 
                 -l3/2, -0.02, -l3/2, 0.02]; 

     NumberOfBodies = length(Body);
     NumberOfLines = 0;

 %% Animation viewport 
     axis equal 
     axis ([ -20 20 -20 20]);
     grid on 

     definecolor = {'r' 'g' 'b' 'm' 'k' 'r'}; 

% Begin Animation
     y = transpose(y);
     sizeoft=size(y,1);
     for j=1:NumberOfBodies
         bodydraw{j}=line(zeros(size(Body{j},1)),zeros(size(Body{j},1)));
     end
     for j=1:0
         linedraw{j}=line(zeros(1,1),zeros(1,1));
     end
     for i1=1:sizeoft
        ynew(1,i1) = y(i1, 1);
        ynew(2,i1) = y(i1, 2);
        ynew(3,i1) = y(i1, 3);
        ynew(4,i1) = y(i1, 4);
        ynew(5,i1) = y(i1, 5);
        ynew(6,i1) = y(i1, 6);
        ynew(7,i1) = y(i1, 7);
        ynew(8,i1) = y(i1, 8);
        ynew(9,i1) = y(i1, 9);
        for j=1:NumberOfBodies
             colorindex= j - floor((j-1)/5)*5;
             for i=1:size(Body{j},1)
                 R_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,1:2));
                 S_= [ynew(1+3*(j-1),i1); ynew(2+3*(j-1),i1)]+cambiocoord(ynew(3+3*(j-1),i1))* transpose(Body{j}(i,3:4));
                 set(bodydraw{j}(i),'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',definecolor{colorindex},'LineWidth',1);
             end
         end
         for j=1:0
             colorindex= j - floor((j-1)/5)*5;
             R_= [lineplot(j,1,i1); lineplot(j,2,i1)];
             S_= [lineplot(j,3,i1); lineplot(j,4,i1)];
             set(linedraw{j},'XData',[R_(1),S_(1)],'YData',[R_(2),S_(2)],'Color',[0.494 0.184 0.556], 'LineStyle', '--');
         end
         drawnow nocallbacks;
    end
end
