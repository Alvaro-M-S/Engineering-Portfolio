function Jacobian_ = Jacobian_Modelo18240(q,t)
%% Model parameters 
      Param= Parameters_Modelo18240(t,q);

      l1= Param.l1;
      l2= Param.l2;
      l3= Param.l3;

%% Jacobian matrix. Rows correspondring to the kinematic constraints 
      Jacobian_(1,:)= [ 1, 0, -(l1*sin(q(3)))/2, 0, 0, 0, 0, 0, 0]; 
      Jacobian_(2,:)= [ 0, 1, (l1*cos(q(3)))/2, 0, 0, 0, 0, 0, 0]; 
      Jacobian_(3,:)= [ -sin(q(6)), cos(q(6)), - (l1*cos(q(3))*cos(q(6)))/2 - (l1*sin(q(3))*sin(q(6)))/2, sin(q(6)), -cos(q(6)), q(4)*cos(q(6)) - q(1)*cos(q(6)) - q(2)*sin(q(6)) + q(5)*sin(q(6)) + (l1*cos(q(3))*cos(q(6)))/2 + (l1*sin(q(3))*sin(q(6)))/2, 0, 0, 0]; 
      Jacobian_(4,:)= [ 0, 0, 0, sin(q(6)), -cos(q(6)), q(4)*cos(q(6)) - q(7)*cos(q(6)) + q(5)*sin(q(6)) - q(8)*sin(q(6)) - (l3*cos(q(6))*cos(q(9)))/2 - (l3*sin(q(6))*sin(q(9)))/2, -sin(q(6)), cos(q(6)), (l3*cos(q(6))*cos(q(9)))/2 + (l3*sin(q(6))*sin(q(9)))/2]; 
      Jacobian_(5,:)= [ 0, 0, 0, 1, 0, (l2*sin(q(6)))/2, 0, 0, 0]; 
      Jacobian_(6,:)= [ 0, 0, 0, 0, 1, -(l2*cos(q(6)))/2, 0, 0, 0]; 
      Jacobian_(7,:)= [ 0, 0, 0, 0, 0, 0, -1, 0, -(l3*sin(q(9)))/2]; 
      Jacobian_(8,:)= [ 0, 0, 0, 0, 0, -1, 0, 0, 1]; 

%% Matriz Jacobiana. Jacobian matrix. Rows correspondring to the drivers 
      Jacobian_(9,:)= [ 0, 0, 1, 0, 0, 0, 0, 0, 0]; 

end
