function Param = Parameters_Modelo18240(t,x)

%% Model Parameters 
    l1 = 8; 
    l2 = 16; 
    l3 = 12; 
    phi0 = 0; 
    w = 0.3; 
    Amp = 0.5; 
    d = 10; 

    Param.l1 = l1; 
    Param.l2 = l2; 
    Param.l3 = l3; 
    Param.phi0 = phi0; 
    Param.w = w; 
    Param.Amp = Amp; 
    Param.d = d; 
 
end 

