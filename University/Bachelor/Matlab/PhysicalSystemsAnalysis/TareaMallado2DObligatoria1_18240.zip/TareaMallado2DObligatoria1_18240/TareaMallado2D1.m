%Tarea Mallado 2D 1 �lvaro Morales 18240

% system('EasyMesh_win');

datos='Mallado2D1.xls';

EasyMesh(datos,true)

EasyMeshRepre(datos)