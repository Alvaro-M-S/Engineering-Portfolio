%TareaVoluntariaTema3 InfoEjrcicio3

load('VariablesEj3')

xlswrite('TareaVoluntariaTema3Ej3_18240.xlsx',x,1,'B2');
xlswrite('TareaVoluntariaTema3Ej3_18240.xlsx',y,1,'C2');
xlswrite('TareaVoluntariaTema3Ej3_18240.xlsx',barras,2,'B2');

