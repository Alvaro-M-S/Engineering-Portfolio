%Tarea Tema 3 Ejercicio 4

%Llamar a la funcion

[x,y,barras]=VigaHorizontal_X(1,24,24)
%Para el plot, ordenador los puntos para unirlos y formar las barras

y2=y-1/2; %para centrar el plot

grid on

plot(x,y2,'ro'); %representaci�n grt�fica de los nodos

axis equal

barrasx=[];
barrasy=[];

z=size(barras);

for i=1:z(1)
    barrasx=[barrasx;x(barras(i,1));x(barras(i,2))];
    barrasy=[barrasy;y2(barras(i,1));y2(barras(i,2))];

end

hold on

grid on

plot(barrasx,barrasy,'r-')

save('VariablesEj4')