%Tarea Mallado Electrostatica 2 1 �lvaro Morales 18240

%system('EasyMesh_win');

datos='MallaTE2_18240.xls';

EasyMesh(datos,true)

EasyMeshRepre(datos)
