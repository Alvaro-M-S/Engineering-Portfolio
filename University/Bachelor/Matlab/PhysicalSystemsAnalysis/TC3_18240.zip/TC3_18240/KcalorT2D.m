function [Ke,Be,M,Kte]=KcalorT2D(x,y,k,ro,cp);
% KcalorT2D es la matriz correspondiente a elementos finitos 2D triangulares
% lineales para TRANSMISI�N DE CALOR 2D
%
% Variables de entrada:
%    x,y:  Vectores 3x1 con la coordenadas de los tres nodos del tri�ngulo
%    k:    Conductividad T�rmica
%    ro:   densidad
%    cp:   calor espec�fico
%
% Variables de salida
%    Ke: Matriz elemental de conducci�n
%
%    Be:  Matriz que permite calcular el vector de fuentes nodales de calor q
%         a partir del vector de densidades de fuentes de calor p
%         q = Be'*p
%
%    M :  Matriz que permite calcular el vector flujo de calor f
%         a partir del vector columna u=[ui;uj;uk] que contiene
%         las temperaturas de los tres nodos del tri�ngulo
%         f = M*u
%
%    Kte: Matriz elemental de capacidad t�rmica
%
% Ver la siguiente referencia (es an�logo al problema de electr�statica)
%   
%   "Aplicaciones del M�todo de los Elementos Finitos en F�sica"
%   Jes�s de Vicente y Oliva
%   Sec. Publicaciones ETSII (1998) ISBN 84-7484-127-5
%   Cap�tulo 4, 'Electrost�tica en 2D'
%   p�ginas 92 a 94

    x=x(:); y=y(:);
    
    D=[ [1 0 0]', [-1 1 0 ]', [-1 0 1]' ];
    A=eye(3); A(1,1)=0;
    R=ones(3,3);
    R(2:3,:)=[ x' ; y' ];
    Se=1/2*abs(det(R*D));
    Rinv=inv(R);
    
    % Matriz Elemental de Conducci�n
    Ke = k*Se*Rinv*A*Rinv';
    
    % Matriz B
    Be = Se/12*[ 2 1 1 ; 1 2 1 ; 1 1 2 ];
	
	% Matriz M
	M = -k*[ 0 1 0 ;  0 0 1 ]*Rinv';
    
    % Matriz Kte
    if nargout>3
        Kte = ro*cp*Be';
    end
        
end