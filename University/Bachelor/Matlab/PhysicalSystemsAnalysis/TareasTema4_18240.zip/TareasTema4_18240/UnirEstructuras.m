function [N,B]=UnirEstructuras(Na,Ba,Nb,Bb,tol);
% Uni?n de estructuras: une las estructuras (Na,Ba) y (Nb,Bb) dando
% lugar a la estructura uni?n (N,B).
%
% Se eliminan los nodos y barras repetidos
%
% Variables de entrada
%     Na,Ba : variables que definen la estructura 'a'. 
%             Na tiene dos columnas, la primera son las coordenadas x
%             de los nodos y la segunda las coordenadas y de los nodos
%             En Ba, cada fila representa una barra. El primer elemento de
%             la fila es el n?mero de nodo en que comienza la barra y el
%             segundo n?mero de la fila es el nodo en el cual termina la
%             barra.
%      Nb,Bb: variables que definen la estrcutra 'b'.
%        tol: Tolerancia. Si dos coordenadas difieren en una cantidad
%             inferior a tol, se consideran que son iguales.
%
% Variables de salida
%        N,B: Variables que definen la estructura uni?n de 'a' y 'b'

N=[Na;Nb];            % Uni?n de las matrices de coordenadas de los nodos
% Redondeo
if nargin<5
    tol=1e-6*max(abs(N(:)));
end
N=round(N/tol)*tol;   % Redondeo a tol
na=length(Na(:))/2;   % N?mero de nodos en la primera estructura
n =length(N(:,end));  % N?mero de nodos en la uni?n de ambas estructuras
B=[ Ba ; na+Bb ];     % Uni?n de las matrices de barras

% Eliminaci?n de los nodos repetidos
[N,new2old,old2new]=unique(N,'rows');

Bnew=B;  % Renumeraci?n de los nodos en la matriz de barras
for i=1:n
    inew=old2new(i);
    ii=find(B(:)==i);
    Bnew(ii)=inew;
end

B=sort(Bnew,2); % Se reordenan los nodos de modo que el primero de cada barra
                % sea el menor
                
                
% Se eliminan las barras repetidas
B=unique(B,'rows');
