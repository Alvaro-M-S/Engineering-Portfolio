%TareasTema4 Ejercicio 2 (Leer dos notas del final)

%crearemos la estructura final de izquierda a derecha

%Para emplear la funci�n unir estructuras necesitamos primero un pilar
%vertical y un arco de 180 a 90 grados, simetrico al del ejercicio 1

%Empezamos creando el pilar vertical

[x1,y1,barras1]=VigaVertical_X(1,10,10);

N1=[x1 y1];
B1=barras1;

%Despu�s el arco

[x2,y2,barras2]=ArcoRomano_X(1,10,16);

%Ponemos los x2 e y2 en la posici�n final de los x e y del vertical
%anterior

x2=-x2+10;
x2=x2+x1(22);
y2=y2+y1(22);

N2=[x2 y2];
B2=barras2;

%Unimos estas dos primeras estructuras

[N3,B3]=UnirEstructuras(N1,B1,N2,B2);

%A la estructura resultante la denominaremos estructura 3 y la juntaremos
%con una barra horizontal, creando la estructura 5

%Barra horizontal

[x4,y4,barras4]=VigaHorizontal_X(1,10,10);

x4=x4+x2(34);
y4=y4+y2(33);

N4=[x4 y4];
B4=barras4;

%Union estructura 3 y barra horizontal

[N5,B5]=UnirEstructuras(N3,B3,N4,B4);

%Union estructura 5 con arco de 0 a 90 grados

[x6,y6,barras6]=ArcoRomano_X(1,10,16);

x6=x6+N5(74,1);
y6=y6+10;

N6=[x6 y6];
B6=barras6;

[N7,B7]=UnirEstructuras(N5,B5,N6,B6);

%Union estructura 7 con viga vertical, dando la estructura final

[x8,y8,barras8]=VigaVertical_X(1,10,10);

x8=x8+31.02;

N8=[x8 y8];
B8=barras8;

[N,B]=UnirEstructuras(N7,B7,N8,B8);

%Represetnacion de la estructura
% 
h=Repre(N(:,1),N(:,2),B,B1,B2,B4,B6,B8);
% 
% h=Repre2D2(N(:,1),N(:,2),B);

%Utilizando la funci�n repre2D de clase, pero metiendo mas variables y bucles para cambiar el color y as� poder hacer cada tramo de un color.

%NOTAS

%Salta una figura con un arco debido a la funci�n empleada para la tarea 1
%del tema y no crear otra u modficar esta

%Los colores de la figura final est�n mal. Prob� con variaciones de la
%funci�n repre2D de clase y la de moodle. Tambi�n prob� con la funci�n
%repre creada por mi. Creo que el error viene del orden de las matrices N
%al unir estructuras. Pero como la funci�n estructuras estaba dada de
%antemano no logro ver el fallo. Se que las x e y no siguen el orden que
%deber�an de seguir y por eso el plot se salta unos nudos por otros
