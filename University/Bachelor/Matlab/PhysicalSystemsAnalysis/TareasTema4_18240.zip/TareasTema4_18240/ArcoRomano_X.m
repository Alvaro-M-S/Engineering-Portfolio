function [x,y,barras]=ArcoRomano_X(a,R,n)

% Variables de entrada:
%      a : ancho del arco, en metros
%      R : radio (medio) del arco, en metros
%      n : n�mero de cuadrados (n�mero entero)
% Variables de salida:
%      x : vector de dimensiones 1 NN � (siendo NN el n�mero de nodos) que contiene las coordenadas xi de los nodos (expresadas en metros).
%      y : vector de dimensiones 1 NN � (siendo NN el n�mero de nodos) que contiene las coordenadas yi de los nodos (expresadas en metros).
%      barras : Matriz de dimensiones 2 NB � (siendo NB el n�mero de barras) que contiene en cada fila el n�mero de los nodos en comienza y termina la barra correspondiente 

%Basandonos en la creaci�n de un pilar pero con polares

x=[]; y=[];

n=n; R=R; a=a;

%Se crea primero un pilar vertical

for p=1:(n+1)
    x=[ x ;    0  ;   1  ];
    y=[ y ; (p-1) ; (p-1)];
end

%Se unen y crea la conectividad de las barras

barras=[];
for p=1:n
    b1=5*(p-1)+1;
    n1=2*(p-1)+1;
    n0=n1-1;
    barras=[barras;
        n0+1 n0+2 ;
        n0+1 n0+3 ;
        n0+2 n0+4 ;
        n0+2 n0+3 ;
        n0+1 n0+4 ];
end

% Falta la barra superior horizontal
Nn=length(x);
barras=[ barras ;
         Nn-1  Nn];

Fijos=[ 0*x 0*y];
Fijos(1:2,:)=1; % Los nodos 1 y 2 fijos

%Se arquea la barra vertical formando un arco, empleando polares

% ro = R + (x-0.5)*a;
ro = R + (x)*a;
theta = y/max(y)*pi/2;

x=ro.*cos(theta);

y=ro.*sin(theta);
    
plot(x,y,'bo');

axis equal
grid on

hold on

[nb,nada]=size(barras);

for b=1:nb
    plot( x(barras(b,:)) , y(barras(b,:)) ,'g' );
end

nn=length(x);

for n=1:nn
  if sum(Fijos(n,:))>0
     plot(x(n),y(n),'ko');
   end
end
  
axis equal

end
