function [algo]=Repre(x,y,barras,barras1,barras2,barras3,barras4,barras5,Fijos)
    
    whos 

    figure
    
    plot(x,y,'bo');

    axis equal
    grid on
    xlabel('X (m)')
    ylabel('Y (m)')

    hold on

    [nb1,nada]=size(barras1);  
    [nb2,nada]=size(barras2);
    [nb3,nada]=size(barras3);
    [nb4,nada]=size(barras4);
    [nb5,nada]=size(barras5);
    
    
    for b=1:(nb1)
        plot( x(barras(b,:)) , y(barras(b,:)) ,'g' );
    end
    for b=(nb1):(nb1+nb2)
        plot( x(barras(b,:)) , y(barras(b,:)) ,'k' );
    end
    for b=(nb1+nb2):(nb1+nb2+nb3-1)
        plot( x(barras(b,:)) , y(barras(b,:)) ,'r' );
    end
    for b=(nb1+nb2+nb3):(nb1+nb2+nb3+nb4-2)
        plot( x(barras(b,:)) , y(barras(b,:)) ,'m' );
    end
    for b=(nb1+nb2+nb3+nb4):(nb1+nb2+nb3+nb4+nb5-3)
        plot( x(barras(b,:)) , y(barras(b,:)) ,'c' );
    end
    
    
    nn=length(x);
    for n=1:nn
        if sum(Fijos(n,:))>0
            plot(x(n),y(n),'ko');
        end
    end

end