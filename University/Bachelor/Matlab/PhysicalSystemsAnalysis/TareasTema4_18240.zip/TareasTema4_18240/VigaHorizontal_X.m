%Tarea 3 Ejercicio 2

function [x,y,barras]=VigaHorizontal_X(a,L,n)

% a :ancho del pilar en m
% L : alto del pilar en m
% n : n�mero de cuadrados (n�mero entero) 

% x : vector de dimensiones 1 NN � (siendo NN el n�mero de nodos) que contiene las coordenadas xi de los nodos (expresadas en metros).
% y : vector de dimensiones 1 NN � (siendo NN el n�mero de nodos) que contiene las coordenadas i
% y de los nodos (expresadas en metros).
% barras : Matriz de dimensiones 2 NB � (siendo NB el n�mero de barras) que contiene en cada fila el n�mero de los nodos en comienza y termina la barra correspondiente

x=[]; y=[]; %creamos los vectores de salida que en un principio estar�n vacios

for p=L/n:L/n:L+1 %bucle para poner en cada piso dos puntos en cero y 1 (eje x), mediante concatenando vectores
    x=[x; (p-L/n); (p-L/n)];
    y=[y; 0; a];
end

barras=[];
for p=1:n
    b1=5*(p-1)+1;
    n1=2*(p-1)+1;
    n0=n1-1;
    barras=[barras;
        n0+1 n0+2 ;
        n0+1 n0+3 ;
        n0+2 n0+4 ;
        n0+2 n0+3 ;
        n0+1 n0+4 ];
end

% Faltar�a la barra superior horizontal
Nn=length(x);
barras=[ barras ;
         Nn-1  Nn];

x
y
barras

end