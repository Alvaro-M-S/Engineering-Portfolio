function h=Repre2D(x,y,b);
   
   h=figure;
   
   plot(x,y,'bo'); 
   grid on
   axis equal
   xlabel('X (m)');
   ylabel('Y (m)');
   hold on
   
   [n,nada]=size(b);
   
   for i=1:n
       A=b(i,1);
       B=b(i,2);
       plot( x([A B]) , y([A B]) ,'g');
   end
end