function [algo]=Repre2D2(x,y,barras,Fijos)
    
    whos 

    figure
    
    plot(x,y,'bo');

    axis equal
    grid on
    xlabel('X (m)')
    ylabel('Y (m)')

    hold on

    [nb,nada]=size(barras);
    for b=1:nb
        plot( x(barras(b,:)) , y(barras(b,:)) ,'k' );
    end

    nn=length(x);
    for n=1:nn
        if sum(Fijos(n,:))>0
            plot(x(n),y(n),'ko');
        end
    end

end