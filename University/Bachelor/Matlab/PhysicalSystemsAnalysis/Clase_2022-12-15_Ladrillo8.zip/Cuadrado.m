function [ x,y ] = Cuadrado( t )
%Cuadrado devuelve las coordenadas x,y de
%   un punto de un cuadrado de lado 2 con centro en el origen
%   correspondiente a la coordenada angular t
%   t debe pasarse en radianes
    
    r1 = 1./abs(cos(t));
    r2 = 1./abs(sin(t));
    r = r1; 
    ii = find(r2<r1);
    r(ii) = r2(ii);
    x=r.*cos(t);
    y=r.*sin(t);
    ii=find( abs(y)>1 );
    x(ii)=1./y(ii);
    y(ii)=sign(sin(t(ii)));

end

