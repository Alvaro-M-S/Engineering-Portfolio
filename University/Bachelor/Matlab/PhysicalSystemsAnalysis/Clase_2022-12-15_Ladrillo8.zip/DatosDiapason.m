function [f,E,nu,ro,a,L,b,r,L2,ln]=DatosDiapason(N,f,a,b);
% Devuelve los datos del diapas�n
%
% En principio no necesita datos de entrada (son opcionales), pero 
% se le pueden pasar los siguientes datos:
% f:   Frecuencia de resonancia en Hz
% a,b: Longitudes de los lados de la secci�n rectangular
% N:   N�mero aproximado de elementos finitos en cada secci�n

% Variables de salida:
%
% f:   Frecuencia de resonancia del diapas�n
% E:   M�dulo de Young del material del diapas�n
% nu:  Coeficiente de Poisson del material del diapas�n
% ro:  Densidad del material del diapas�n
% a,b: Lados de la secci�n rectangular axb del diapas�n
% L:   Longitud de la barra del diapas�n
% r:   Radio del arco que une ambas barras (para el diapas�n completo)
% L2:  Longitud del mango central (para el diapas�n completo)
% ln:  Longitud aprox. de los lados de los elementos finitos

% Devuelve los datos del diapas�n
if nargin<2
    f = 440;   % Frecuencia de resonancia del diapas�n
end

% Datos del material del diapas�n
E = 210e9;     % Modulo de Young (unidades SI, Pa), Acero
nu= 0.30;      % Coeficiente de Poisson
ro= 7.85e3;    % Densidad, en kg/m3, Acero

% Datos geom�tricos del diapas�n
if nargin<3
    a = 5e-3 ; % Ancho de las vigas vibrandes del diapas�n, en m
end
if nargin<4
    b = a;    
end;
r = max([a b]);;
L2= 2*r+r;

k = min([a b])/sqrt(12) ; % Radio de giro
% Frecuencia del diapason
% http://www.acs.psu.edu/drussell/Publications/Rossing-Russell-Fork.pdf
% http://en.wikipedia.org/wiki/Tuning_fork
% Aunque ambas referencias dan ecuaciones aparentemente distintas,
% en la pr�ctica son equivalentes.
L = sqrt(1.194^2*pi*k/8/f*sqrt(E/ro));

% lado aprox. del elemento finito
if nargin<1
    ln=min([a b])/3;
else
    ln=sqrt(a*b/N);
end