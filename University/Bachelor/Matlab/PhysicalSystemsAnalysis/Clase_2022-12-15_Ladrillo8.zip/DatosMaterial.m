function [E,nu,ro,sigma_adm]=DatosMaterial(Material)
% Devuelve las propiedades E,nu,ro,sigma_adm
% cuando se le pasa en la cadena de caracteres Material
% el nombre del material

% Datos del material
switch Material
    case 'ACERO'
        E = 210e9;        % Modulo de Young (unidades SI, Pa), Acero
        nu= 0.30;         % Coeficiente de Poisson
        ro= 7.85e3;       % Densidad, en kg/m3, Acero
        sigma_adm=200e6;  % Tensi�n m�xima admisible, en N/m2 (unidades SI)
    case 'POLIURETANO'
        E = 100e6;        % Modulo de Young (unidades SI, Pa)
        nu= 0.30;         % Coeficiente de Poisson
        ro= 35;           % Densidad, en kg/m3
        sigma_adm=15e6;   % Tensi�n m�xima admisible, en N/m2 (unidades SI)
    case 'ALUMINIO'
        E = 70e9;         % Modulo de Young (unidades SI, Pa)
        nu= 0.33;         % Coeficiente de Poisson
        ro= 2700;         % Densidad, en kg/m3
        sigma_adm=200e6;  % Tensi�n m�xima admisible, en N/m2 (unidades SI)
    case 'GOMA'
        E =  7e6;         % Modulo de Young (unidades SI, Pa)
        nu= 0.49;         % Coeficiente de Poisson
        ro= 3300;         % Densidad, en kg/m3
        sigma_adm=20e6;   % Tensi�n m�xima admisible, en N/m2 (unidades SI)
    case 'MADERA'
        E =  7e9;         % Modulo de Young (unidades SI, Pa)
        nu= 0.40;         % Coeficiente de Poisson
        ro=  500;         % Densidad, en kg/m3
        sigma_adm=15e6;   % Tensi�n m�xima admisible, en N/m2 (unidades SI)
    case 'PVC'
        E = 3.5e9;        % Modulo de Young (unidades SI, Pa)
        nu= 0.38;         % Coeficiente de Poisson
        ro=  140;         % Densidad, en kg/m3
        sigma_adm=50e6;   % Tensi�n m�xima admisible, en N/m2 (unidades SI)
end