% Mallado de un bloque de dos cilindros huecos

close all, clear all, fclose all;

% Dimensiones
L = 2 ; % Lado del cuadrado
D = 1 ; % Diámetro de los cilindros huecos
H = 0.3; % Altura del bloque
Amp=1 ;
N1= Amp*10; % Número de nodos por lado del cuadrado
Nc= Amp*3 ; % Elementos entre borde exterior e interior
Nz= Amp*3 ; % Número de elementos según Z


% Generación del contorno exterior (cuadrado)
[ x,y ] = Poligono( 4 , 4*N1 , pi/4 ) ;
figure
plot(x,y,'ro-'); grid on; axis equal

Amp=sqrt(2)*L/2;
x=x*Amp; y=y*Amp;
figure
plot(x,y,'ro-'); grid on; axis equal

x_ext=x; y_ext=y;

% Generación del contorno interior (circulo)
[ x,y ] = Poligono( 4*N1 , 4*N1 , pi/4 ) ;
Amp=1/2*D;
x=x*Amp; y=y*Amp;
hold on
plot(x,y,'bo-'); grid on; axis equal
x_int=x; y_int=y;


% Mallado en la corona 2D entre contornos exterior e interior
BordeInt=[ x_int y_int];
BordeExt=[ x_ext y_ext];
[nod2d,ele2d]=Corona2D(BordeInt,BordeExt,Nc);
Representa2DCuad(nod2d,ele2d);

% Paso a 3 dimensiones
[no1,el1]=Paso2Da3D(nod2d,ele2d,H,Nz);

% Redondeo a 1 um (1E-6 m)
Ndigit=6;
no1=round(no1,Ndigit);

no2=no1; el2=el1; % Duplicación

% Traslación de una distancia L según X
no2=[ no2(:,1)+L  no2(:,2) no2(:,3)];
no2=round(no2,Ndigit);

% Unión de (no1,el1) con (no2,el2) para conseguir (nodos,elem)
[nodos,elem]=UnirLadrillos(no1,el1,no2,el2);
nodos=round(nodos,Ndigit);

% Representación gráfica para ver si está bien
RepresentaLadrillos(nodos,elem)

% Grabación en un archivo EXCEL
Nn=length(nodos(:,1)); % Nº de nodos
Ne=length(elem(:,1));  % Nº de elementos

% Elección del Material y asignación de los valores
% de la densidad (ro), módulo de Young (E)
% y coeficiente de Poisson
[E,nu,ro]=DatosMaterial('PVC');

% Nodos Fijos
Fijos=zeros(Nn,3); % Todos los nodos libres
ii=find( nodos(:,1)==(-L/2)  ); % x=-L/2
Fijos(ii,:)=1;     % Nodos fijos
ii=find( nodos(:,1)==3*L/2 ); % x=3L/2
Fijos(ii,:)=1;     % Nodos fijos

m  = zeros(Nn,1) ; % Masas concentradas en los nodos (a cero)
Fo = zeros(Nn,3) ; % Fuerzas estáticas (según X,Y,Z)
Fd = zeros(Nn,3) ; % Fuerzas dinámicas (según X,Y,Z)

% Búsqueda del punto A (L/2,-L/2,0)
ii = find( (nodos(:,1)==(L/2))&(nodos(:,2)==(-L/2))&(nodos(:,3)==0));

Fo(ii,2)=-1000; % Fuerda estática
Fd(ii,3)= -100; % Fuerda dinámica

% Frecuencias de las fuerzas dinámicas
f = ones(Nn,1)*50; % 50 Hz

ceros_6 = zeros(Nn,6);
unos     = ones(Ne,1);
DATA_nodos=[ [1:Nn]' nodos Fijos m Fo Fd f ceros_6 ];
DATA_elem =[ [1:Ne]' elem  ro*unos E*unos nu*unos];

xls='Mallado_Cilindros.xls';
system( ['copy Plantilla.xls ' xls]);

xlswrite(xls,DATA_nodos,'nodos','A4');
xlswrite(xls,DATA_elem ,'elem' ,'A2');

disp([ 'El mallado se ha guardado en el archivo ' xls]);


