% Mallado de un paralelepídedo de longitudes A,B,C

close all, clear all, fclose all;

A=2; B=3; C=5; % Número de elementos según X,Y,Z

nnodo = @(i,j,k)  1 + i + j*(A+1) + k*(A+1)*(B+1) ;

% Cálculo de las coordenadas de los nodos
for i=0:A , for j=0:B , for k=0:C 
    n = nnodo(i,j,k);
    x(n)=i;
    y(n)=j;
    z(n)=k;
end, end, end
nodos=[ x(:) y(:) z(:) ];

plot3(x,y,z,'ro');
grid on
axis equal

% Determinar la matriz de conectividad elem
for i=0:(A-1), for j=0:(B-1), for k=0:(C-1)
    e = 1 + i + j*A + k*A*B ;

    a1 = nnodo( i+1,j,k) ;
    b1 = nnodo( i,j,k) ;
    c1 = nnodo( i,j+1,k) ;
    d1 = nnodo( i+1,j+1,k) ;

    a2 = nnodo( i+1,j,k+1) ;
    b2 = nnodo( i,j,k+1) ;
    c2 = nnodo( i,j+1,k+1) ;
    d2 = nnodo( i+1,j+1,k+1) ;

    elem(e,:)=[ a1,b1,c1,d1 , a2,b2,c2,d2 ];
end, end, end

RepresentaLadrillos(nodos,elem);

[CarasExt,BarrasExt,NodosExt,Caras,Barras,TN]=CarasBarras(elem);
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt )

Nn=length(nodos(:,1)); % Nº de nodos
Ne=length(elem(:,1));  % Nº de elementos

ceros_17 = zeros(Nn,17);
DATA_nodos=[ [1:Nn]' nodos ceros_17 ];
DATA_elem =[ [1:Ne]' elem  zeros(Ne,3)];

xls='Mallado_Ej_0.xls';
system( ['copy Plantilla.xls ' xls]);

xlswrite(xls,DATA_nodos,'nodos','A4');
xlswrite(xls,DATA_elem ,'elem' ,'A2');

disp([ 'El mallado se ha guardado en el archivo ' xls]);
