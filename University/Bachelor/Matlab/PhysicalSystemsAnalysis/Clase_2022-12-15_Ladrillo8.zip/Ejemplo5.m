% Prueba de la rutina Corona2D y Representa2DCuad
% Genera la malla de un tubo circular

close all, clear all, fclose all;

N  = 10;      % N�mero de elementos por cuadrante (90�)
D  =  1;      % Di�metro exterior
e  =  0.1*D;  % Espesor del tubo
Nc =  3;      % N�mero de elementos entre coronas

% Angulo
t = 2*pi*[0:1/(4*N):1]'; t=t(2:end);
% Coordenadas Borde Interior
BordeInt=[ (D/2-e)*cos(t) (D/2-e)*sin(t) ];
% Coordenadas Borde exterior
BordeExt=[   D/2*cos(t)     D/2*sin(t)   ];
        
figure
plot(BordeInt(:,1),BordeInt(:,2),'ro-'); hold on % Borde interior
plot(BordeExt(:,1),BordeExt(:,2),'go-');         % Borde exterior

axis equal, grid on

% Mallado
[nod2D,ele2D]=Corona2D(BordeInt,BordeExt,Nc);

% Representaci�n gr�fica
Representa2DCuad(nod2D,ele2D);

% Paso a 3D ( se convierte la malla 2D en una malla 3D )
[nodos,elem]=Paso2Da3D(nod2D,ele2D,D*3,5*Nc);
[CarasExt,BarrasExt,NodosExt,Caras,Barras,TN]=CarasBarras(elem);

% Representaci�n gr�fica 
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)

% Fin del mallado




Nn=length(nodos(:,1));
Ne=length(elem(:,1));

% Aplicaci�n de las condiciones de contorno
% (son fijos los nodos situados en Z=0)
Fijos=0*nodos; % Todos los nodos libres
ii=find(nodos(:,3)==0);
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen z=0

Vzo=0*nodos(:,1); % Todas las velocidades de los nodos en t=0 son nulas

% Escritura de la informaci�n en los archivos

% Archivo Ejemplo5.nodos.txt
f=fopen('Ejemplo5.nodos.txt','w');
fprintf(f,'%%                                      Nodos                   Fuerzas Estaticas              Fuerzas Dinamicas                              Condiciones Iniciales       \r\n');
fprintf(f,'%%                                      Fijos                                                                                            Posici�n                Velocidad    \r\n');
fprintf(f,'%% N�Nodo     X(m)    Y(m)    Z(m)      X Y Z     m(kg)      Fxo(N)   Fyo(N)   Fzo(N)        Fx(N)    Fy(N)    Fz(N)     f(Hz)     dXo(m) dYo(m) dZo(m)  Vxo(m/s) Vyo(m/s) Vzo(m/s)  \r\n');

data= [ [1:Nn]' nodos Fijos zeros(Nn,13) Vzo ];
fprintf(f,'  %4.0f     %+7.3f %+7.3f %+7.3f     %1.0f %1.0f %1.0f    %6.3f    %+8.3f %+8.3f %+8.3f     %+8.3f %+8.3f %+8.3f   %6.1f     %+6.3f %+6.3f %+6.3f  %+8.3f %+8.3f %+8.3f \r\n',data');
fclose(f);

% Archivo Ejemplo5.elem.txt
f=fopen('Ejemplo5.elem.txt','w');
fprintf(f,'%% N�Elem      a1   b1   c1   d1   a2   b2   c2   d2   ro(kg/m3)   E(PA)   nu \r\n');


% Datos del material 
Material='ALUMINIO';
switch Material
    case 'ACERO'
        E = 210e9;    % Modulo de Young (unidades SI, Pa), Acero
        nu= 0.30;     % Coeficiente de Poisson
        ro= 7.85e3;   % Densidad, en kg/m3, Acero
    case 'POLIURETANO'
        E = 100e6;    % Modulo de Young (unidades SI, Pa)
        nu= 0.30;     % Coeficiente de Poisson
        ro= 35;       % Densidad, en kg/m3
    case 'ALUMINIO'
        E = 70e9;     % Modulo de Young (unidades SI, Pa)
        nu= 0.33;     % Coeficiente de Poisson
        ro= 2700;     % Densidad, en kg/m3
end

data=[ [1:Ne]' elem ro*ones(Ne,1) E*ones(Ne,1) nu*ones(Ne,1) ];
    

fprintf(f,'  %4.0f      %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f   %6.1f %10g %4.2f \r\n',data');
fclose(f);



