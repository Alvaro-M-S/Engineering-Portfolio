% Malladado de un semiarco

close all, clear all, fclose all;

R1 = 10 ; % Radio interior
R2 = 12 ; % Radio exterior
H  = 15 ; % Altura

Na = 3  ; % Número de elementos según el radio
Nb = 22 ; % Número de elementos según la circunferencia
Nz = 15 ; % Número de elementos según el eje z

% Generación de la malla rectangular
[nodos2D,elem2D]=Rectangulo2D(R2-R1,pi/2,Na,Nb);
nodos2D(:,1)=nodos2D(:,1)+R1; % Traslación según la primera coordenada
Representa2DCuad(nodos2D,elem2D);
axis equal

% Paso a cartesianas
ro   =nodos2D(:,1);
theta=nodos2D(:,2);
nodos2D=[  ro.*cos(theta)  ro.*sin(theta) ];
Representa2DCuad(nodos2D,elem2D);
axis equal

% Paso a 3D
[nodos,elem]=Paso2Da3D(nodos2D,elem2D,H,Nz);
RepresentaLadrillos(nodos,elem)