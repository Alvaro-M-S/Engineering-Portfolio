% Prueba de la rutina Corona2D y Representa2DCuad

close all, clear all, fclose all;

N  = 10;      % N�mero de elementos por cuadrante
a  =  1;      % Lado del cuadrado exterior
D  =  0.8*a;  % Di�metro del c�rculo interior
Nc =  3;      % N�mero de elmentos entre coronas

% Borde interior
% Angulo
t = pi/4 + 2*pi*[0:1/(4*N):1]'; t=t(2:end);
% Coordenadas
BordeInt=[ D/2*cos(t) D/2*sin(t) ];

% Borde exterior
BordeExt= [ -a*[1:N]'/N+a/2   a/2*ones(N,1)  ; ...
            -a/2*ones(N,1)    a/2-a*[1:N]'/N ; ... 
             a*[1:N]'/N-a/2  -a/2*ones(N,1)  ; ...
             a/2*ones(N,1)   -a/2+a*[1:N]'/N ];
        
figure
plot(BordeInt(:,1),BordeInt(:,2),'ro-'); hold on % Borde interior
plot(BordeExt(:,1),BordeExt(:,2),'go-');         % Borde exterior

axis equal, grid on

% Mallado
[nod2D,ele2D]=Corona2D(BordeInt,BordeExt,Nc);

% Representaci�n gr�fica
Representa2DCuad(nod2D,ele2D);

% Paso a 3D ( se convierte la malla 2D en una malla 3D )
[nodos,elem]=Paso2Da3D(nod2D,ele2D,D-a,Nc);
[CarasExt,BarrasExt,NodosExt,Caras,Barras,TN]=CarasBarras(elem);

% Representaci�n gr�fica 
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)


nod1=nodos; ele1=elem;
nodos=[]; elem=[];
for i=1:2,for j=1:4;
        dx=(j-1)*a; dy=(i-1)*a;
        nodi = [ nod1(:,1)+dx nod1(:,2)+dy nod1(:,3) ];
        [nodos,elem]=UnirLadrillos(nodos,elem,nodi,ele1);
        [n2,e2]=UnirLadrillos(nod1,ele1,nodi,ele1);
        
        % Representaci�n gr�fica del proceso de uni�n
        % RepresentaLadrillos(nodos,elem);
        % title(sprintf('Fase i=%1.0f  j=%1.0f',i,j));
        % nada=input('Pulsar [Intro] para continuar...','s');
end,end
[CarasExt,BarrasExt,NodosExt,Caras,Barras,TN]=CarasBarras(elem);

% Representaci�n gr�fica 
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)



Nn=length(nodos(:,1));
Ne=length(elem(:,1));

% Aplicaci�n de las condiciones de contorno
% (realmente no hay ning�n nodo fijo)
Fijos=0*nodos; % Todos los nodos libres;

Vzo=0*nodos(:,1); % Todas las velocidades de los nodos en t=0 son nulas

% Escritura de la informaci�n en los archivos

% Archivo Ejemplo3.nodos.txt
f=fopen('Ejemplo3.nodos.txt','w');
fprintf(f,'%%                                      Nodos                   Fuerzas Estaticas              Fuerzas Dinamicas                              Condiciones Iniciales       \r\n');
fprintf(f,'%%                                      Fijos                                                                                            Posici�n                Velocidad    \r\n');
fprintf(f,'%% N�Nodo     X(m)    Y(m)    Z(m)      X Y Z     m(kg)      Fxo(N)   Fyo(N)   Fzo(N)        Fx(N)    Fy(N)    Fz(N)     f(Hz)     dXo(m) dYo(m) dZo(m)  Vxo(m/s) Vyo(m/s) Vzo(m/s)  \r\n');

data= [ [1:Nn]' nodos Fijos zeros(Nn,13) Vzo ];
fprintf(f,'  %4.0f     %+7.3f %+7.3f %+7.3f     %1.0f %1.0f %1.0f    %6.3f    %+8.3f %+8.3f %+8.3f     %+8.3f %+8.3f %+8.3f   %6.1f     %+6.3f %+6.3f %+6.3f  %+8.3f %+8.3f %+8.3f \r\n',data');
fclose(f);

% Archivo Ejemplo3.elem.txt
f=fopen('Ejemplo3.elem.txt','w');
fprintf(f,'%% N�Elem      a1   b1   c1   d1   a2   b2   c2   d2   ro(kg/m3)   E(PA)   nu \r\n');


% Datos del material 
Material='ALUMINIO';
switch Material
    case 'ACERO'
        E = 210e9;    % Modulo de Young (unidades SI, Pa), Acero
        nu= 0.30;     % Coeficiente de Poisson
        ro= 7.85e3;   % Densidad, en kg/m3, Acero
    case 'POLIURETANO'
        E = 100e6;    % Modulo de Young (unidades SI, Pa)
        nu= 0.30;     % Coeficiente de Poisson
        ro= 35;       % Densidad, en kg/m3
    case 'ALUMINIO'
        E = 70e9;     % Modulo de Young (unidades SI, Pa)
        nu= 0.33;     % Coeficiente de Poisson
        ro= 2700;     % Densidad, en kg/m3
end

data=[ [1:Ne]' elem ro*ones(Ne,1) E*ones(Ne,1) nu*ones(Ne,1) ];
    

fprintf(f,'  %4.0f      %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f   %6.1f %10g %4.2f \r\n',data');
fclose(f);



