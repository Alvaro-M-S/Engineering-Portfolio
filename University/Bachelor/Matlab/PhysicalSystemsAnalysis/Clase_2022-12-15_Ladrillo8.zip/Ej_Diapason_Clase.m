% Problema del Diapasón (clase)
close all, clear all, fclose all;

tic
N=5; % Número de elementos en cada lado de la sección
% Carga de los datos del Diapasón (440 Hz)
[f,E,nu,ro,a,L,b]=DatosDiapason(N);
% f:   Frecuencia de resonancia del diapasón
% E:   Módulo de Young del material del diapasón
% nu:  Coeficiente de Poisson del material del diapasón
% ro:  Densidad del material del diapasón
% a,b: Lados de la sección rectangular axb del diapasón
% L:   Longitud de la barra del diapasón

A=N; % Nº elementos en dirección X
B=N; % Nº elementos en dirección Y
% Nº elementos en dirección Z
le = a/A ; 
C  =  round(L/le) ;

[ nodos,elem ] = PilarLadrillo(a,b,L,A,B,C);

RepresentaLadrillos(nodos,elem);

Nn=length(nodos(:,1)); % Nº de nodos
Ne=length(elem(:,1));  % Nº de elementos

% Nodos Fijos
Fijos=zeros(Nn,3); % Todos los nodos libres
ii=find( nodos(:,3)==0 ); 
Fijos(ii,:)=1;     % Nodos fijos

ceros_14 = zeros(Nn,14);
unos     = ones(Ne,1);
DATA_nodos=[ [1:Nn]' nodos Fijos ceros_14 ];
DATA_elem =[ [1:Ne]' elem  ro*unos E*unos nu*unos];

% Busqueda del punto con x=y=0 y z=L
ii = find( (nodos(:,1)==0)&(nodos(:,2)==0)&(nodos(:,3)==L) );

% Aplicación en el nodo anterior de una fuerza Fx=100 N
Fx = 100 ; 
DATA_nodos(ii,9)=Fx;

xls='Mallado_Ej_Diapason.xls';
system( ['copy Plantilla.xls ' xls]);

xlswrite(xls,DATA_nodos,'nodos','A4');
xlswrite(xls,DATA_elem ,'elem' ,'A2');

disp([ 'El mallado se ha guardado en el archivo ' xls]);

NombreArchivo=xls; % Se le pasa a LecturaEnsamblajeXLS
                   % en NombreArchivo el archivo XLS a leer
LecturaEnsamblajeXLS;

Problema='Dinamico';
switch Problema
    case 'Estatico'
        q = K\fo ; % Se resuelve K*q = fo
        figure
        RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt,q );
    case 'Dinamico'
        lambda=eigs(M\K,30,'smallestabs'); 
        w=sqrt(lambda); 
        f_reson=real( w/(2*pi) );
        disp( sprintf('La frecuencia #1 es %6.2f Hz',f_reson(1) ));
        figure
        plot(f_reson,'bo'); grid on
        toc
end