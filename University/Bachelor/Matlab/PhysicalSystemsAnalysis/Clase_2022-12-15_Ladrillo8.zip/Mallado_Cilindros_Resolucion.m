% Resoloción del problema cuyo mallado
% ha sido generado por Mallado_Cilindros.m
% y almacenado en      Mallado_Cilindros.xls

clear all, close all, fclose all;

NombreArchivo='Mallado_Cilindros.xls';

LecturaEnsamblajeXLS;

Alternativa='Reg.Permanente';
switch Alternativa
    case 'Estatica'
        q = K\fo ;
        RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt,q );
    case 'ModosNormales'
        % eig no funciona para matrices dispersas
        [V,D]=eigs(M\K,6,'smallestabs');
        i=1; % Modo normal a representar
        fi = sqrt( D(i,i) )/(2*pi) 
        vi = V(:,i);
        RepresentaLadrillosModo(nodos,CarasExt,vi,'Modo_i.gif')
    case 'Reg.Permanente'
        wd=wd(1);
        v = ( M*wd^2 + K ) \ fd ;
        RepresentaLadrillosModo(nodos,CarasExt,v,'Reg_Per.gif')
end