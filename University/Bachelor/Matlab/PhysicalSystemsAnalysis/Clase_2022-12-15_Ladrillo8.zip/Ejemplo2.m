% Ejemplo 2: Modos normales en una placa cuadrada de lado L y espesor e

close all, clear all

Lx  = 2 ;     % Longitud del rect�ngulo seg�n X, en metros
Ly  = 3 ;     % Longitud del rect�ngulo seg�n Y, en metros
esp = 0.2;    % Espesor de la placa en metros
esp = 0.5;    % Espesor de la placa en metros


% Datos del material 
Material='POLIURETANO';
switch Material
    case 'ACERO'
        E = 210e9;    % Modulo de Young (unidades SI, Pa), Acero
        nu= 0.30;     % Coeficiente de Poisson
        ro= 7.85e3;   % Densidad, en kg/m3, Acero
    case 'POLIURETANO'
        E = 100e6;    % Modulo de Young (unidades SI, Pa)
        nu= 0.30;     % Coeficiente de Poisson
        ro= 35;       % Densidad, en kg/m3
    case 'ALUMINIO'
        E = 70e9;     % Modulo de Young (unidades SI, Pa)
        nu= 0.33;     % Coeficiente de Poisson
        ro= 2700;     % Densidad, en kg/m3
end

% Nex = 20 ;    % N�mero de elementos seg�n X
% Ney = 30 ;    % N�mero de elementos seg�n Y
% Nez =  2 ;    % N�mero de elementos seg�n Z

Nex =  7 ;    % N�mero de elementos seg�n X
Ney =  5 ;    % N�mero de elementos seg�n Y
Nez =  3 ;    % N�mero de elementos seg�n Z

Nnx = Nex+1 ; % N�meros de elementos seg�n los ejes X,Y,Z
Nny = Ney+1 ;
Nnz = Nez+1 ;

[J,I]=meshgrid(1+[0:Nex],1+[0:Ney]);  % �ndices dobles de los nodos

X=(J-1)*Lx/Nex;   % Coordenadas de los nodos
Y=(I-1)*Ly/Ney;   % Coordenadas de los nodos

nodos2D=[ X(:) Y(:) ];
elem2D=[];
for e=1:Ney
    for f=1:Nex
        i=e; j=f;
        a1 = (j  -1)*Nny+i  ;
        a2 = (j+1-1)*Nny+i  ;
        a3 = (j+1-1)*Nny+i+1;
        a4 = (j  -1)*Nny+i+1;
        elem2D=[elem2D ; a1 a2 a3 a4 ];
    end
end

% Representaci�n de la malla 2D
Representa2DCuad(nodos2D,elem2D);

% Se convierte en 3D la malla 2D
[nodos,elem]=Paso2Da3D(nodos2D,elem2D,esp,Nez);

% Matrices adicionales para representar la superficie exterior del sistema:
%   CarasExt:  Matriz de conectividad de las caras externas
%   BarrasExt: Matriz de conectividad de las aristas externas de los
%              elementos
%   NodosExt:  Vector con la lista de nodos externos
%   caras:     Matriz de conectividad de todas las caras (internas y externas)
%   barras:    Matriz de conectividad de todas las barras (internas y externas)
[CarasExt,BarrasExt,NodosExt,caras,barras]=CarasBarras(elem);

% Representaci�n del sistema tipo "wire-frame"
Representa3Dbarras(nodos,barras), 

% Representaci�n de la superficie externa del sistema
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)
hfigura=gcf;

% Condiciones de contorno (nodos fijos)
Fijos=0*nodos;   % Todos los nodos son libres en este momento
ii=find(nodos(:,1)==0);  Fijos(ii,:)=1; % Nodos situados en el plano X=0,  se considerar�n fijos
ii=find(nodos(:,1)==Lx); Fijos(ii,:)=1; % Nodos situados en el plano X=Lx, se considerar�n fijos
ii=find(nodos(:,2)==0);  Fijos(ii,:)=1; % Nodos situados en el plano Y=0,  se considerar�n fijos
ii=find(nodos(:,2)==Ly); Fijos(ii,:)=1; % Nodos situados en el plano Y=Ly, se considerar�n fijos

% Representaci�n de los nodos fijos
ii=find( prod(Fijos,2)==1 );
figure(hfigura), hold on
plot3(nodos(ii,1),nodos(ii,2),nodos(ii,3),'ro');






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                    %%%
%%% ENSAMBLAJE                                                         %%%
%%%                                                                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Nn,nada] = size(nodos);  % Numero de nodos
[Ne,nada] = size(elem);   % Numero de elementos

N  = 3*Nn;       % N�mero de grados de libertad
    
                          %%%%%%%%%%%%%%
MatricesDispersas=true;   %%% OPCION %%%
                          %%%%%%%%%%%%%%
if MatricesDispersas
    K = sparse(N,N); % Inicializaci�n de la matriz de rigidez global
                     % como matriz dispersa
    M = sparse(N,N); % Inicializaci�n de la matriz de masa global 
                     % como matriz dispersa
else
    K  = zeros(N,N); % Inicializaci�n de la matriz de rigidez global
    M  = zeros(N,N); % Inicializaci�n de la matriz de masa global
end
fo = zeros(N,1); % Vector de fuerzas nodales est�ticas


for e=1:Ne % Bucle a lo largo de todos los elementos
           % Se ensamblan las matrices elementales de rigidez y masa
   
    % Coordenadas de los nodos del elemento
    ne=nodos(elem(e,:),:);
    
    % Matrices de Rigidez (Ke) y Masa (Me) elementales 
    % junto con las fuerzas gravitatorias
    [Ke,Me,Fge]=Ladrillo8(ne,ro,E,nu);
        
    % Numeraci�n global de grados de libertad del elemento
    ii=[];
    for k=1:length(elem(e,:))
        ii=[ ii    3*(elem(e,k)-1)+[1 2 3] ];
    end
    
    % Ensamblaje de la matriz de rigidez (suma)
    K(ii,ii) = K(ii,ii) + Ke;
    % Ensamblaje de la matriz de masa (suma)
    M(ii,ii) = M(ii,ii) + Me;
    % Ensamblaje del vector de fuerzas estaticas (suma)
    fo(ii) = fo(ii) + Fge ;
    
end % Fin del bucle a lo largo de las barras



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                    %%%
%%% APLICACI�N DE LAS CONDICIONES DE CONTORNO                          %%%
%%%                                                                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Para la aplicaci�n de las condiciones de contorno se va a suponer
% que los cimientos poseen una constante el�stica muy grande (kinf),
% pero no infinita.
%
% � Como se fija el valor de kinf ?
% Se busca el mayor valor absoluto de las componentes Kij de la matriz
% de rigidez y se multiplica ese valor por un n�mero grande (1000 en este
% caso)
kmax=max(abs(K(:)));
kinf=1000*kmax;

for i=1:Nn % Bucle a lo largo de todos los nodos
    % � Est� fijo el nodo seg�n eje X ?
    if Fijos(i,1)==1
        j=3*(i-1)+1;         % Idenficador del grado de libertad
                             % en numeraci�n globlal
        K(j,j)=K(j,j)+kinf;  % Se ensambla el apoyo "el�stico"
    end
    % � Est� fijo el nodo seg�n eje Y ?
    if Fijos(i,2)==1
        j=3*(i-1)+2;         % Idenficador del grado de libertad
                             % en numeraci�n globlal
        K(j,j)=K(j,j)+kinf;  % Se ensambla el apoyo "el�stico"
    end
    % � Est� fijo el nodo seg�n eje Z ?
    if Fijos(i,3)==1
        j=3*(i-1)+3;         % Idenficador del grado de libertad
                             % en numeraci�n globlal
        K(j,j)=K(j,j)+kinf;  % Se ensambla el apoyo "el�stico"
    end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Resoluci�n del problema de valores y vectores propios generalizado  %%%
%%% en ausencia de rozamiento                                           %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

           %%%%%%%%%%%%%%
Opcion=3;  %%% OPCION %%%
           %%%%%%%%%%%%%%
           
if MatricesDispersas, Opcion=3; end
switch Opcion
    % Opci�n 1: la alternativa habitual
    case 1, tic, [V,D]=eig(K,M); toc   % Es es la alternativa usual, pero para 
                              % el tama�o de las matrices implicadas
                              % puede suponer un tiempo excesivamente largo
                              % de c�lculo
                              
    % Opci�n 2: Para matrices M de masas concentradas.
    % La matriz M es, en este caso, una matriz de masas concentradas
    % (Lumped Mass Matrix). Es decir, es una matriz diagonal
    % Por ello es muy facil obtener su inversa y multiplicarla por K
    case 2, tic, [V,D]=eig(M\K); toc   

    % Opci�n 3: Para matrices M de masas concentradas, cuando K y M son
    %           tambi�n matrices disperas
    % La matriz M es, en este caso, una matriz de masas concentradas
    % (Lumped Mass Matrix). Es decir, es una matriz diagonal
    % Por ello es muy facil obtener su inversa y multiplicarla por K
    case 3, tic, [V,D]=eigs(K,M, 1,'sm'); toc  
end                           

% Frecuencias naturales 
w=sqrt(diag(D)); f=w/2/pi;

% Primera Frencuencia natural
[fmin,imin]=min(f);

disp(sprintf('Primera Frecuencia Natural = %6.2f Hz',fmin));

% Representaci�n del primer modo normal
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt,V(:,imin) )


