% Discretiza la viga de un diapas�n (440 Hz) de secci�n cuadrada
% utilizando elementos finitos tipo LADRILLO de 8 nodos


close all, clear all, fclose all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                    %%%
%%% DATOS DEL DIAPAS�N (Una sola barra)                                %%%
%%%                                                                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Se cargan los datos del diapas�n
[f,E,nu,ro,a,L,b,r,L2,ln]=DatosDiapason(3^2);
% f:   Frecuencia de resonancia del diapas�n
% E:   M�dulo de Young del material del diapas�n
% nu:  Coeficiente de Poisson del material del diapas�n
% ro:  Densidad del material del diapas�n
% a,b: Lados de la secci�n rectangular axb del diapas�n
% L:   Longitud de la barra del diapas�n
% r:   Radio del arco que une ambas barras (para el diapas�n completo)
% L2:  Longitud del mango central (para el diapas�n completo)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                    %%%
%%% DISCRETIZACI�N DEL PROBLEMA (GEOMETR�A)                            %%%
%%%                                                                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Matrices con los datos del problema:
%    nodos : Matriz nodos de dimensi�n Nnx3, con las coordenas X,Y,Z 
%            del nodo i-�simo en la fila i.
%    elem  : Matriz de conectividad de los elementos tipo ladrillo (8-nodos)
                
                %%%%%%%%%%%%%%
Opcion=1;       %%% OPCION %%%
switch Opcion   %%%%%%%%%%%%%%
    
    % Opcion 1: Usando PilarLadrillo, la matriz K tiene un ancho de banda
    %           estrecho
    case 1, [nodos,elem]=PilarLadrillo(a,a,L,round(a/ln),round(a/ln),round(L/ln));
        
    % Opcion 1: Usando PilarLadrillo2, la matriz K tiene un ancho de banda
    %           grande
    case 1, [nodos,elem]=PilarLadrillo2(a,a,L,round(a/ln),round(a/ln),round(L/ln));
end

% Matrices adicionales para representar la superficie exterior del sistema:
%   CarasExt:  Matriz de conectividad de las caras externas
%   BarrasExt: Matriz de conectividad de las aristas externas de los
%              elementos
%   NodosExt:  Vector con la lista de nodos externos
%   caras:     Matriz de conectividad de todas las caras (internas y externas)
%   barras:    Matriz de conectividad de todas las barras (internas y externas)
[CarasExt,BarrasExt,NodosExt,caras,barras]=CarasBarras(elem);

% Representaci�n del sistema tipo "wire-frame"
Representa3Dbarras(nodos,barras)

% Representaci�n de la superficie externa del sistema
% RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)

% Condiciones de contorno (nodos fijos)
Fijos=0*nodos;          % Todos los nodos son libres en este momento
ii=find(nodos(:,3)==0); % Nodos situados en el plano Z=0, se considerar�n fijos
Fijos(ii,:)=1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                    %%%
%%% ENSAMBLAJE                                                         %%%
%%%                                                                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Nn,nada] = size(nodos);  % Numero de nodos
[Ne,nada] = size(elem);   % Numero de elementos

N  = 3*Nn;       % N�mero de grados de libertad
    
                          %%%%%%%%%%%%%%
MatricesDispersas=true;   %%% OPCION %%%
                          %%%%%%%%%%%%%%
if MatricesDispersas
    K = sparse(N,N); % Inicializaci�n de la matriz de rigidez global
                     % como matriz dispersa
    M = sparse(N,N); % Inicializaci�n de la matriz de masa global 
                     % como matriz dispersa
else
    K  = zeros(N,N); % Inicializaci�n de la matriz de rigidez global
    M  = zeros(N,N); % Inicializaci�n de la matriz de masa global
end
fo = zeros(N,1); % Vector de fuerzas nodales est�ticas


for e=1:Ne % Bucle a lo largo de todos los elementos
           % Se ensamblan las matrices elementales de rigidez y masa
   
    % Coordenadas de los nodos del elemento
    ne=nodos(elem(e,:),:);
    
    % Matrices de Rigidez (Ke) y Masa (Me) elementales 
    % junto con las fuerzas gravitatorias
    [Ke,Me,Fge]=Ladrillo8(ne,ro,E,nu);
        
    % Numeraci�n global de grados de libertad del elemento
    ii=[];
    for k=1:length(elem(e,:))
        ii=[ ii    3*(elem(e,k)-1)+[1 2 3] ];
    end
    
    % Ensamblaje de la matriz de rigidez (suma)
    K(ii,ii) = K(ii,ii) + Ke;
    % Ensamblaje de la matriz de masa (suma)
    M(ii,ii) = M(ii,ii) + Me;
    % Ensamblaje del vector de fuerzas estaticas (suma)
    fo(ii) = fo(ii) + Fge ;
    
end % Fin del bucle a lo largo de las barras



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                    %%%
%%% APLICACI�N DE LAS CONDICIONES DE CONTORNO                          %%%
%%%                                                                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Para la aplicaci�n de las condiciones de contorno se va a suponer
% que los cimientos poseen una constante el�stica muy grande (kinf),
% pero no infinita.
%
% � Como se fija el valor de kinf ?
% Se busca el mayor valor absoluto de las componentes Kij de la matriz
% de rigidez y se multiplica ese valor por un n�mero grande (1000 en este
% caso)
kmax=max(abs(K(:)));
kinf=1000*kmax;

for i=1:Nn % Bucle a lo largo de todos los nodos
    % � Est� fijo el nodo seg�n eje X ?
    if Fijos(i,1)==1
        j=3*(i-1)+1;         % Idenficador del grado de libertad
                             % en numeraci�n globlal
        K(j,j)=K(j,j)+kinf;  % Se ensambla el apoyo "el�stico"
    end
    % � Est� fijo el nodo seg�n eje Y ?
    if Fijos(i,2)==1
        j=3*(i-1)+2;         % Idenficador del grado de libertad
                             % en numeraci�n globlal
        K(j,j)=K(j,j)+kinf;  % Se ensambla el apoyo "el�stico"
    end
    % � Est� fijo el nodo seg�n eje Z ?
    if Fijos(i,3)==1
        j=3*(i-1)+3;         % Idenficador del grado de libertad
                             % en numeraci�n globlal
        K(j,j)=K(j,j)+kinf;  % Se ensambla el apoyo "el�stico"
    end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Resoluci�n del problema de valores y vectores propios generalizado  %%%
%%% en ausencia de rozamiento                                           %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

           %%%%%%%%%%%%%%
Opcion=3;  %%% OPCION %%%
           %%%%%%%%%%%%%%
           
if MatricesDispersas, Opcion=3; end
switch Opcion
    % Opci�n 1: la alternativa habitual
    case 1, tic, [V,D]=eig(K,M); toc   % Es es la alternativa usual, pero para 
                              % el tama�o de las matrices implicadas
                              % puede suponer un tiempo excesivamente largo
                              % de c�lculo:
                              % 450 segundos en un Core i5 @ 3.1 GHz
                              
    % Opci�n 2: Para matrices M de masas concentradas.
    % La matriz M es, en este caso, una matriz de masas concentradas
    % (Lumped Mass Matrix). Es decir, es una matriz diagonal
    % Por ello es muy facil obtener su inversa y multiplicarla por K
    case 2, tic, [V,D]=eig(M\K); toc   % 22 segundos en un Core i5 @ 3.1 GHz (4 n�cleos)
                                       % 60 segundos en Phenom II X4 @ 3.0 GHz (4 n�cleos)

    % Opci�n 3: Para matrices M de masas concentradas, cuando K y M son
    %           tambi�n matrices disperas
    % La matriz M es, en este caso, una matriz de masas concentradas
    % (Lumped Mass Matrix). Es decir, es una matriz diagonal
    % Por ello es muy facil obtener su inversa y multiplicarla por K
    case 3, tic, [V,D]=eigs(K,M, 1,'sm'); toc  % 1 segundo en un Core i5 @ 3.1 GHz (50 modos)
                                               % (0.34 seg con matriz K optima)
end                           

% Frecuencias naturales 
w=sqrt(diag(D)); f=w/2/pi;

% Primera Frencuencia natural
[fmin,imin]=min(f);

disp(sprintf('Primera Frecuencia Natural = %6.2f Hz',fmin));

% Representaci�n del primer modo normal
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt,V(:,imin) )

