% Tipos de Materiales del Problema del Chip
Material=[
% Tipo   k      ro   Cp  (todo en unidades SI)   
   1   0.026   1.22   1     ; ... % Aire
   2    389    8960  385    ; ... % Cobre
   3    160    2700  910    ; ... % Aluminio
   4    148    2330  710    ; ... % Silicio
   5     12    3800  750    ; ... % Al�mina
%
% Unidades SI:
%  k  : conductividad t�rmica , W/(m*K)
%  ro : densidad, kg/m3
%  Cp : calor espec�fico, en J/(K*kg)
