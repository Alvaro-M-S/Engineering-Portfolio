% Programa para la resoluci�n de problemas de TRANSMISI�N DEL CALOR 2D
% por el M�todo de los Elementos Finitos 
% (Elementos Triangulares)
%
% Resoluci�n del ejercicio Ladrillo.xls :
% Ladrillo con la cara derecha e izquierda a temperaturas conocidas

close all, clear all, fclose all;

arc='Ladrillo.xls';       % Nombre del archivo EXCEL que contiene la definici�n del problema
                          % (Se supone que se ha generado con EasyMesh.m)
                  
% Lecturas de las distintas pesta�as del archivo EXCEL
% ��� OJO !!! Se supone que los archivos EXCEL tienen un maximo de 65536 filas


% Tipos de Materiales
Material=[
% Tipo   k (conductividad t�rmica en W/(m*K) )   
   1    1.28           ; ...  % Arcilla
   2    0.026          ; ...  % Aire
   3    0.488          ; ...  % Yeso
   4    0.026e-3    ]  ;      % "Superaislante"
   
   
% Lecturas de las pesta�as 'n', 'e' y 's' del archivo EXCEL
Nodos =xlsread(arc,'n','A29:D65536');   % Pesta�a 'n' (NODOS)
Elem  =xlsread(arc,'e','A29:M65536');   % Pesta�a 'e' (ELEMENTOS)
Segmen=xlsread(arc,'s','A29:F65536');   % Pesta�a 's' (SEGMENTOS)

% Nota: las coordenadas x,y en el archivo .xls est�n en mm
x=Nodos(:,2)/1000; y=Nodos(:,3)/1000; % Coordenadas de los nodos
TipoNodo=Nodos(:,4);        % Tipo de nodo (marcador)
Conec=Elem(:,2:4);          % Matriz de Conectividad
TipoMat=Elem(:,13);         % Tipo de Material
    
% Representaci�n gr�fica de la malla
Repre2DmallaT(x,y,Conec)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%      ENSAMBLAJE                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=length(x);           % N�mero de nodos (que es igual al n�mero de inc�gnitas)
Ne=length(Elem(:,1));  % N�mero de elementos
K=sparse(n,n);         % Matriz K
q=zeros(n,1);          % Vector q

% Ensamblaje a lo largo de todos los elementos triangulares
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad T�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   [Ke,B]=KcalorT2D(x(ii),y(ii),k);
   
   % Ensamblaje
   K(ii,ii)=K(ii,ii)+Ke;
end
Ko=K; qo=q; % Valores de K y q antes de aplicar las condiciones de contorno

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Introducci�n de las condiciones de contorno en temperatura %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Kmax=max(max(abs(K)));
Kinf=1e8*Kmax;

T10 = 25;  % Temperatura en lado derecho del ladrillo 
           % (nodos marcados como 10)
       
T9  =  5;  % Temperatura en lado izquierdo del ladrillo 
           % (nodos marcados como 9)

figure(1), hold on
T=T10; % Nodos marcados como 10
ii=find( TipoNodo==10 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'ro');

% Nodos marcados como 9
T=T9; 
ii=find( TipoNodo==9 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'go');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Resoluci�n del sistema de ecuaciones %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u = K\q ;  % Calculo de la temperatura en cada nodo


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para las temperaturas)              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure, trisurf(Conec,x*1000,y*1000,u); axis equal, colorbar
xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('T (�C)');

colormap jet   % Mapa de color JET
view(2)        % Representaci�n bidimensional
shading interp % Se eliminan las aristas de los tri�ngulos


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para el flujo de calor)             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% C�lculo del Flujo en el centro de los elementos
xc=NaN(Ne,1); yc=xc; % Coordenadas de los centros de los Elementos
Qx=xc;        Qy=xc; % Componentes del vector flujo de calor
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad t�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   
   % Centro del tri�ngulo
   xc(i)=mean(x(ii)); yc(i)=mean(y(ii));
   
   % Matriz M 
   [~,~,M]=KcalorT2D(x(ii),y(ii),k);
   Q = M*u(ii); 
   
   Qx(i)=Q(1);
   Qy(i)=Q(2);
end

% Representaci�n gr�fica del flujo de calor
figure
quiver(xc*1000,yc*1000,Qx,Qy); axis equal
xlabel('X (mm)'); ylabel('Y (mm)');
title('Vector Flujo de Calor');
