% Programa para la resoluci�n de problemas de TRANSMISI�N DEL CALOR 2D
% por el M�todo de los Elementos Finitos 
% (Elementos Triangulares)
%
%
% Resoluci�n del ejercicio Chip.xls (problema est�tico #1):
%     - Se conoce la temperatura en los tubos (nodos tipo 6, 35 �C)
%     - Se conoce la temperatura en el chip (nodos tipo 3, 100 �C)
%     - Se conoce la temperatura del aire lejos del chip (nodos tipo 1, 25�C)

close all, clear all, fclose all;

arc='chip.xls';  % Nombre del archivo EXCEL que contiene la definici�n del problema
                 % (Se supone que se ha generado con EasyMesh.m)
                  
% Lecturas de las distintas pesta�as del archivo EXCEL
% ��� OJO !!! Se supone que los archivos EXCEL tienen un maximo de 65536 filas


% Tipos de Materiales
Material=[
% Tipo   k (conductividad t�rmica en W/(m*k) )   
   1    0.026          ; ...  % Aire
   2    389            ; ...  % Cobre
   3    160            ; ...  % Aluminio
   4    148            ; ...  % Silicio
   5    1.3         ]  ;      % Cer�mica
   
   
% Lecturas de las pesta�as 'n', 'e' y 's' del archivo EXCEL
Nodos =xlsread(arc,'n','A29:D65536');   % Pesta�a 'n' (NODOS)
Elem  =xlsread(arc,'e','A29:M65536');   % Pesta�a 'e' (ELEMENTOS)
Segmen=xlsread(arc,'s','A29:F65536');   % Pesta�a 's' (SEGMENTOS)

x=Nodos(:,2); y=Nodos(:,3); % Coordenadas de los nodos
TipoNodo=Nodos(:,4);        % Tipo de nodo (marcador)
Conec=Elem(:,2:4);          % Matriz de Conectividad
TipoMat=Elem(:,13);         % Tipo de Material
    
% Representaci�n gr�fica de la malla
Repre2DmallaT(x,y,Conec)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%      ENSAMBLAJE                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=length(x);           % N�mero de nodos (que es igual al n�mero de inc�gnitas)
Ne=length(Elem(:,1));  % N�mero de elementos
K=sparse(n,n);         % Matriz de Capacidad global
q=zeros(n,1);          % Vector de fuentes de calor nodales

% Ensamblaje a lo largo de todos los elementos triangulares
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad T�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   [Ke,B]=KcalorT2D(x(ii),y(ii),k);
   
   % Ensamblaje de la matriz K
   K(ii,ii)=K(ii,ii)+Ke;
end
Ko=K; qo=q; % Valores de C y q antes de aplicar las condiciones de contorno

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Introducci�n de las condiciones de contorno en temperatura %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Kmax=max(max(abs(K)));
Kinf=1e8*Kmax;

T1 = 25;   % Temperatura del aire lejos del chip
           % (nodos marcados como 1)

T6 = 35;   % Temperatura en los tubos de refrigeraci�n
           % (nodos marcados como 6)
       
T3 = 100;  % Temperatura en chip
           % (nodos marcados como 3)

figure(1), hold on
T=T6; % Nodos marcados como 6
ii=find( TipoNodo==6 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'ro');

% Nodos marcados como 3
T=T3; 
ii=find( TipoNodo==3 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'go');


% Nodos marcados como 1
T=T1; 
ii=find( TipoNodo==1 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'mo');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Resoluci�n del sistema de ecuaciones %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u = K\q ;  % Calculo de la temperatura en cada nodo


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para las temperaturas)              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure, h=trisurf(Conec,x,y,u); 
axis equal, colormap jet, shading interp
set(h,'EdgeColor','w')
colorbar
xlabel('X (m)'); ylabel('Y (m)'); zlabel('u (V)');
view(2)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para el flujo de calor)             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% C�lculo del Flujo en el centro de los elementos
xc=NaN(Ne,1); yc=xc; % Coordenadas de los centros de los Elementos
Qx=xc;        Qy=xc; % Componentes del vector flujo de calor
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad t�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   
   % Centro del tri�ngulo
   xc(i)=mean(x(ii)); yc(i)=mean(y(ii));
   
   % Matriz M 
   [~,~,M]=KcalorT2D(x(ii),y(ii),k);
   Q = M*u(ii);   % Flujo de calor 
   
   Qx(i)=Q(1);
   Qy(i)=Q(2);
end

% Representaci�n gr�fica del flujo de calor
figure
quiver(xc,yc,Qx,Qy); axis equal
xlabel('X (m)'); ylabel('Y (m)');
title('Vector Flujo de Calor');
