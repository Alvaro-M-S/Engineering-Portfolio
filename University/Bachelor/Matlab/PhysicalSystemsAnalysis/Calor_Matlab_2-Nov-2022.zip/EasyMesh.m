function [Nodos,Elem,Segmen]=EasyMesh(arc,graf)

% Esta funci�n EasyMesh.m llama al programa EasyMesh.exe 
% ver http://web.mit.edu/easymesh_v1.4/www/easymesh.html
%     https://web.ti.bfh.ch/~sha1/pwf/fem/EasyMesh/html/easymesh.html
%   y http://www.ae.metu.edu.tr/~ae305/Easymesh/

% Variables de Entrada
% arc:  Archivo EXCEL. En la pesta�a "d" de este archivo se encuentra
%       la informaci�n que EasyMesh.exe requiere que est� en el archivo
%       .d (definici�n de la malla):
%         - Nodos del Contorno
%         - Segmentos del Contorno
%
% graf: Es una variable l�gica, si toma un valor verdadero se realizan
%       representaciones gr�ficas de la entrada y la salida
%
% Variables de salida:
% Nodos:  Matriz que contiene la informaci�n de los nodos     (pesta�a n)
% Elem:   Matriz que contiene la informaci�n de los elementos (pesta�a e)
% Segmen: Matriz que contiene la informaci�n de los segmentos (pesta�a s)
% 
% IMPORTANTE:
%       EasyMesh.exe comienza la numeraci�n de los nodos, elementos y
%       segmentos por cero. 
%       Sin embargo, EasyMesh.m, por coherencia con MATLAB, comienza la
%       numeraci�n por uno.
%
% (c) Escrita inicialmente por Jes�s de Vicente para Windows
%     Adaptada posteriormente  por Victor H. Alca�iz para Linux/MacOS

if nargin < 2
    graf = false;
end

% Tipos de Sistemas Operativos considerados:
%      'PCWIN64' - 64-bit Windows� platform
%      'GLNXA64' - 64-bit Linux� platform
%      'MACI64'  - 64-bit macOS platform

% Se lee la pesta�a 'd' del archivo arc
switch computer
    case 'PCWIN64', num = xlsread(arc,'d'); % xlsread es mas r�pido que readmatrix en Windows
    case 'GLNXA64', num = readmatrix(arc, 'Sheet', 'd'); % xlsread no funciona ni en MacOS ni en Linux
    case 'MACI64',  num = readmatrix(arc, 'Sheet', 'd'); 
end


% Datos de los nodos del contorno
Points = num(:, 1:5);
ii = isfinite(Points(:, 1));
Points = Points(ii, :);     
Points(:, 1) = Points(:, 1) - 1;  % Los �ndices en EasyMesh deben comenzar 
                                  % en cero (se resta 1)

% Datos de los segmentos del contorno
Segments = num(:, 9:12);
ii = isfinite(Segments(:, 1));
Segments = Segments(ii, :); 
Segments(:, 1:3) = Segments(:, 1:3) - 1; % Los �ndices en EasyMesh deben 
                                         % comenzar en cero (se resta 1)

% Escritura del archivo de texto 'nada.d' donde se le pasar� la informaci�n
% a EasyMesh.exe
f = fopen('nada.d', 'w');

% Escritura de la informaci�n de los nodos
fprintf(f, '%1.0f \r\n', length(Points(:,1)));
fprintf(f, '%4.0f:      %0.16e %0.16e     %0.16e     %1.0f \r\n', Points');

% Escritura de la informaci�n de los segmentos
fprintf(f, '%1.0f \r\n', length(Segments(:, 1)));
fprintf(f, '%4.0f:  %4.0f %4.0f        %1.0f \r\n', Segments');

% Los �ndices en Matlab comienzan en cero (hay que sumar una unidad)
Points(:, 1) = Points(:, 1) + 1;        
Segments(:, 1:3) = Segments(:, 1:3) + 1;

fclose(f);

% Se representa gr�ficamente el contenido de la pesta�a 'd'
if graf
    figure
    for i = 1:length(Points(:, 2))
        plot(Points(i, 2), Points(i, 3), 'bo'); hold on
        text(Points(i, 2), Points(i, 3), sprintf('%1.0f', i));
    end
    for i = 1:length(Segments(:, 1))
        ii = Segments(i, 2:3); m = Segments(i, 4);
        plot(Points(ii, 2),Points(ii, 3), 'g'); hold on
        text(mean(Points(ii, 2)), mean(Points(ii, 3)), sprintf('%1.0f', m));
    end
    axis equal
end

% drawnow
% disp('Pulsar cualquier tecla para continuar...');
% pause

% Tipos de Sistemas Operativos considerados:
%      'PCWIN64' - 64-bit Windows� platform
%      'GLNXA64' - 64-bit Linux� platform
%      'MACI64'  - 64-bit macOS platform


% Se llama a EasyMesh
switch computer
    case 'PCWIN64', system('EasyMesh_win nada.d');
    case 'GLNXA64', system('chmod +x EasyMesh_linux');
                    system('./EasyMesh_linux nada.d');
    case 'MACI64',  system('chmod +x EasyMesh_macos');
                    system('./EasyMesh_macos nada.d');
end
        

% Lectura de los archivos generados por EasyMesh.exe
% Lectura del archivo nada.n (nodos)
f = fopen('nada.n', 'r');
s = fgetl(f); n = sscanf(s, '%f'); Nodos = NaN(n, 4);
for i = 1:n
    s = fgetl(f); num = sscanf(s, '%f: %f %f %f');
    Nodos(i, :) = [i num(2:end)'];
end
fclose(f);

% Lectura del archivo nada.e (elementos)
f = fopen('nada.e', 'r');
s = fgetl(f); n = sscanf(s, '%f'); Elem = NaN(n, 13);
for i = 1:n
    s = fgetl(f); num = sscanf(s,'%f: %f %f %f %f %f %f %f %f %f %f %f %f');
    Elem(i, :) = [i num(2:end)'];
end
Elem(:, 2:10) = Elem(:, 2:10) + 1;
A = Elem(:, 2:10); ii = find(A(:) == 0); A(ii) = -1; Elem(:, 2:10) = A;
fclose(f);

% Lectura del archivo nada.s (segmentos)
f = fopen('nada.s', 'r');
s = fgetl(f); n = sscanf(s, '%f'); Segmen = NaN(n, 6);
for i = 1:n
    s = fgetl(f); num = sscanf(s, '%f: %f %f %f %f %f %f');
    Segmen(i, :) = [i num(2:end)'];
end
Segmen(:, 2:5) = Segmen(:, 2:5) + 1;
A = Segmen(:, 2:5); ii = find(A(:) == 0); A(ii) = -1; Segmen(:, 2:5) = A;
fclose(f);


% Tipos de Sistemas Operativos considerados:
%      'PCWIN64' - 64-bit Windows� platform
%      'GLNXA64' - 64-bit Linux� platform
%      'MACI64'  - 64-bit macOS platform


% ��� OJO !!! Se supone que el n�mero m�ximo de filas en EXCEL es 65536
nn = 65536 - 28;    % N�mero de filas a escribir. 
                    % La primera fila que se escribe es la fila 29
switch computer
    case 'PCWIN64'  % xlswrite es mas r�pido que writematrix en Windows
        % Se vac�an las pesta�as n, e y s antes de escribir en ellas
        xlswrite(arc,NaN(nn, 4),'n','A29'); 
        xlswrite(arc,NaN(nn,13),'e','A29'); 
        xlswrite(arc,NaN(nn, 6),'s','A29'); 
        
        % Escritura en el archivo EXCEL
        xlswrite(arc,Nodos ,'n','A29'); % Escritura de la informaci�n relativa a los NODOS
        xlswrite(arc,Elem  ,'e','A29'); % Escritura de la informaci�n relativa a los ELEMENTOS
        xlswrite(arc,Segmen,'s','A29'); % Escritura de la informaci�n relativa a los SEGMENTOS
    case {'GLNXA64', 'MACI64'} % xlswrite no funciona ni en MacOS ni en Linux, por eso se usa writematrix
        % Se vac�an las pesta�as n, e y s antes de escribir en ellas
        writematrix(NaN(nn, 4),  arc, 'Sheet','n', 'Range','A29'); 
        writematrix(NaN(nn, 13), arc, 'Sheet','e', 'Range','A29'); 
        writematrix(NaN(nn, 6),  arc, 'Sheet','s', 'Range','A29'); 
        
        % Escritura en el archivo EXCEL
        writematrix(Nodos , arc, 'Sheet','n', 'Range','A29'); % Escritura de la informaci�n relativa a los NODOS
        writematrix(Elem  , arc, 'Sheet','e', 'Range','A29'); % Escritura de la informaci�n relativa a los ELEMENTOS
        writematrix(Segmen, arc, 'Sheet','s', 'Range','A29'); % Escritura de la informaci�n relativa a los SEGMENTOS
end


if graf
    figure; 
    indices = [Points(:, end) ; Segments(:,end) ; Nodos(:,end) ; ...
        Elem(:,end) ; Segmen(:,end)];
    imin = min(indices);
    imax = max(indices);
    colores = lines(1 + (imax - imin));
   
    % Representaci�n gr�fica de la salida (elementos)
    for i = 1:length(Elem(:, 1))
        if i == 2
            hold on
        end
        % a = Elem(i, 2); b = Elem(i, 3); c = Elem(i, 4);
        % x = Nodos([a b c a],2); y = Nodos([a b c a], 3); 
        % plot(x,y,'k');
        plot( Elem(i, 11), Elem(i, 12), '.', 'color',...
            colores(1 - imin + Elem(i, end), :) );
    end

    % Representaci�n gr�fica de la salida (segmentos)
    for i = 1:length(Segmen(:,1))
        a = Segmen(i, 2); b = Segmen(i, 3);
        x = Nodos([a b], 2); y = Nodos([a b], 3);
        plot(x, y, 'color',colores(1 - imin + Segmen(i, end), :) );
    end
   
    % Representaci�n gr�fica de la entrada
    for i = 1:length(Points(:, 1))
        plot(Points(i, 2),Points(i, 3), 'o', 'color',...
            colores(1 - imin + Points(i, 5), :));
    end
    axis equal, grid on
    
    % Representaci�n gr�fica de la salida (nodos)
    for i = 1:length(Nodos(:, 1))
        plot(Nodos(i, 2),Nodos(i, 3), '.', 'color',...
            colores(1 - imin + Nodos(i, 4), :));
    end    
    
end

% Elimino los archivos generados por el ejecutable EasyMesh
switch computer
    case {'GLNXA64','MACI64'}
        system('rm ./nada.d');
        system('rm ./nada.n');
        system('rm ./nada.e');
        system('rm ./nada.s');
    case 'PCWIN64'
        system('del nada.d');
        system('del nada.n');
        system('del nada.e');
        system('del nada.s');
end
