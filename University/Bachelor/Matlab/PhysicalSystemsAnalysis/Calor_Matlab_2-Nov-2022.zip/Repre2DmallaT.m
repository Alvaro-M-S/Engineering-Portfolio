function Repre2DmallaT(x,y,triang)
% Repre2DmallaT(x,y,triang)
%
% Representa una malla 2D de tri�ngulos
%
% Variables de entrada:
%
%         x,y: vectores de dimensi�n Nnx1 conteniendo las coordenadas de los
%              nodos de la malla
%      triang: Matriz de dimensi�n Ntx3 conteniendo los n�meros de los
%              nodos del tri�ngulo

%     Nn y Nt son, respectivamente, el n�mero de nodos y el de tri�ngulos

Nn=length(x);
Nt=length(triang(:,1));


Alternativa=2;

figure
switch Alternativa
    case 1 % Representaci�n tri�ngulo a tri�ngulo
        for i=1:Nt
            ii=triang(i,:);
            ii=[ ii ii(1) ];
            plot(x(ii),y(ii),'b'); hold on
        end
        grid on, axis equal
        
    case 2 % Representaci�n de una sola vez    
        % Representaci�n de las barras
        X=NaN(5*Nt,1); Y=X;
        for i=1:Nt    
            ii=triang(i,:);
            ii=[ ii ii(1) ];
            jj=5*(i-1)+[1 2 3 4];
            X(jj)=x(ii);
            Y(jj)=y(ii);
        end
        plot(X,Y,'b'); grid on, axis equal

end

