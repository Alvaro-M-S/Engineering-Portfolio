% Programa para la resoluci�n de problemas de TRANSMISI�N DEL CALOR 2D
% por el M�todo de los Elementos Finitos 
% (Elementos Triangulares)
%
%
% Resoluci�n del ejercicio Chip.xls (problema din�mico #3):
%     - Se conoce todo el campo de temperaturas en t=0 (35�C en todos los nodos)
%       El conjunto est� en equilibrio t�rmico.
%     - Se conoce la temperatura en los tubos (nodos tipo 6, 35 �C)
%     - Se conoce la temperatura del aire lejos del chip (nodos tipo 1, 35�C)
%     - Estas dos �ltimas temperatura permanecen siempre constantes
%     - Para t>0 se conecta la alimentaci�n del chip y comienza a generar
%        calor de forma constante


close all, clear all, fclose all;

arc='chip.xls';  % Nombre del archivo EXCEL que contiene la definici�n del problema
                 % (Se supone que se ha generado con EasyMesh.m)
                  
% Lecturas de las distintas pesta�as del archivo EXCEL
% ��� OJO !!! Se supone que los archivos EXCEL tienen un maximo de 65536 filas

% Nomenclatura de las propiedades del material
%    k : conductividad t�rmica en W/(m*k) 
%   ro : densidad en kg/m^3
%   Cp : calor espec�fico en J/(kg*K)

% Tipos de Materiales
Material=[
% Tipo   k      ro   Cp
   1    0.026   1.22    1.00   ; ...  % Aire
   2    389     8960    385    ; ...  % Cobre
   3    160     2700    910    ; ...  % Aluminio
   4    148     2330    710    ; ...  % Silicio
   5     12     3800    750 ]  ;      % Cer�mica (Al�mina, para chips)
   
   
% Lecturas de las pesta�as 'n', 'e' y 's' del archivo EXCEL
Nodos =xlsread(arc,'n','A29:D65536');   % Pesta�a 'n' (NODOS)
Elem  =xlsread(arc,'e','A29:M65536');   % Pesta�a 'e' (ELEMENTOS)
Segmen=xlsread(arc,'s','A29:F65536');   % Pesta�a 's' (SEGMENTOS)

% Densidad de calor generado por unidad de volumen:
%     El chip se supone que tiene unas dimensiones de 
%     20 mm x 20 mm x 3 mm y que disipa 100 W 

q_chip   = 100 / (0.020*0.020*0.003) ; % Densidad de calor generado

Hz       = 0.02 ; % Dimensi�n del sistema en la direcci�n Z
                  % Es igual a la longitud del lado del chip
TipoChip = 4 ;    % Tipo de los elementos que pertenecen al chip (4)               

x=Nodos(:,2); y=Nodos(:,3); % Coordenadas de los nodos
TipoNodo=Nodos(:,4);        % Tipo de nodo (marcador)
Conec=Elem(:,2:4);          % Matriz de Conectividad
TipoMat=Elem(:,13);         % Tipo de Material
    
% Representaci�n gr�fica de la malla
Repre2DmallaT(x,y,Conec)

% Ecuaci�n din�mica
% Kt*(du/dt) + K*u = q

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%      ENSAMBLAJE                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=length(x);           % N�mero de nodos (que es igual al n�mero de inc�gnitas)
Ne=length(Elem(:,1));  % N�mero de elementos
% K=sparse(n,n);         % Matriz K global
% Kt=sparse(n,n);        % Matriz Kt
K  = zeros(n);         % Matriz K global
Kt = zeros(n);         % Matriz Kt
q=zeros(n,1);          % Vector de fuentes de calor nodales

% Ensamblaje a lo largo de todos los elementos triangulares
for i=1:Ne
   % Tipo de material
   j  = find( Material(:,1)==TipoMat(i) );
   k  = Material(j,2);  % Conductividad T�rmica
   ro = Material(j,3);  % Densidad
   cp = Material(j,4);  % Calor espec�fico
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   [Ke,Be]=KcalorT2D(x(ii),y(ii),k);
   
   % Ensamblaje de la matriz K
   K(ii,ii)=K(ii,ii)+Ke;
   
   % Ensamblaje de la matriz Kt
   Kt(ii,ii)=Kt(ii,ii)+ro*cp*Be;
   
   % fuentes nodales de calor
   if TipoMat(i)==TipoChip
       p=ones(3,1)*q_chip;  % densidades nodales de calor 
   else
       p=zeros(3,1);
   end
   qe=Be*p; % fuentes nodales de calor equivalentes
   
   % Ensamblaje de fuentes nodales de calor
   q(ii)=q(ii)+qe;
end
Ko=K; qo=q; % Valores de C y q antes de aplicar las condiciones de contorno

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Introducci�n de las condiciones de contorno en temperatura %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Kmax=max(max(abs(K)));
Kinf=1e8*Kmax;

To = 35;   % Temperatura de todos los nodos en t=0
           % (equililbrio t�rmico con el ambiente)

T1 = 35;   % Temperatura del aire lejos del chip
           % (nodos marcados como 1)

T6 = 35;   % Temperatura en los tubos de refrigeraci�n
           % (nodos marcados como 6)

figure(1), hold on


T=T6; % Nodos marcados como 6
ii=find( TipoNodo==6 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'ro');



% Nodos marcados como 1
T=T1; 
ii=find( TipoNodo==1 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'mo');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% REGIMEN PERMANENTE :  Resoluci�n del %%%
%%% sistema de ecuaciones lineales       %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u_per = K\q ;  % Calculo de la temperatura en cada nodo


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para las temperaturas en Reg. Per.) %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure, h=trisurf(Conec,x,y,u_per); 
axis equal, colormap jet, shading interp
set(h,'EdgeColor','w')
colorbar
xlabel('X (m)'); ylabel('Y (m)'); zlabel('u (V)');
view(2)
title('Distribuci�n de temperaturas en R�gimen Permanente');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado  %%% 
%%% (para el flujo de calor en Reg. Per.) %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% C�lculo del Flujo en el centro de los elementos
xc=NaN(Ne,1); yc=xc; % Coordenadas de los centros de los Elementos
Qx=xc;        Qy=xc; % Componentes del vector flujo de calor
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad t�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   
   % Centro del tri�ngulo
   xc(i)=mean(x(ii)); yc(i)=mean(y(ii));
   
   % Matriz M 
   [~,~,M]=KcalorT2D(x(ii),y(ii),k);
   Q = M*u_per(ii);   % Flujo de calor (2D, por unidad de longitud)
   
   Qx(i)=Q(1);
   Qy(i)=Q(2);
end

% Representaci�n gr�fica del flujo de calor en R�gimen Permanente
figure
quiver(xc,yc,Qx,Qy); axis equal
xlabel('X (m)'); ylabel('Y (m)');
title('Vector Flujo de Calor en R�gimen Permanente');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% REGIMEN TRANSITORIO :  Resoluci�n del %%%
%%% sistema de ecuaciones diferenciales   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Campo de temperaturas en el instante inicial t=0
uo = To*ones(size(u_per)); 

% Resoluci�n del problema de valores y vectores propios
% A = Kt\K ;
% [V,D]=eig(A); lambda=diag(D); 
[V,D]  = eig(K,Kt,'chol');
lambda = diag(D); 
tau    = 1./lambda;

% Representaci�n gr�fica de los tau_i
semilogy(sort(tau,'descend'),'o'); grid on; 
ylabel('Tiempos \tau_i (s)'); xlabel('�ndice i');

% C�lculo de las constantes de integraci�n ci
c = V \ (uo-u_per);

% C�lculo de y(t)=u(t)-u_per y almacenamiento en la matriz Y
% La matriz Y tiene dimensiones n x Nt donde:
%    n  : n�mero de nodos
%    Nt : n�mero de instantes
%
% Por tanto, en cada columna tenemos el vector y(t)
% que representa el campo de temperaturas y(t)=u(t)-u_per en el instante t
%
% En la fila i-�sima tenemos la variaci�n de la temperatura yi(t)=Ti(t)-Ti(inf)
% del nodo i-�simo a lo largo del tiempo
%
% Es decir, para el nodo i-�simo en el instante j-�simo tj
%
%    Y(i,j) = yi(tj) = Ti(tj) - Ti(inf)

t_max=5; % L�mite superior del intervalo temporal que se va a estudiar
Nt=200;  % N�mero de instantes en los que se va a realizar el c�lculo
t = [0:(Nt-1)]/(Nt-1) * t_max;   % Instantes ti
Y = V*diag(c)*exp( -lambda*t );  % Matriz Y de temperaturas Yij=yi(tj)=u(tj)-u_per


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%   Representaci�n gr�fica del campo de temperaturas  %%% 
%%%   en R�GIMEN TRANSITORIO (ANIMACI�N)                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure, h=trisurf(Conec,x,y,u_per+Y(:,end)); 
% axis equal
colormap jet, shading interp
set(h,'EdgeColor','w')
colorbar
xlabel('X (m)'); ylabel('Y (m)'); zlabel('u (V)');
% view(2)
title(sprintf('Distribuci�n de temperaturas en t_{MAX}=%0.2f s',t(end)));

disp('Pulsar [Enter] para continuar .... ');
pause

ejes=axis;

% Animaci�n (variaci�n de la temperatura desde t=0 hasta t=tmax)
Tmax=NaN*t; % Vector para el almacenamiento de la temperatura m�xima Tmax
for j=1:length(t)
    h=trisurf(Conec,x,y,u_per+Y(:,j)); 
    colormap jet, shading interp
    set(h,'EdgeColor','w')
    axis(ejes); 
    title(sprintf('Distribuci�n de temperaturas en t=%0.2f s',t(j)));
    drawnow
    Tmax(j)=max( u_per+Y(:,j) );
end

% Representaci�n de la evoluci�n de la temperatura m�xima en funci�n del tiempo
figure
plot(t,Tmax); grid on
xlabel('Tiempo t (s)');
ylabel('Tmax (�C)');
