% Tipos de Materiales
Material=[
% Tipo   k      ro   Cp  (todo en unidades SI)   
   1    0.5     1800    840    ; ...  % Arcilla (ladrillo com�n)
   2    0.026   1.22    1.00   ; ...  % Aire
   3    0.25    900     1000   ; ...  % Yeso    
   4    0.26e-4 1       1.00   ; ...  % "Superaislante"

  12    389     8960    385    ; ...  % Cobre
  13    160     2700    910    ; ...  % Aluminio
  14    148     2330    710    ; ...  % Silicio
  15     12     3800    750 ]  ;      % Cer�mica (Al�mina, para chips)
%
% Unidades SI:
%  k  : conductividad t�rmica , W/(m*K)
%  ro : densidad, kg/m3
%  Cp : calor espec�fico, en J/(K*kg)
