%Tarea Tema 7

[x,y,Fijos,mn,fx,fy , barras,mb,k,loo]=LeeEstru2D('TareaTema7_18240');

Representa2D(x,y,barras);

hold on

g=9.7995;

Nn=length(x); %numero de nodos
Nb=length(k); %numero de barras
gdl=2*Nn; %numeor de gdl

%Reserva de memoria para las variables del problema
K=zeros(gdl,gdl); %Matriz de rigidez
M=zeros(gdl,gdl);%Matriz de Masa

f=zeros(gdl,1); %Vector de fuerzas

f(1:2:end)=f(1:2:end)+fx;
f(2:2:end)=f(2:2:end)+fy;
f(2:2:end)=f(2:2:end)-mn*g;

%Ensambleje de las barras

for e=1:Nb
 a=barras(e,1);
 b=barras(e,2);
 ra=[x(a) y(a)];
 rb=[x(b) y(b)];
 [Ke,Me,fg]=barra2D(ra,rb,k(e),mb(e));
 
 ii=[2*(a-1)+1 2*(a-1)+2 2*(b-1)+1 2*(b-1)+2];
 
 %Ensamblaje
 K(ii,ii)=K(ii,ii)+Ke;
 M(ii,ii)=M(ii,ii)+Me;
 f(ii)=f(ii)+fg;
 
end

%Aplicaci�n de las condiciones de contorno
Kmax=max(abs(K(:)));
Kinf=1e8*Kmax;
fijos=NaN(gdl,1);
fijos(1:2:end)=Fijos(:,1);
fijos(2:2:end)=Fijos(:,2);
for i=1:gdl
    if fijos(i)==1
    K(i,i)=K(i,i)+Kinf;
    end
end

%Resoluci�n R�gimen Permanente

%En el nodo 9 se introduce una fuerza vertical de tipo oscilante con
%frecuencia angular wo
wo=2*pi*50; %50 Hz
fo=zeros(gdl,1);
fo(2*9)=500; %500 N en nodo 9 seg�n y

v=(-wo^2+M+K)\fo;

Amp= 100 %Factor de amplificaci�n

Representa2Dmodo(x,y,barras,v,'EjemploDin.gif');
Representa2Dmov(x,y,barras,v,'EjemploDin.gif');

dx=v(1:2:end);
dy=v(2:2:end);


sol='Desplazamiento de los nodos:';
disp('  ');
disp(sol);
for i=1:Nn
    s=sprintf('Nodo %2.0f : dX= %7.3f mm  dY= %7.3f mm',i,dx(i)*1000,dy(i)*1000);
    disp(s);
end 

fileID = fopen('Resultados.txt', 'w');

fprintf(fileID,'Desplazamiento de los nodos\n\n');
for i=1:Nn
fprintf(fileID,'Nodo %2.0f : dX= %7.3f mm  dY= %7.3f mm \n',i,dx(i)*1000,dy(i)*1000);
end
fclose(fileID);