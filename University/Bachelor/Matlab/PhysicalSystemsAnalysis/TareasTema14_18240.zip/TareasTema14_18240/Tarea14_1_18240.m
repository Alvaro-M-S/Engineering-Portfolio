%Tareas Obligatorias Tema 14.1 (�lvaro Morales - 18240)

close all, clear all

Lx  = 5 ;     % Longitud del rect�ngulo seg�n X, en metros
Ly  = 4 ;     % Longitud del rect�ngulo seg�n Y, en metros
esp = 1;    % Espesor de la placa en metros

Nex =  5 ;    % N�mero de elementos seg�n X
Ney =  4 ;    % N�mero de elementos seg�n Y
Nez =  2 ;    % N�mero de elementos seg�n Z

Nnx = Nex+1 ; % N�meros de elementos seg�n los ejes X,Y,Z
Nny = Ney+1 ;
Nnz = Nez+1 ;

[J,I]=meshgrid(1+[0:Nex],1+[0:Ney]);  % �ndices dobles de los nodos

X=(J-1)*Lx/Nex;   % Coordenadas de los nodos
Y=(I-1)*Ly/Ney;   % Coordenadas de los nodos

nodos2D=[ X(:) Y(:) ];
elem2D=[];
for e=1:Ney
    for f=1:Nex
        i=e; j=f;
        a1 = (j  -1)*Nny+i  ;
        a2 = (j+1-1)*Nny+i  ;
        a3 = (j+1-1)*Nny+i+1;
        a4 = (j  -1)*Nny+i+1;
        elem2D=[elem2D ; a1 a2 a3 a4 ];
    end
end

% Representaci�n de la malla 2D
Representa2DCuad(nodos2D,elem2D);

% Se convierte en 3D la malla 2D
[nodos,elem]=Paso2Da3D(nodos2D,elem2D,esp,Nez);

% Matrices adicionales para representar la superficie exterior del sistema:
%   CarasExt:  Matriz de conectividad de las caras externas
%   BarrasExt: Matriz de conectividad de las aristas externas de los
%              elementos
%   NodosExt:  Vector con la lista de nodos externos
%   caras:     Matriz de conectividad de todas las caras (internas y externas)
%   barras:    Matriz de conectividad de todas las barras (internas y externas)
[CarasExt,BarrasExt,NodosExt,caras,barras]=CarasBarras(elem);

% Representaci�n del sistema tipo "wire-frame"
Representa3Dbarras(nodos,barras), 

% Representaci�n de la superficie externa del sistema
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)
hfigura=gcf;

%Unir los tres conjuntos
nod1=nodos; ele1=elem;
nodos=[]; elem=[];
for i=1:2,for j=1:2;
        dx=(j-1)*5; dy=(i-1)*4;
        nodi = [ nod1(:,1)+dx nod1(:,2)+dy nod1(:,3) ];
        [nodos,elem]=UnirLadrillos(nodos,elem,nodi,ele1);
        [n2,e2]=UnirLadrillos(nod1,ele1,nodi,ele1);
        
        % Representaci�n gr�fica del proceso de uni�n
        % RepresentaLadrillos(nodos,elem);
        % title(sprintf('Fase i=%1.0f  j=%1.0f',i,j));
        % nada=input('Pulsar [Intro] para continuar...','s');
end,end
for i=2:2,for j=2:2;
        dx=(j-1)*5; dy=(i-1)*4;
        nodi = [ nod1(:,1)+dx nod1(:,2)+dy nod1(:,3) ];
        [nodos,elem]=UnirLadrillos(nodos,elem,nodi,ele1);
        [n2,e2]=UnirLadrillos(nod1,ele1,nodi,ele1);
        
        % Representaci�n gr�fica del proceso de uni�n
        % RepresentaLadrillos(nodos,elem);
        % title(sprintf('Fase i=%1.0f  j=%1.0f',i,j));
        % nada=input('Pulsar [Intro] para continuar...','s');
end,end
[CarasExt,BarrasExt,NodosExt,Caras,Barras,TN]=CarasBarras(elem);

% Representaci�n gr�fica 
RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt)

Nn=length(nodos(:,1));
Ne=length(elem(:,1));

%'POLIURETANO'
    E = 100e6;    % Modulo de Young (unidades SI, Pa)
    nu= 0.30;     % Coeficiente de Poisson
    ro= 35;       % Densidad, en kg/m3

% Aplicaci�n de las condiciones de contorno
% (realmente no hay ning�n nodo fijo)
Fijos=0*nodos; % Todos los nodos libres;
ii=find(nodos(:,1)==0);
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen x=0
ii=find((nodos(:,1)==5)&(nodos(:,2)>=4))
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen x=5 e y>=4
ii=find(nodos(:,2)==0);
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen y=0
ii=find((nodos(:,2)==4)&(nodos(:,1)>=5))
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen y=4 e y>=5
ii=find(nodos(:,1)==10);
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen x=10
ii=find(nodos(:,2)==8);
Fijos(ii,:)=1; % Nodos fijos aquellos que tienen y=8

Vzo=0*nodos(:,1); % Todas las velocidades de los nodos en t=0 son nulas
ii=find((nodos(:,1)==2)&(nodos(:,2)==2)&(nodos(:,3)==1));
Vzo(ii)=1;

Fxdin=1680*ones(Nn);

% Escritura de la informaci�n en los archivos

% Archivo malla.nodos.txt
f=fopen('malla.nodos.txt','w');
fprintf(f,'%%                                      Nodos                   Fuerzas Estaticas              Fuerzas Dinamicas                              Condiciones Iniciales       \r\n');
fprintf(f,'%%                                      Fijos                                                                                            Posici�n                Velocidad    \r\n');
fprintf(f,'%% N�Nodo     X(m)    Y(m)    Z(m)      X Y Z     m(kg)      Fxo(N)   Fyo(N)   Fzo(N)        Fx(N)    Fy(N)    Fz(N)     f(Hz)     dXo(m) dYo(m) dZo(m)  Vxo(m/s) Vyo(m/s) Vzo(m/s)  \r\n');

data= [ [1:Nn]' nodos Fijos zeros(Nn,4) 1680*ones(Nn,1) zeros(Nn,8) Vzo ];
fprintf(f,'  %4.0f     %+7.3f %+7.3f %+7.3f     %1.0f %1.0f %1.0f    %6.3f    %+8.3f %+8.3f %+8.3f     %+8.3f %+8.3f %+8.3f   %6.1f     %+6.3f %+6.3f %+6.3f  %+8.3f %+8.3f %+8.3f \r\n',data');
fclose(f);

dos('copy Plantilla.xls malla.xls');
xlswrite('malla.xls',data,'nodos','A4');



% Archivo malla.elem.txt
f=fopen('malla.elem.txt','w');
fprintf(f,'%% N�Elem      a1   b1   c1   d1   a2   b2   c2   d2   ro(kg/m3)   E(PA)   nu \r\n');

data=[ [1:Ne]' elem ro*ones(Ne,1) E*ones(Ne,1) nu*ones(Ne,1) ];
fprintf(f,'  %4.0f      %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f %4.0f   %6.1f %10g %4.2f \r\n',data');
fclose(f);

xlswrite('malla.xls',data,'elem','A2');
