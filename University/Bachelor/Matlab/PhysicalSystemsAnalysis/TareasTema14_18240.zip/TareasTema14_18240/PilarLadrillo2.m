function [ nodos,elem ] = PilarLadrillo(a,b,L,A,B,C);
%PilarLadrillo genera un pilar vertical utilizando 
%   elementos tipo LADRILLO.
%
% Variables de entrada:
%   - a,b,L: dimensiones axb de la secci�n rectangular junto con la 
%            altura L del pilar
%   - A,B,C: N�mero de elementos seg�n X,Y y Z

% Coordenadas de los nodos
%
% Al nodo (i,j,k) se le asignar� el n� de nodo n = i*(B+1)*(C+1)+j*(C+1)+k+1
nodos=NaN*zeros(A*B*C,3);
for i=0:A, for j=0:B, for k=0:C
   n = i*(B+1)*(C+1)+j*(C+1)+k+1;
   nodos(n,1)=i;
   nodos(n,2)=j;
   nodos(n,3)=k;
end, end, end
[Nn,nada]=size(nodos); % Numero Nn de nodos

% Matriz de Conectividad
elem=[];
for i=1:A, for j=1:B, for k=1:C
   % N�meros de los nodos de la base inferior
   a1 = (i+1-1)*(B+1)*(C+1) + (j  -1)*(C+1) + k-1 + 1 ;
   b1 = (i  -1)*(B+1)*(C+1) + (j  -1)*(C+1) + k-1 + 1 ;
   c1 = (i  -1)*(B+1)*(C+1) + (j+1-1)*(C+1) + k-1 + 1 ;
   d1 = (i+1-1)*(B+1)*(C+1) + (j+1-1)*(C+1) + k-1 + 1 ;
   % N�meros de los nodos de la base superior
   a2 = (i+1-1)*(B+1)*(C+1) + (j  -1)*(C+1) + k   + 1 ;
   b2 = (i  -1)*(B+1)*(C+1) + (j  -1)*(C+1) + k   + 1 ;
   c2 = (i  -1)*(B+1)*(C+1) + (j+1-1)*(C+1) + k   + 1 ;
   d2 = (i+1-1)*(B+1)*(C+1) + (j+1-1)*(C+1) + k   + 1 ;
   % Actualizaci�n de matriz de conectividad
   elem = [ elem ; a1 b1 c1 d1   a2 b2 c2 d2 ];
end, end, end
[Ne,nada]=size(elem); % Numero Ne de elementos


% El pilar ya se ha generado, pero sus dimensiones no coinciden con las
% prefijadas

nodos(:,1)=nodos(:,1)*a/A;
nodos(:,2)=nodos(:,2)*b/B;
nodos(:,3)=nodos(:,3)*L/C;

end

