%Tareas Obligatorias Tema 14.2 (�lvaro Morales - 18240)

close all, clear all

NombreArchivo='malla.xls'; % Se le pasa a LecturaEnsamblajeXLS
                   % en NombreArchivo el archivo XLS a leer
LecturaEnsamblajeXLS;

Problema='Dinamico';
switch Problema
    case 'Estatico'
        q = K\fo ; % Se resuelve K*q = fo
        figure
        RepresentaLadrillos(nodos,CarasExt,BarrasExt,NodosExt,q );
    case 'Dinamico'
        lambda=eigs(M\K,30,'smallestabs'); 
        w=sqrt(lambda); 
        f_reson=real( w/(2*pi) );
        disp( sprintf('La frecuencia #1 es %6.2f Hz',f_reson(1) ));
        figure
        plot(f_reson,'bo'); grid on
end