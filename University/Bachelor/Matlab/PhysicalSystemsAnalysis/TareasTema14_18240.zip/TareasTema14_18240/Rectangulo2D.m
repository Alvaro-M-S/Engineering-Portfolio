function [nodos2D,elem2D]=Rectangulo2D(a,b,Na,Nb);
% Genera una malla rectangular de lados de longitud a (seg�n X)
% y b (segun Y) con Na elementos seg�n X y Nb elementos segun Y

ai=a*[0:Na]/Na;        % Posici�n de los nodos segun X
 i=[1:Na];             % Sub�ndices i de los elementos
bj=b*[0:Nb]/Nb;        % Posici�n de los nodos segun Y
 j=[1:Nb];             % Sub�ndices j de los elementos
[x,y]=meshgrid(ai,bj); % Coordenadas de los nodos
[i,j]=meshgrid(i,j);   % Sub�ndices i,j de los elementos
            
x=x(:); y=y(:); nodos2D=[x  y];
i=i(:); j=j(:);

elem2D=[ (i-1)*(Nb+1)+j  (i-1)*(Nb+1)+j+1 i*(Nb+1)+j+1 i*(Nb+1)+j ];