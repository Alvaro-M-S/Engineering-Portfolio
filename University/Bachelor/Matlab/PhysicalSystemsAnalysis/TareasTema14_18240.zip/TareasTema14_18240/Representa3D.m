function Representa3D(x,y,z,barras,c)
%
% Representa una estructura tridimensional
% formada por barras articuladas
%
% Variables de entrada:
%
%      x,y,z: vectores de dimensi�n Nnx1 conteniendo las coordenadas de los
%           nodos de la estructura
%      barras: Matriz de dimensi�n Nbx2 conteniendo los n�meros de los
%           nodos en los que comienza y finaliza cada una de las barras
%     c:    color de las barras. Por omisi�n es verde
%
%     Nn y Nb son, respectivamente, el n�mero de nodos y el de barras

if nargin<5, c='g'; end

% Representaci�n de las barras
[Nb,nada]=size(barras);
for i=1:Nb
    plot3( x(barras(i,:)) , y(barras(i,:)) , z(barras(i,:)) , c ); hold on
end

% Representaci�n de los nodos
plot3( x,y,z ,'bo' );

axis equal, grid on, xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)');