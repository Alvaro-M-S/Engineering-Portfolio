%Mallado para la Tarea TC3 (Por tanto tarea TC2)

% system('EasyMesh_win');

datos='TC2_18240.xls';

EasyMesh(datos,true)

EasyMeshRepre(datos)