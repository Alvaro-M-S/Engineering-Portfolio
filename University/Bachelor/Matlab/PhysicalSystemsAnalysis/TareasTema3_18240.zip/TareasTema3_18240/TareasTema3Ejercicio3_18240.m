%Tarea Tema 3 Ejercicio 3

%Llamar a la funcion

[x,y,barras]=VigaVertical_X(1,12,12)
%Para el plot, ordenador los puntos para unirlos y formar las barras

x2=x-1/2; %para centrar el plot

grid on

plot(x2,y,'ro'); %representaci�n grt�fica de los nodos

axis equal

barrasx=[];
barrasy=[];

z=size(barras);

for i=1:z(1)
    barrasx=[barrasx;x2(barras(i,1));x2(barras(i,2))];
    barrasy=[barrasy;y(barras(i,1));y(barras(i,2))];

end

hold on

grid on

plot(barrasx,barrasy,'r-')

