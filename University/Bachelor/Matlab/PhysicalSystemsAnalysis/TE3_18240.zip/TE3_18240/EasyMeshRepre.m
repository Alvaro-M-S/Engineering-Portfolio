function EasyMeshRepre(arc)
% Representa la malla generada por EasyMesh
% y almacenada en el archivo arc (EXCEL)

% Lectura del Archivos
Def    = readmatrix(arc, 'Sheet','d', 'Range','A29:L65536');   % Pesta�a 'd' (Definici�n)
Nodos  = readmatrix(arc, 'Sheet','n', 'Range','A29:D65536');   % Pesta�a 'n' (NODOS)
Elem   = readmatrix(arc, 'Sheet','e', 'Range','A29:M65536');   % Pesta�a 'e' (ELEMENTOS)
Segmen = readmatrix(arc, 'Sheet','s', 'Range','A29:F65536');   % Pesta�a 's' (SEGMENTOS)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n de la definici�n del problema %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
x   = rmmissing( Def(:, 2) );     y  = rmmissing( Def(:, 3) ); 
tn  = rmmissing( Def(:, 5) );     in = rmmissing( Def(:, 1) );
seg = rmmissing( Def(:, 10:11) ); ts = rmmissing( Def(:, 12) ); 
is  = rmmissing( Def(:, 9) );

tmin = min([tn;ts]); tmax = max([tn;ts]);
c = lines(1+(tmax-tmin)); % Colores

% Representaci�n de los nodos
for i = 1:length(x)
    plot(x(i), y(i), 'o', 'color',c(1 + tn(i) - tmin, :)); hold on
    text(x(i), y(i), sprintf('%1.0f', in(i)));
end

% Representaci�n de los segmentos
for i = 1:length(ts)
    ii = [ find(in == seg(i, 1))  find(in == seg(i, 2)) ];  
    plot(x(ii), y(ii), 'color',c(1 + ts(i) - tmin, :), 'LineWidth',2);
    text(mean(x(ii)), mean(y(ii)), sprintf('%1.0f', is(i)));
end

axis equal, grid on, xlabel('X (m)'); ylabel('Y (m)');
title(sprintf('Archivo %s :  Pesta�a "d"', arc));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n de los nodos y los segmentos  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
x  = rmmissing( Nodos(:, 2) ); y   = rmmissing( Nodos(:, 3) ); 
tn = rmmissing( Nodos(:, 4) ); seg = rmmissing( Segmen(:, 2:3) );
ts = rmmissing( Segmen(:, 6) );

tmin = min([tn;ts]); tmax = max([tn;ts]);
c = lines(1 + (tmax - tmin)); % Colores

% Representaci�n de los nodos
for i = 1:length(x)
    plot(x(i), y(i), '.', 'color',c(1 + tn(i) - tmin, :), 'MarkerSize',10); 
    hold on
end

% Representaci�n de los segmentos
for i = 1:length(ts)
    ii = seg(i, :);  
    if prod(ii <= length(x))
        plot(x(ii), y(ii), 'color',c(1 + ts(i) - tmin, :));
    end
end

axis equal, grid on, xlabel('X (m)'); ylabel('Y (m)');
title(sprintf('Archivo %s :  Pesta�as "n" y "s"', arc));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n de los tri�ngulos             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
tri = rmmissing( Elem(:, 2:4) ); tt = rmmissing( Elem(:, 13) );

tmin = min(tt); tmax = max(tt);
c = lines(1 + (tmax - tmin)); % Colores

% Representaci�n de los elementos
for i = 1:length(tt)
    ii = tri(i, :);  
    fill(x(ii), y(ii), c(1 + tt(i) - tmin,:)); hold on
    ii = [ii ii(1)];
    plot(x(ii), y(ii), 'color', [0.7 0.7 0.7]); 
end

axis equal, grid on, xlabel('X (m)'); ylabel('Y (m)');
title(sprintf('Archivo %s :  Pesta�a "e"', arc));

