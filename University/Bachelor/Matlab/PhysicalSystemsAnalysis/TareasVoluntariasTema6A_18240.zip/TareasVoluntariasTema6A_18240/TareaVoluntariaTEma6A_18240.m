%Tarea Voluntaria Tema 6A

[x,y,Fijos,mn,fx,fy , barras,mb,k,loo]=LeeEstru2D('TareaVoluntariaTema6A_18240');

Representa2D(x,y,barras);

hold on

g=9.7995;

Nn=length(x); %numero de nodos
Nb=length(k); %numero de barras
gdl=2*Nn; %numeor de gdl

%Reserva de memoria para las variables del problema
K=zeros(gdl,gdl); %Matriz de rigidez
M=zeros(gdl,gdl);%Matriz de Masa

f=zeros(gdl,1); %Vector de fuerzas

f(1:2:end)=f(1:2:end)+fx;
f(2:2:end)=f(2:2:end)+fy;
f(2:2:end)=f(2:2:end)-mn*g;

%Ensambleje de las barras

for e=1:Nb
 a=barras(e,1);
 b=barras(e,2);
 ra=[x(a) y(a)];
 rb=[x(b) y(b)];
 [Ke,Me,fg]=barra2D(ra,rb,k(e),mb(e));
 
 ii=[2*(a-1)+1 2*(a-1)+2 2*(b-1)+1 2*(b-1)+2];
 
 %Ensamblaje
 K(ii,ii)=K(ii,ii)+Ke;
 M(ii,ii)=M(ii,ii)+Me;
 f(ii)=f(ii)+fg;
 
end

%Aplicaci�n de las condiciones de contorno
Kmax=max(abs(K(:)));
Kinf=1e8*Kmax;
fijos=NaN(gdl,1);
fijos(1:2:end)=Fijos(:,1);
fijos(2:2:end)=Fijos(:,2);
for i=1:gdl
    if fijos(i)==1
    K(i,i)=K(i,i)+Kinf;
    end
end

%Resolucion del problema estatico
q=K\f;

%Calculo de las reacciones
r=zeros(gdl,1);
for i=1:gdl
    if fijos(i)==1
        r(i)=-Kinf*q(i);
    end 
end
Rx=r(1:2:end);
Ry=r(2:2:end);

dx=q(1:2:end);
dy=q(2:2:end);

%Calculo de las tensiones de las barras
T=NaN(Nb,1);
for e=1:Nb
     a=barras(e,1);
 b=barras(e,2);
 ra=[x(a) y(a)];
 rb=[x(b) y(b)];
 l1=norm(rb-ra); %long antes de deformarse
 
  ra=[x(a)+dx(a) y(a)+dy(a)];
 rb=[x(b)+dx(b) y(b)+dy(b)];
 l2=norm(rb-ra); %Long. desp de deformarse
 
 T(e)=k(e)*(l2-l1);
end

%Representaci�n gr�fica de las tensiones
% Amp=1000;

figure
Representa2DT(x+dx,y+dy,barras,T)

disp('  ');
disp('Barra           T');
for i=1:Nb
    s=sprintf(' %2.0f        %4.3f N',i,T(i));
    disp(s);
end 

fileID = fopen('Resultados.txt', 'w');

fprintf(fileID,'Barra           T\n\n');
for i=1:Nb
fprintf(fileID,' %2.0f           %4.3f N \n',i,T(i));
end
fclose(fileID);