%Funcion que lea la plantilla: 
function [x,y,Fijos,mn,fx,fy , barras,mb,k,loo]=LeeEstru2D(nombre)

%Variables de salida para los nodos
%x,y: coordenadas x,y
%Fijos: Matriz Nnx2 indicando los grados de libertad que son fijos
%m: masa de cada nodo
%fx,fy: Fuerzas aplicadas seg�n x e y en cada nodo

%Variables de salida para las barras
%barras:Matriz Nbx2 de conectividad de las barras
%mb: Masas de las barras
%k: constante el�stica de las barras
%loo: longitud natural de las barras

data=xlsread(nombre,'nodos');
x=data(:,2);
y=data(:,3);
mn=data(:,5);
fx=data(:,6);
fy=data(:,7);
Fijos=data(:,8:9);


data=xlsread(nombre,'barras');
barras=data(:,2:3);
mb=data(:,5);
k=data(:,7);
loo=data(:,6);

end
