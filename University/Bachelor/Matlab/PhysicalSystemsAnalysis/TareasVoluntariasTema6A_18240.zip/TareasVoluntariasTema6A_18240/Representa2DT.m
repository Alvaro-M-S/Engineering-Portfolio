function Representa2DT(x,y,barras,T)
%
% Representa una estructura bidimensional
% formada por barras articuladas y sometidas
% a una serie de tensiones
%
% Variables de entrada:
%
%      x,y: vectores de dimensi�n Nnx1 conteniendo las coordenadas de los
%           nodos de la estructura
%      barras: Matriz de dimensi�n Nbx2 conteniendo los n�meros de los
%           nodos en los que comienza y finaliza cada una de las barras
%      T:   vector de tensiones a las que est�n sometidas las barras
%
%     Nn y Nb son, respectivamente, el n�mero de nodos y el de barras

if nargin<4, c='g'; end


nc1 =32;        % N�mero de colores (en positivo y negativo)
nc2=2*nc1+1;    % N�mero total de colores
ncmax  = 1;     % Color correspondiente a Tmax
nczero = nc1+1; % Color correspondiente a T=0
ncmin  = nc2;   % Color correspondiente a Tmin

cm=jet(nc2);    % Escala de colores (JET)

Tmax  = max(T);
Tmin  = min(T);

% Representaci�n de las barras
[Nb,nada]=size(barras);
for i=1:Nb
    
    if T(i)>0
        e=T(i)/Tmax;
        ic=round(nczero*(1-e)+ncmax*e);
        c=cm(ic,:);
    else
        e=T(i)/Tmin;
        ic=round(nczero*(1-e)+ncmin*e);
        c=cm(ic,:);
    end
    
    plot( x(barras(i,:)) , y(barras(i,:)) , 'color',c ,'LineWidth',2 ); hold on
 
    e=0.3+0.4*rand;
    xc=e*x(barras(i,1))+(1-e)*x(barras(i,2));
    yc=e*y(barras(i,1))+(1-e)*y(barras(i,2));
    text(xc,yc,sprintf('%1.0f',i),'VerticalAlignment','middle','HorizontalAlignment','center','color',c);
end

% Representaci�n de los nodos
plot( x,y ,'ko' );

axis equal, grid on, xlabel('X (m)'); ylabel('Y (m)');
     
for i=1:length(x)
    Opc=1+floor(7.99*rand);
    switch Opc
        case 1, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','top','HorizontalAlignment','left','color','k');
        case 2, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','top','HorizontalAlignment','center','color','k');
        case 3, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','top','HorizontalAlignment','right','color','k');
        case 4, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','middle','HorizontalAlignment','right','color','k');
        case 5, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','bottom','HorizontalAlignment','right','color','k');
        case 6, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','bottom','HorizontalAlignment','center','color','k');
        case 7, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','bottom','HorizontalAlignment','left','color','k');
        case 8, text(x(i),y(i),sprintf('   %1.0f   ',i),'VerticalAlignment','middle','HorizontalAlignment','left','color','k');
    end
end



