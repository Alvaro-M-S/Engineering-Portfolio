%Tarea 1 Calor 18240

close all, clear all, fclose all;

arc='Tarea_C1.xls';  % Nombre del archivo EXCEL que contiene la definici�n del problema
                 % (Se supone que se ha generado con EasyMesh.m)
                 
[x,y,Conec,TipoNodo,TipoMat]=LeerCalor2D(arc); %Lectura del archivo

% Densidad de calor generado por unidad de volumen:
%     El cobre se supone que tiene unas dimensiones de 
%     20 mm x 20 mm x 1 m y que disipa 1000 W 

Wcobre    = 1000 ;
q_cobre   = Wcobre / (0.020*0.020*1) ; % Densidad de calor generado

TipoCobre = 4 ;    % Tipo de los elementos que pertenecen al chip (4)  

% Tipos de Materiales
Material=[
% Tipo   k (conductividad t�rmica en W/(m*k) )   
   1    0.042          ; ...  % Aislante
   2    160            ; ...  % Aluminio
   3    12            ; ...  % Cer�mica
   4    389         ]  ; ...  % Cobre
   
% Lecturas de las pesta�as 'n', 'e' y 's' del archivo EXCEL
Nodos =xlsread(arc,'n','A29:D893');   % Pesta�a 'n' (NODOS)
Elem  =xlsread(arc,'e','A29:M1444');   % Pesta�a 'e' (ELEMENTOS)
Segmen=xlsread(arc,'s','A29:F2316');   % Pesta�a 's' (SEGMENTOS)

% x=Nodos(:,2); y=Nodos(:,3); % Coordenadas de los nodos
% TipoNodo=Nodos(:,4);        % Tipo de nodo (marcador)
% Conec=Elem(:,2:4);          % Matriz de Conectividad
% TipoMat=Elem(:,13);         % Tipo de Material

% Representaci�n gr�fica de la malla
Repre2DmallaT(x,y,Conec)

% Representaci�n gr�fica de la malla
Repre2DmallaT(x,y,Conec)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%      ENSAMBLAJE                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=length(x);           % N�mero de nodos (que es igual al n�mero de inc�gnitas)
Ne=length(Elem(:,1));  % N�mero de elementos
K=sparse(n,n);         % Matriz de Capacidad global
q=zeros(n,1);          % Vector de fuentes de calor nodales

% Ensamblaje a lo largo de todos los elementos triangulares
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad T�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   [Ke,Be]=KcalorT2D(x(ii),y(ii),k);
   
   % Ensamblaje de la matriz K
   K(ii,ii)=K(ii,ii)+Ke;
   
   % fuentes nodales de calor
   if TipoMat(i)==TipoCobre
       p=ones(3,1)*q_cobre;  % densidades nodales de calor
   else
       p=zeros(3,1);
   end
   qe=Be*p; % fuentes nodales de calor equivalentes
   
   % Ensamblaje de fuentes nodales de calor
   q(ii)=q(ii)+qe;
end
Ko=K; qo=q; % Valores de C y q antes de aplicar las condiciones de contorno

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Introducci�n de las condiciones de contorno en temperatura %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Kmax=max(max(abs(K)));
Kinf=1e8*Kmax;

T2 = 35;   % Temperatura del fluido refrigerante dentro de los canales de aluminio
           % (nodos marcados como 2)

T1 = 35;   % Temperatura en el aislante del exterior
           % (nodos marcados como 1)
      

figure(1), hold on

T=T2; % Nodos marcados como 2
ii=find( TipoNodo==2 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'ro');

% Nodos marcados como 1
T=T1; 
ii=find( TipoNodo==1 ); 
q(ii)=q(ii)+Kinf*T; 
for j=1:length(ii)
    k=ii(j);
    K(k,k)=K(k,k)+Kinf;
end
plot(x(ii),y(ii),'go');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Resoluci�n del sistema de ecuaciones %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u = K\q ;  % Calculo de la temperatura en cada nodo

xlswrite('Tarea_C1.xls',Nodos(:,1),'Temperatura','A2');
xlswrite('Tarea_C1.xls',u,'Temperatura','B2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para las temperaturas)              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure, h=trisurf(Conec,x,y,u)
axis equal, colormap jet, shading interp
set(h,'EdgeColor','w')
colorbar
xlabel('X (m)'); ylabel('Y (m)'); zlabel('u (V)');
view(2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para el flujo de calor)             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% C�lculo del Flujo en el centro de los elementos
xc=NaN(Ne,1); yc=xc; % Coordenadas de los centros de los Elementos
Qx=xc;        Qy=xc; % Componentes del vector flujo de calor
for i=1:Ne
   % Tipo de material
   j = find( Material(:,1)==TipoMat(i) );
   k = Material(j,2);  % Conductividad t�rmica
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   
   % Centro del tri�ngulo
   xc(i)=mean(x(ii)); yc(i)=mean(y(ii));
   
   % Matriz M 
   [~,~,M]=KcalorT2D(x(ii),y(ii),k);
   Q = M*u(ii);   % Flujo de calor 
   
   Qx(i)=Q(1);
   Qy(i)=Q(2);
end

xlswrite('Tarea_C1.xls',Elem(:,1),'Flujo de Calor','A2');
xlswrite('Tarea_C1.xls',Qx,'Flujo de Calor','B2');
xlswrite('Tarea_C1.xls',Qy,'Flujo de Calor','C2');

% Representaci�n gr�fica del flujo de calor
figure
quiver(xc,yc,Qx,Qy)
axis equal
xlabel('X (m)'); ylabel('Y (m)');
title('Vector Flujo de Calor');

% Localizaci�n del nodo mas cercano al "centro"
% del cobre
Xc=0.065; Yc=0.065; 
d=sqrt( (x-Xc).^2+(y-Yc).^2 );
[~,i]=min(d); 
Tc=u(i); % Temperatura en el centro del cobre
disp(sprintf('Potencia disipada por el cobre,      W  = %3.0f W',Wcobre));
disp(sprintf('Temperatura en el centro del cobre , Tc = %6.3f �C',Tc));
disp(sprintf('Temperatura m�xima ,              Tmax = %6.3f �C',max(u)));

%Determinar T max y min del aluminio y d�nde

% Nodos marcados como 2
ii=find( (TipoNodo==2)|(TipoNodo==0) ); 
umax=0;
umin=3000;
for j=1:length(ii)
   if u(ii(j)) > umax
       umax=u(ii(j)); 
       posumax=ii(j);
   else
       if u(ii(j)) < umin
        umin=u(ii(j));
        posumin=ii(j);
       end
   end
end
umin
posumin
umax
posumax

