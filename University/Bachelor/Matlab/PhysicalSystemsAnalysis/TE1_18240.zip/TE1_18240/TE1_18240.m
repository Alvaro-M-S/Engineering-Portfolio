%TElectrostatica1 18240

%Comienzo de la resoluci�n del problema

%Materiales (En excel)

close all,clear all, fclose all;

co    = 299792458;   % Velocidad de la luz en el vacio (SI)
mu_o  = 4e-7*pi;     % Permeabilidad magn�tica del vacio (SI)
eps_o = 1/co^2/mu_o; % Permitividad el�ctrica del vacio (SI)

arc='Tarea_E1.xls'; %Malla del problema
[x,y,Conec,TipoNodo,TipoMat]=LeerElec2D(arc); %Lectura del archivo

% Tipos de Materiales
Material=[
% Tipo   eps   
   -1    eps_o            ; ...  % Vacio
    1    1.00051*eps_o    ; ...  % Aire
    2    1.00051*eps_o    ; ...  % 
    4    5.4*eps_o        ; ...  % Mica / Vidrio
    5    35*eps_o       ] ; ...  % PVC


Nodos =xlsread(arc,'n','A29:D1123');   % Pesta�a 'n' (NODOS)
Elem  =xlsread(arc,'e','A29:M2004');   % Pesta�a 'e' (ELEMENTOS)
Segmen=xlsread(arc,'s','A29:F3100');   % Pesta�a 's' (SEGMENTOS)

% x=Nodos(:,2); y=Nodos(:,3); % Coordenadas de los nodos
% TipoNodo=Nodos(:,4);        % Tipo de nodo (marcador)
% Conec=Elem(:,2:4);          % Matriz de Conectividad
% TipoMat=Elem(:,13);         % Tipo de Material
    
% Representaci�n gr�fica de la malla
Repre2DmallaT(x,y,Conec)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%      ENSAMBLAJE                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=length(x);           % N�mero de nodos (que es igual al n�mero de inc�gnitas)
Ne=length(Elem(:,1));  % N�mero de elementos
C=sparse(n,n);         % Matriz de Capacidad global
B=sparse(n,n);         % Matriz global q = B*p ( q: cargas , p: densidades)
q=zeros(n,1);          % Vector de cargas nodales

% Ensamblaje a lo largo de todos los elementos triangulares
for i=1:Ne
   % Tipo de material
   k = find( Material(:,1)==TipoMat(i) );
   eps_e=Material(k,2);  % Permitividad Relativa
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   [Ce,Be]=KelecT2D(x(ii),y(ii),eps_e);
   
   % Ensamblaje de la matriz de capacidad
   C(ii,ii)=C(ii,ii)+Ce;
   
  
   % Ensamblaje de la matriz B
   B(ii,ii)=B(ii,ii)+Be;
   
   % Ensamblaje del vector de cargas nodales
   %No hay en este ej

   
end
Co=C; qo=q; % Valores de C y q antes de aplicar las condiciones de contorno

% Introducci�n de las condiciones de contorno en tensi�n
Cmax=max(max(abs(C)));
Cinf=1e8*Cmax;

%Introducci�n de las condiciones de contorno
V1=0;
V2=10;
V3=-10;

%Contorno 1
ii=find((TipoNodo==1));
q(ii)=q(ii)+Cinf*V1;
for j=1:length(ii)
    k=ii(j);
    C(k,k)=C(k,k)+Cinf;
end
%Contorno 2
ii=find((TipoNodo==2));
q(ii)=q(ii)+Cinf*V2;
for j=1:length(ii)
    k=ii(j);
    C(k,k)=C(k,k)+Cinf;
end
%Contorno 3
ii=find((TipoNodo==3));
q(ii)=q(ii)+Cinf*V3;
for j=1:length(ii)
    k=ii(j);
    C(k,k)=C(k,k)+Cinf;
end

% Resoluci�n del sistema de ecuaciones
u = C\q ;  % Calculo del potencial en cada nodo

xlswrite('Tarea_E1.xls',Nodos(:,1),'Potencial','A2');
xlswrite('Tarea_E1.xls',u,'Potencial','B2');

% Representaci�n gr�fica del resultado
% figure, trimesh(Conec,x,y,u);
figure, trisurf(Conec,x,y,u);
xlabel('X (m)'); ylabel('Y (m)'); zlabel('u (V)');

figure, trisurf(Conec,x,y,u); shading interp; view(2); colorbar
xlabel('X (m)'); ylabel('Y (m)'); 

figure, tricontour([x,y],Conec,u,20); 
xlabel('X (m)'); ylabel('Y (m)'); 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Representaci�n gr�fica del resultado %%% 
%%% (para el campo el�ctrico)            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% C�lculo del Campo El�ctrico en el centro de los elementos
xc=NaN(Ne,1); yc=xc; % Coordenadas de los centros de los Elementos
Ex=xc;        Ey=xc; % Componentes del vector campo el�ctrico
for i=1:Ne
   % Tipo de material
   k = find( Material(:,1)==TipoMat(i) );
   eps_e=Material(k,2);  % Permitividad Relativa
   
   % Nodos del tri�ngulo
   ii = Conec(i,:); 
   
   % Centro del tri�ngulo
   xc(i)=mean(x(ii)); yc(i)=mean(y(ii));
   
   % Matriz M 
   [~,~,M]=KelecT2D(x(ii),y(ii),eps_e);
   E = M*u(ii); 
   
   Ex(i)=E(1);
   Ey(i)=E(2);
end

xlswrite('Tarea_E1.xls',Elem(:,1),'Campo Electrico','A2');
xlswrite('Tarea_E1.xls',Ex,'Campo Electrico','B2');
xlswrite('Tarea_E1.xls',Ey,'Campo Electrico','C2');

% Representaci�n gr�fica del campo el�ctrico
figure
quiver(xc,yc,Ex,Ey); axis equal
xlabel('X (m)'); ylabel('Y (m)');
title('Campo El�ctrico E');

% Cargas nodales que finalmente se encuentran sobre los nodos
qn=Co*u;
%Contorno 2
ii=find((TipoNodo==2));
for j=1:length(ii)
    k=ii(j);
    q2(j)=qn(k);
end
%Contorno 3
ii=find((TipoNodo==3));
for j=1:length(ii)
    k=ii(j);
    q3(j)=qn(k);
end

