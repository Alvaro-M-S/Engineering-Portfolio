function [x,y,Conec,TipoNodo,TipoMat]=LeerElec2D(arc)

    % Lecturas de las pesta�as 'n', 'e' y 's' del archivo EXCEL
    Nodos =xlsread(arc,'n','A29:D65536'); % Pesta�a 'n' (NODOS)
    Elem =xlsread(arc,'e','A29:M65536');  % Pesta�a 'e' (ELEMENTOS)
    Segmen=xlsread(arc,'s','A29:F65536'); % Pesta�a 's' (SEGMENTOS)

    x=Nodos(:,2); y=Nodos(:,3); % Coordenadas de los nodos
    TipoNodo=Nodos(:,4);        % Tipo de nodo (marcador)
    Conec=Elem(:,2:4);          % Matriz de Conectividad
    TipoMat=Elem(:,13);         % Tipo de Material
    
end