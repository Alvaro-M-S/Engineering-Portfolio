function [x,y,TipoNodo,Conec,TipoMat]=EasyMeshLeeXLS(arc); 

% Lecturas de las pestanñas n (nodos) y e (elementos) del archivo EXCEL
Nodos = readmatrix(arc,'Sheet','n','Range','A29:D65536'); Nodos=rmmissing(Nodos);
Elem  = readmatrix(arc,'Sheet','e','Range','A29:M65536'); Elem =rmmissing(Elem);

x=Nodos(:,2); y=Nodos(:,3); % Coordenadas x,y de los nodos
TipoNodo = Nodos(:,4);       % Tipo de nodo
Conec    = Elem(:,2:4);     % Matriz de Conectividad
TipoMat  = Elem(:,13);      % Tipo de Material